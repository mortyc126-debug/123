package com.google.android.material.color.utilities;

import java.util.function.Function;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: classes3.dex */
public final /* synthetic */ class MaterialDynamicColors$$ExternalSyntheticLambda85 implements Function {
    public final /* synthetic */ MaterialDynamicColors f$0;

    @Override // java.util.function.Function
    public final Object apply(Object obj) {
        return this.f$0.highestSurface((DynamicScheme) obj);
    }
}
