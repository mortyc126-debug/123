package com.google.android.material.carousel;

/* JADX INFO: loaded from: classes3.dex */
interface Carousel {
    int getCarouselAlignment();

    int getContainerHeight();

    int getContainerWidth();

    int getItemCount();

    boolean isHorizontal();
}
