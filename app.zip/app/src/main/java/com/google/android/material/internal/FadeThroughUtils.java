package com.google.android.material.internal;

/* JADX INFO: loaded from: classes3.dex */
final class FadeThroughUtils {
    static final float THRESHOLD_ALPHA = 0.5f;

    static void calculateFadeOutAndInAlphas(float progress, float[] out) {
        if (progress <= THRESHOLD_ALPHA) {
            out[0] = 1.0f - (2.0f * progress);
            out[1] = 0.0f;
        } else {
            out[0] = 0.0f;
            out[1] = (2.0f * progress) - 1.0f;
        }
    }

    private FadeThroughUtils() {
    }
}
