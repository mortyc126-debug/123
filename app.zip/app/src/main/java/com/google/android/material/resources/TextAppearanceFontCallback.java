package com.google.android.material.resources;

import android.graphics.Typeface;

/* JADX INFO: loaded from: classes3.dex */
public abstract class TextAppearanceFontCallback {
    public abstract void onFontRetrievalFailed(int i);

    public abstract void onFontRetrieved(Typeface typeface, boolean z);
}
