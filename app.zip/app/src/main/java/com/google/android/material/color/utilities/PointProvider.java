package com.google.android.material.color.utilities;

/* JADX INFO: loaded from: classes3.dex */
public interface PointProvider {
    double distance(double[] dArr, double[] dArr2);

    double[] fromInt(int i);

    int toInt(double[] dArr);
}
