package com.google.android.material.internal;

import android.text.StaticLayout;

/* JADX INFO: loaded from: classes3.dex */
public interface StaticLayoutBuilderConfigurer {
    void configure(StaticLayout.Builder builder);
}
