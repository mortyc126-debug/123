package com.google.android.material.slider;

/* JADX INFO: loaded from: classes3.dex */
public interface BaseOnChangeListener<S> {
    void onValueChange(S s, float f2, boolean z);
}
