package com.google.android.material;

/* JADX INFO: loaded from: classes3.dex */
public final class R {

    public static final class anim {
        public static int abc_fade_in = 0x7f010000;
        public static int abc_fade_out = 0x7f010001;
        public static int abc_grow_fade_in_from_bottom = 0x7f010002;
        public static int abc_popup_enter = 0x7f010003;
        public static int abc_popup_exit = 0x7f010004;
        public static int abc_shrink_fade_out_from_bottom = 0x7f010005;
        public static int abc_slide_in_bottom = 0x7f010006;
        public static int abc_slide_in_top = 0x7f010007;
        public static int abc_slide_out_bottom = 0x7f010008;
        public static int abc_slide_out_top = 0x7f010009;
        public static int abc_tooltip_enter = 0x7f01000a;
        public static int abc_tooltip_exit = 0x7f01000b;
        public static int btn_checkbox_to_checked_box_inner_merged_animation = 0x7f01000c;
        public static int btn_checkbox_to_checked_box_outer_merged_animation = 0x7f01000d;
        public static int btn_checkbox_to_checked_icon_null_animation = 0x7f01000e;
        public static int btn_checkbox_to_unchecked_box_inner_merged_animation = 0x7f01000f;
        public static int btn_checkbox_to_unchecked_check_path_merged_animation = 0x7f010010;
        public static int btn_checkbox_to_unchecked_icon_null_animation = 0x7f010011;
        public static int btn_radio_to_off_mtrl_dot_group_animation = 0x7f010012;
        public static int btn_radio_to_off_mtrl_ring_outer_animation = 0x7f010013;
        public static int btn_radio_to_off_mtrl_ring_outer_path_animation = 0x7f010014;
        public static int btn_radio_to_on_mtrl_dot_group_animation = 0x7f010015;
        public static int btn_radio_to_on_mtrl_ring_outer_animation = 0x7f010016;
        public static int btn_radio_to_on_mtrl_ring_outer_path_animation = 0x7f010017;
        public static int design_bottom_sheet_slide_in = 0x7f010018;
        public static int design_bottom_sheet_slide_out = 0x7f010019;
        public static int design_snackbar_in = 0x7f01001a;
        public static int design_snackbar_out = 0x7f01001b;
        public static int fragment_fast_out_extra_slow_in = 0x7f01001c;
        public static int linear_indeterminate_line1_head_interpolator = 0x7f01001d;
        public static int linear_indeterminate_line1_tail_interpolator = 0x7f01001e;
        public static int linear_indeterminate_line2_head_interpolator = 0x7f01001f;
        public static int linear_indeterminate_line2_tail_interpolator = 0x7f010020;
        public static int m3_bottom_sheet_slide_in = 0x7f010021;
        public static int m3_bottom_sheet_slide_out = 0x7f010022;
        public static int m3_motion_fade_enter = 0x7f010023;
        public static int m3_motion_fade_exit = 0x7f010024;
        public static int m3_side_sheet_enter_from_left = 0x7f010025;
        public static int m3_side_sheet_enter_from_right = 0x7f010026;
        public static int m3_side_sheet_exit_to_left = 0x7f010027;
        public static int m3_side_sheet_exit_to_right = 0x7f010028;
        public static int mtrl_bottom_sheet_slide_in = 0x7f010029;
        public static int mtrl_bottom_sheet_slide_out = 0x7f01002a;
        public static int mtrl_card_lowers_interpolator = 0x7f01002b;

        private anim() {
        }
    }

    public static final class animator {
        public static int design_appbar_state_list_animator = 0x7f020000;
        public static int design_fab_hide_motion_spec = 0x7f020001;
        public static int design_fab_show_motion_spec = 0x7f020002;
        public static int fragment_close_enter = 0x7f020003;
        public static int fragment_close_exit = 0x7f020004;
        public static int fragment_fade_enter = 0x7f020005;
        public static int fragment_fade_exit = 0x7f020006;
        public static int fragment_open_enter = 0x7f020007;
        public static int fragment_open_exit = 0x7f020008;
        public static int m3_appbar_state_list_animator = 0x7f020009;
        public static int m3_btn_elevated_btn_state_list_anim = 0x7f02000a;
        public static int m3_btn_state_list_anim = 0x7f02000b;
        public static int m3_card_elevated_state_list_anim = 0x7f02000c;
        public static int m3_card_state_list_anim = 0x7f02000d;
        public static int m3_chip_state_list_anim = 0x7f02000e;
        public static int m3_elevated_chip_state_list_anim = 0x7f02000f;
        public static int m3_extended_fab_change_size_collapse_motion_spec = 0x7f020010;
        public static int m3_extended_fab_change_size_expand_motion_spec = 0x7f020011;
        public static int m3_extended_fab_hide_motion_spec = 0x7f020012;
        public static int m3_extended_fab_show_motion_spec = 0x7f020013;
        public static int m3_extended_fab_state_list_animator = 0x7f020014;
        public static int mtrl_btn_state_list_anim = 0x7f020015;
        public static int mtrl_btn_unelevated_state_list_anim = 0x7f020016;
        public static int mtrl_card_state_list_anim = 0x7f020017;
        public static int mtrl_chip_state_list_anim = 0x7f020018;
        public static int mtrl_extended_fab_change_size_collapse_motion_spec = 0x7f020019;
        public static int mtrl_extended_fab_change_size_expand_motion_spec = 0x7f02001a;
        public static int mtrl_extended_fab_hide_motion_spec = 0x7f02001b;
        public static int mtrl_extended_fab_show_motion_spec = 0x7f02001c;
        public static int mtrl_extended_fab_state_list_animator = 0x7f02001d;
        public static int mtrl_fab_hide_motion_spec = 0x7f02001e;
        public static int mtrl_fab_show_motion_spec = 0x7f02001f;
        public static int mtrl_fab_transformation_sheet_collapse_spec = 0x7f020020;
        public static int mtrl_fab_transformation_sheet_expand_spec = 0x7f020021;

        private animator() {
        }
    }

    public static final class attr {
        public static int actionBarDivider = 0x7f030000;
        public static int actionBarItemBackground = 0x7f030001;
        public static int actionBarPopupTheme = 0x7f030002;
        public static int actionBarSize = 0x7f030003;
        public static int actionBarSplitStyle = 0x7f030004;
        public static int actionBarStyle = 0x7f030005;
        public static int actionBarTabBarStyle = 0x7f030006;
        public static int actionBarTabStyle = 0x7f030007;
        public static int actionBarTabTextStyle = 0x7f030008;
        public static int actionBarTheme = 0x7f030009;
        public static int actionBarWidgetTheme = 0x7f03000a;
        public static int actionButtonStyle = 0x7f03000b;
        public static int actionDropDownStyle = 0x7f03000c;
        public static int actionLayout = 0x7f03000d;
        public static int actionMenuTextAppearance = 0x7f03000e;
        public static int actionMenuTextColor = 0x7f03000f;
        public static int actionModeBackground = 0x7f030010;
        public static int actionModeCloseButtonStyle = 0x7f030011;
        public static int actionModeCloseContentDescription = 0x7f030012;
        public static int actionModeCloseDrawable = 0x7f030013;
        public static int actionModeCopyDrawable = 0x7f030014;
        public static int actionModeCutDrawable = 0x7f030015;
        public static int actionModeFindDrawable = 0x7f030016;
        public static int actionModePasteDrawable = 0x7f030017;
        public static int actionModePopupWindowStyle = 0x7f030018;
        public static int actionModeSelectAllDrawable = 0x7f030019;
        public static int actionModeShareDrawable = 0x7f03001a;
        public static int actionModeSplitBackground = 0x7f03001b;
        public static int actionModeStyle = 0x7f03001c;
        public static int actionModeTheme = 0x7f03001d;
        public static int actionModeWebSearchDrawable = 0x7f03001e;
        public static int actionOverflowButtonStyle = 0x7f03001f;
        public static int actionOverflowMenuStyle = 0x7f030020;
        public static int actionProviderClass = 0x7f030021;
        public static int actionTextColorAlpha = 0x7f030022;
        public static int actionViewClass = 0x7f030023;
        public static int activeIndicatorLabelPadding = 0x7f030024;
        public static int activityChooserViewStyle = 0x7f030025;
        public static int addElevationShadow = 0x7f030026;
        public static int alertDialogButtonGroupStyle = 0x7f030027;
        public static int alertDialogCenterButtons = 0x7f030028;
        public static int alertDialogStyle = 0x7f030029;
        public static int alertDialogTheme = 0x7f03002a;
        public static int allowStacking = 0x7f03002b;
        public static int alpha = 0x7f03002c;
        public static int alphabeticModifiers = 0x7f03002d;
        public static int altSrc = 0x7f03002e;
        public static int animateMenuItems = 0x7f03002f;
        public static int animateNavigationIcon = 0x7f030030;
        public static int animate_relativeTo = 0x7f030031;
        public static int animationMode = 0x7f030032;
        public static int appBarLayoutStyle = 0x7f030033;
        public static int applyMotionScene = 0x7f030034;
        public static int arcMode = 0x7f030035;
        public static int arrowHeadLength = 0x7f030036;
        public static int arrowShaftLength = 0x7f030037;
        public static int attributeName = 0x7f030038;
        public static int autoAdjustToWithinGrandparentBounds = 0x7f030039;
        public static int autoCompleteTextViewStyle = 0x7f03003a;
        public static int autoShowKeyboard = 0x7f03003b;
        public static int autoSizeMaxTextSize = 0x7f03003c;
        public static int autoSizeMinTextSize = 0x7f03003d;
        public static int autoSizePresetSizes = 0x7f03003e;
        public static int autoSizeStepGranularity = 0x7f03003f;
        public static int autoSizeTextType = 0x7f030040;
        public static int autoTransition = 0x7f030041;
        public static int backHandlingEnabled = 0x7f030042;
        public static int background = 0x7f030043;
        public static int backgroundColor = 0x7f030044;
        public static int backgroundInsetBottom = 0x7f030045;
        public static int backgroundInsetEnd = 0x7f030046;
        public static int backgroundInsetStart = 0x7f030047;
        public static int backgroundInsetTop = 0x7f030048;
        public static int backgroundOverlayColorAlpha = 0x7f030049;
        public static int backgroundSplit = 0x7f03004a;
        public static int backgroundStacked = 0x7f03004b;
        public static int backgroundTint = 0x7f03004c;
        public static int backgroundTintMode = 0x7f03004d;
        public static int badgeGravity = 0x7f03004e;
        public static int badgeHeight = 0x7f03004f;
        public static int badgeRadius = 0x7f030050;
        public static int badgeShapeAppearance = 0x7f030051;
        public static int badgeShapeAppearanceOverlay = 0x7f030052;
        public static int badgeStyle = 0x7f030053;
        public static int badgeText = 0x7f030054;
        public static int badgeTextAppearance = 0x7f030055;
        public static int badgeTextColor = 0x7f030056;
        public static int badgeVerticalPadding = 0x7f030057;
        public static int badgeWidePadding = 0x7f030058;
        public static int badgeWidth = 0x7f030059;
        public static int badgeWithTextHeight = 0x7f03005a;
        public static int badgeWithTextRadius = 0x7f03005b;
        public static int badgeWithTextShapeAppearance = 0x7f03005c;
        public static int badgeWithTextShapeAppearanceOverlay = 0x7f03005d;
        public static int badgeWithTextWidth = 0x7f03005e;
        public static int barLength = 0x7f03005f;
        public static int barrierAllowsGoneWidgets = 0x7f030060;
        public static int barrierDirection = 0x7f030061;
        public static int barrierMargin = 0x7f030062;
        public static int behavior_autoHide = 0x7f030063;
        public static int behavior_autoShrink = 0x7f030064;
        public static int behavior_draggable = 0x7f030065;
        public static int behavior_expandedOffset = 0x7f030066;
        public static int behavior_fitToContents = 0x7f030067;
        public static int behavior_halfExpandedRatio = 0x7f030068;
        public static int behavior_hideable = 0x7f030069;
        public static int behavior_overlapTop = 0x7f03006a;
        public static int behavior_peekHeight = 0x7f03006b;
        public static int behavior_saveFlags = 0x7f03006c;
        public static int behavior_significantVelocityThreshold = 0x7f03006d;
        public static int behavior_skipCollapsed = 0x7f03006e;
        public static int borderWidth = 0x7f03006f;
        public static int borderlessButtonStyle = 0x7f030070;
        public static int bottomAppBarStyle = 0x7f030071;
        public static int bottomInsetScrimEnabled = 0x7f030072;
        public static int bottomNavigationStyle = 0x7f030073;
        public static int bottomSheetDialogTheme = 0x7f030074;
        public static int bottomSheetDragHandleStyle = 0x7f030075;
        public static int bottomSheetStyle = 0x7f030076;
        public static int boxBackgroundColor = 0x7f030077;
        public static int boxBackgroundMode = 0x7f030078;
        public static int boxCollapsedPaddingTop = 0x7f030079;
        public static int boxCornerRadiusBottomEnd = 0x7f03007a;
        public static int boxCornerRadiusBottomStart = 0x7f03007b;
        public static int boxCornerRadiusTopEnd = 0x7f03007c;
        public static int boxCornerRadiusTopStart = 0x7f03007d;
        public static int boxStrokeColor = 0x7f03007e;
        public static int boxStrokeErrorColor = 0x7f03007f;
        public static int boxStrokeWidth = 0x7f030080;
        public static int boxStrokeWidthFocused = 0x7f030081;
        public static int brightness = 0x7f030082;
        public static int buttonBarButtonStyle = 0x7f030083;
        public static int buttonBarNegativeButtonStyle = 0x7f030084;
        public static int buttonBarNeutralButtonStyle = 0x7f030085;
        public static int buttonBarPositiveButtonStyle = 0x7f030086;
        public static int buttonBarStyle = 0x7f030087;
        public static int buttonCompat = 0x7f030088;
        public static int buttonGravity = 0x7f030089;
        public static int buttonIcon = 0x7f03008a;
        public static int buttonIconDimen = 0x7f03008b;
        public static int buttonIconTint = 0x7f03008c;
        public static int buttonIconTintMode = 0x7f03008d;
        public static int buttonPanelSideLayout = 0x7f03008e;
        public static int buttonStyle = 0x7f03008f;
        public static int buttonStyleSmall = 0x7f030090;
        public static int buttonTint = 0x7f030091;
        public static int buttonTintMode = 0x7f030092;
        public static int cardBackgroundColor = 0x7f030093;
        public static int cardCornerRadius = 0x7f030094;
        public static int cardElevation = 0x7f030095;
        public static int cardForegroundColor = 0x7f030096;
        public static int cardMaxElevation = 0x7f030097;
        public static int cardPreventCornerOverlap = 0x7f030098;
        public static int cardUseCompatPadding = 0x7f030099;
        public static int cardViewStyle = 0x7f03009a;
        public static int carousel_alignment = 0x7f03009b;
        public static int centerIfNoTextEnabled = 0x7f03009c;
        public static int chainUseRtl = 0x7f03009d;
        public static int checkMarkCompat = 0x7f03009e;
        public static int checkMarkTint = 0x7f03009f;
        public static int checkMarkTintMode = 0x7f0300a0;
        public static int checkboxStyle = 0x7f0300a1;
        public static int checkedButton = 0x7f0300a2;
        public static int checkedChip = 0x7f0300a3;
        public static int checkedIcon = 0x7f0300a4;
        public static int checkedIconEnabled = 0x7f0300a5;
        public static int checkedIconGravity = 0x7f0300a6;
        public static int checkedIconMargin = 0x7f0300a7;
        public static int checkedIconSize = 0x7f0300a8;
        public static int checkedIconTint = 0x7f0300a9;
        public static int checkedIconVisible = 0x7f0300aa;
        public static int checkedState = 0x7f0300ab;
        public static int checkedTextViewStyle = 0x7f0300ac;
        public static int chipBackgroundColor = 0x7f0300ad;
        public static int chipCornerRadius = 0x7f0300ae;
        public static int chipEndPadding = 0x7f0300af;
        public static int chipGroupStyle = 0x7f0300b0;
        public static int chipIcon = 0x7f0300b1;
        public static int chipIconEnabled = 0x7f0300b2;
        public static int chipIconSize = 0x7f0300b3;
        public static int chipIconTint = 0x7f0300b4;
        public static int chipIconVisible = 0x7f0300b5;
        public static int chipMinHeight = 0x7f0300b6;
        public static int chipMinTouchTargetSize = 0x7f0300b7;
        public static int chipSpacing = 0x7f0300b8;
        public static int chipSpacingHorizontal = 0x7f0300b9;
        public static int chipSpacingVertical = 0x7f0300ba;
        public static int chipStandaloneStyle = 0x7f0300bb;
        public static int chipStartPadding = 0x7f0300bc;
        public static int chipStrokeColor = 0x7f0300bd;
        public static int chipStrokeWidth = 0x7f0300be;
        public static int chipStyle = 0x7f0300bf;
        public static int chipSurfaceColor = 0x7f0300c0;
        public static int circleRadius = 0x7f0300c1;
        public static int circularProgressIndicatorStyle = 0x7f0300c2;
        public static int clickAction = 0x7f0300c3;
        public static int clockFaceBackgroundColor = 0x7f0300c4;
        public static int clockHandColor = 0x7f0300c5;
        public static int clockIcon = 0x7f0300c6;
        public static int clockNumberTextColor = 0x7f0300c7;
        public static int closeIcon = 0x7f0300c8;
        public static int closeIconEnabled = 0x7f0300c9;
        public static int closeIconEndPadding = 0x7f0300ca;
        public static int closeIconSize = 0x7f0300cb;
        public static int closeIconStartPadding = 0x7f0300cc;
        public static int closeIconTint = 0x7f0300cd;
        public static int closeIconVisible = 0x7f0300ce;
        public static int closeItemLayout = 0x7f0300cf;
        public static int collapseContentDescription = 0x7f0300d0;
        public static int collapseIcon = 0x7f0300d1;
        public static int collapsedSize = 0x7f0300d2;
        public static int collapsedTitleGravity = 0x7f0300d3;
        public static int collapsedTitleTextAppearance = 0x7f0300d4;
        public static int collapsedTitleTextColor = 0x7f0300d5;
        public static int collapsingToolbarLayoutLargeSize = 0x7f0300d6;
        public static int collapsingToolbarLayoutLargeStyle = 0x7f0300d7;
        public static int collapsingToolbarLayoutMediumSize = 0x7f0300d8;
        public static int collapsingToolbarLayoutMediumStyle = 0x7f0300d9;
        public static int collapsingToolbarLayoutStyle = 0x7f0300da;
        public static int color = 0x7f0300db;
        public static int colorAccent = 0x7f0300dc;
        public static int colorBackgroundFloating = 0x7f0300dd;
        public static int colorButtonNormal = 0x7f0300de;
        public static int colorContainer = 0x7f0300df;
        public static int colorControlActivated = 0x7f0300e0;
        public static int colorControlHighlight = 0x7f0300e1;
        public static int colorControlNormal = 0x7f0300e2;
        public static int colorError = 0x7f0300e3;
        public static int colorErrorContainer = 0x7f0300e4;
        public static int colorOnBackground = 0x7f0300e5;
        public static int colorOnContainer = 0x7f0300e6;
        public static int colorOnContainerUnchecked = 0x7f0300e7;
        public static int colorOnError = 0x7f0300e8;
        public static int colorOnErrorContainer = 0x7f0300e9;
        public static int colorOnPrimary = 0x7f0300ea;
        public static int colorOnPrimaryContainer = 0x7f0300eb;
        public static int colorOnPrimaryFixed = 0x7f0300ec;
        public static int colorOnPrimaryFixedVariant = 0x7f0300ed;
        public static int colorOnPrimarySurface = 0x7f0300ee;
        public static int colorOnSecondary = 0x7f0300ef;
        public static int colorOnSecondaryContainer = 0x7f0300f0;
        public static int colorOnSecondaryFixed = 0x7f0300f1;
        public static int colorOnSecondaryFixedVariant = 0x7f0300f2;
        public static int colorOnSurface = 0x7f0300f3;
        public static int colorOnSurfaceInverse = 0x7f0300f4;
        public static int colorOnSurfaceVariant = 0x7f0300f5;
        public static int colorOnTertiary = 0x7f0300f6;
        public static int colorOnTertiaryContainer = 0x7f0300f7;
        public static int colorOnTertiaryFixed = 0x7f0300f8;
        public static int colorOnTertiaryFixedVariant = 0x7f0300f9;
        public static int colorOutline = 0x7f0300fa;
        public static int colorOutlineVariant = 0x7f0300fb;
        public static int colorPrimary = 0x7f0300fc;
        public static int colorPrimaryContainer = 0x7f0300fd;
        public static int colorPrimaryDark = 0x7f0300fe;
        public static int colorPrimaryFixed = 0x7f0300ff;
        public static int colorPrimaryFixedDim = 0x7f030100;
        public static int colorPrimaryInverse = 0x7f030101;
        public static int colorPrimarySurface = 0x7f030102;
        public static int colorPrimaryVariant = 0x7f030103;
        public static int colorSecondary = 0x7f030104;
        public static int colorSecondaryContainer = 0x7f030105;
        public static int colorSecondaryFixed = 0x7f030106;
        public static int colorSecondaryFixedDim = 0x7f030107;
        public static int colorSecondaryVariant = 0x7f030108;
        public static int colorSurface = 0x7f030109;
        public static int colorSurfaceBright = 0x7f03010a;
        public static int colorSurfaceContainer = 0x7f03010b;
        public static int colorSurfaceContainerHigh = 0x7f03010c;
        public static int colorSurfaceContainerHighest = 0x7f03010d;
        public static int colorSurfaceContainerLow = 0x7f03010e;
        public static int colorSurfaceContainerLowest = 0x7f03010f;
        public static int colorSurfaceDim = 0x7f030110;
        public static int colorSurfaceInverse = 0x7f030111;
        public static int colorSurfaceVariant = 0x7f030112;
        public static int colorSwitchThumbNormal = 0x7f030113;
        public static int colorTertiary = 0x7f030114;
        public static int colorTertiaryContainer = 0x7f030115;
        public static int colorTertiaryFixed = 0x7f030116;
        public static int colorTertiaryFixedDim = 0x7f030117;
        public static int commitIcon = 0x7f030118;
        public static int compatShadowEnabled = 0x7f030119;
        public static int constraintSet = 0x7f03011a;
        public static int constraintSetEnd = 0x7f03011b;
        public static int constraintSetStart = 0x7f03011c;
        public static int constraint_referenced_ids = 0x7f03011d;
        public static int constraints = 0x7f03011e;
        public static int content = 0x7f03011f;
        public static int contentDescription = 0x7f030120;
        public static int contentInsetEnd = 0x7f030121;
        public static int contentInsetEndWithActions = 0x7f030122;
        public static int contentInsetLeft = 0x7f030123;
        public static int contentInsetRight = 0x7f030124;
        public static int contentInsetStart = 0x7f030125;
        public static int contentInsetStartWithNavigation = 0x7f030126;
        public static int contentPadding = 0x7f030127;
        public static int contentPaddingBottom = 0x7f030128;
        public static int contentPaddingEnd = 0x7f030129;
        public static int contentPaddingLeft = 0x7f03012a;
        public static int contentPaddingRight = 0x7f03012b;
        public static int contentPaddingStart = 0x7f03012c;
        public static int contentPaddingTop = 0x7f03012d;
        public static int contentScrim = 0x7f03012e;
        public static int contrast = 0x7f03012f;
        public static int controlBackground = 0x7f030130;
        public static int coordinatorLayoutStyle = 0x7f030131;
        public static int coplanarSiblingViewId = 0x7f030132;
        public static int cornerFamily = 0x7f030133;
        public static int cornerFamilyBottomLeft = 0x7f030134;
        public static int cornerFamilyBottomRight = 0x7f030135;
        public static int cornerFamilyTopLeft = 0x7f030136;
        public static int cornerFamilyTopRight = 0x7f030137;
        public static int cornerRadius = 0x7f030138;
        public static int cornerSize = 0x7f030139;
        public static int cornerSizeBottomLeft = 0x7f03013a;
        public static int cornerSizeBottomRight = 0x7f03013b;
        public static int cornerSizeTopLeft = 0x7f03013c;
        public static int cornerSizeTopRight = 0x7f03013d;
        public static int counterEnabled = 0x7f03013e;
        public static int counterMaxLength = 0x7f03013f;
        public static int counterOverflowTextAppearance = 0x7f030140;
        public static int counterOverflowTextColor = 0x7f030141;
        public static int counterTextAppearance = 0x7f030142;
        public static int counterTextColor = 0x7f030143;
        public static int crossfade = 0x7f030144;
        public static int currentState = 0x7f030145;
        public static int cursorColor = 0x7f030146;
        public static int cursorErrorColor = 0x7f030147;
        public static int curveFit = 0x7f030148;
        public static int customBoolean = 0x7f030149;
        public static int customColorDrawableValue = 0x7f03014a;
        public static int customColorValue = 0x7f03014b;
        public static int customDimension = 0x7f03014c;
        public static int customFloatValue = 0x7f03014d;
        public static int customIntegerValue = 0x7f03014e;
        public static int customNavigationLayout = 0x7f03014f;
        public static int customPixelDimension = 0x7f030150;
        public static int customStringValue = 0x7f030151;
        public static int dayInvalidStyle = 0x7f030152;
        public static int daySelectedStyle = 0x7f030153;
        public static int dayStyle = 0x7f030154;
        public static int dayTodayStyle = 0x7f030155;
        public static int defaultDuration = 0x7f030156;
        public static int defaultMarginsEnabled = 0x7f030157;
        public static int defaultQueryHint = 0x7f030158;
        public static int defaultScrollFlagsEnabled = 0x7f030159;
        public static int defaultState = 0x7f03015a;
        public static int deltaPolarAngle = 0x7f03015b;
        public static int deltaPolarRadius = 0x7f03015c;
        public static int deriveConstraintsFrom = 0x7f03015d;
        public static int dialogCornerRadius = 0x7f03015e;
        public static int dialogPreferredPadding = 0x7f03015f;
        public static int dialogTheme = 0x7f030160;
        public static int displayOptions = 0x7f030161;
        public static int divider = 0x7f030162;
        public static int dividerColor = 0x7f030163;
        public static int dividerHorizontal = 0x7f030164;
        public static int dividerInsetEnd = 0x7f030165;
        public static int dividerInsetStart = 0x7f030166;
        public static int dividerPadding = 0x7f030167;
        public static int dividerThickness = 0x7f030168;
        public static int dividerVertical = 0x7f030169;
        public static int dragDirection = 0x7f03016a;
        public static int dragScale = 0x7f03016b;
        public static int dragThreshold = 0x7f03016c;
        public static int drawPath = 0x7f03016d;
        public static int drawableBottomCompat = 0x7f03016e;
        public static int drawableEndCompat = 0x7f03016f;
        public static int drawableLeftCompat = 0x7f030170;
        public static int drawableRightCompat = 0x7f030171;
        public static int drawableSize = 0x7f030172;
        public static int drawableStartCompat = 0x7f030173;
        public static int drawableTint = 0x7f030174;
        public static int drawableTintMode = 0x7f030175;
        public static int drawableTopCompat = 0x7f030176;
        public static int drawerArrowStyle = 0x7f030177;
        public static int drawerLayoutCornerSize = 0x7f030178;
        public static int drawerLayoutStyle = 0x7f030179;
        public static int dropDownBackgroundTint = 0x7f03017a;
        public static int dropDownListViewStyle = 0x7f03017b;
        public static int dropdownListPreferredItemHeight = 0x7f03017c;
        public static int duration = 0x7f03017d;
        public static int dynamicColorThemeOverlay = 0x7f03017e;
        public static int editTextBackground = 0x7f03017f;
        public static int editTextColor = 0x7f030180;
        public static int editTextStyle = 0x7f030181;
        public static int elevation = 0x7f030182;
        public static int elevationOverlayAccentColor = 0x7f030183;
        public static int elevationOverlayColor = 0x7f030184;
        public static int elevationOverlayEnabled = 0x7f030185;
        public static int emojiCompatEnabled = 0x7f030186;
        public static int enableEdgeToEdge = 0x7f030187;
        public static int endIconCheckable = 0x7f030188;
        public static int endIconContentDescription = 0x7f030189;
        public static int endIconDrawable = 0x7f03018a;
        public static int endIconMinSize = 0x7f03018b;
        public static int endIconMode = 0x7f03018c;
        public static int endIconScaleType = 0x7f03018d;
        public static int endIconTint = 0x7f03018e;
        public static int endIconTintMode = 0x7f03018f;
        public static int enforceMaterialTheme = 0x7f030190;
        public static int enforceTextAppearance = 0x7f030191;
        public static int ensureMinTouchTargetSize = 0x7f030192;
        public static int errorAccessibilityLabel = 0x7f030193;
        public static int errorAccessibilityLiveRegion = 0x7f030194;
        public static int errorContentDescription = 0x7f030195;
        public static int errorEnabled = 0x7f030196;
        public static int errorIconDrawable = 0x7f030197;
        public static int errorIconTint = 0x7f030198;
        public static int errorIconTintMode = 0x7f030199;
        public static int errorShown = 0x7f03019a;
        public static int errorTextAppearance = 0x7f03019b;
        public static int errorTextColor = 0x7f03019c;
        public static int expandActivityOverflowButtonDrawable = 0x7f03019d;
        public static int expanded = 0x7f03019e;
        public static int expandedHintEnabled = 0x7f03019f;
        public static int expandedTitleGravity = 0x7f0301a0;
        public static int expandedTitleMargin = 0x7f0301a1;
        public static int expandedTitleMarginBottom = 0x7f0301a2;
        public static int expandedTitleMarginEnd = 0x7f0301a3;
        public static int expandedTitleMarginStart = 0x7f0301a4;
        public static int expandedTitleMarginTop = 0x7f0301a5;
        public static int expandedTitleTextAppearance = 0x7f0301a6;
        public static int expandedTitleTextColor = 0x7f0301a7;
        public static int extendMotionSpec = 0x7f0301a8;
        public static int extendStrategy = 0x7f0301a9;
        public static int extendedFloatingActionButtonPrimaryStyle = 0x7f0301aa;
        public static int extendedFloatingActionButtonSecondaryStyle = 0x7f0301ab;
        public static int extendedFloatingActionButtonStyle = 0x7f0301ac;
        public static int extendedFloatingActionButtonSurfaceStyle = 0x7f0301ad;
        public static int extendedFloatingActionButtonTertiaryStyle = 0x7f0301ae;
        public static int extraMultilineHeightEnabled = 0x7f0301af;
        public static int fabAlignmentMode = 0x7f0301b0;
        public static int fabAlignmentModeEndMargin = 0x7f0301b1;
        public static int fabAnchorMode = 0x7f0301b2;
        public static int fabAnimationMode = 0x7f0301b3;
        public static int fabCradleMargin = 0x7f0301b4;
        public static int fabCradleRoundedCornerRadius = 0x7f0301b5;
        public static int fabCradleVerticalOffset = 0x7f0301b6;
        public static int fabCustomSize = 0x7f0301b7;
        public static int fabSize = 0x7f0301b8;
        public static int fastScrollEnabled = 0x7f0301b9;
        public static int fastScrollHorizontalThumbDrawable = 0x7f0301ba;
        public static int fastScrollHorizontalTrackDrawable = 0x7f0301bb;
        public static int fastScrollVerticalThumbDrawable = 0x7f0301bc;
        public static int fastScrollVerticalTrackDrawable = 0x7f0301bd;
        public static int firstBaselineToTopHeight = 0x7f0301be;
        public static int floatingActionButtonLargePrimaryStyle = 0x7f0301bf;
        public static int floatingActionButtonLargeSecondaryStyle = 0x7f0301c0;
        public static int floatingActionButtonLargeStyle = 0x7f0301c1;
        public static int floatingActionButtonLargeSurfaceStyle = 0x7f0301c2;
        public static int floatingActionButtonLargeTertiaryStyle = 0x7f0301c3;
        public static int floatingActionButtonPrimaryStyle = 0x7f0301c4;
        public static int floatingActionButtonSecondaryStyle = 0x7f0301c5;
        public static int floatingActionButtonSmallPrimaryStyle = 0x7f0301c6;
        public static int floatingActionButtonSmallSecondaryStyle = 0x7f0301c7;
        public static int floatingActionButtonSmallStyle = 0x7f0301c8;
        public static int floatingActionButtonSmallSurfaceStyle = 0x7f0301c9;
        public static int floatingActionButtonSmallTertiaryStyle = 0x7f0301ca;
        public static int floatingActionButtonStyle = 0x7f0301cb;
        public static int floatingActionButtonSurfaceStyle = 0x7f0301cc;
        public static int floatingActionButtonTertiaryStyle = 0x7f0301cd;
        public static int flow_firstHorizontalBias = 0x7f0301ce;
        public static int flow_firstHorizontalStyle = 0x7f0301cf;
        public static int flow_firstVerticalBias = 0x7f0301d0;
        public static int flow_firstVerticalStyle = 0x7f0301d1;
        public static int flow_horizontalAlign = 0x7f0301d2;
        public static int flow_horizontalBias = 0x7f0301d3;
        public static int flow_horizontalGap = 0x7f0301d4;
        public static int flow_horizontalStyle = 0x7f0301d5;
        public static int flow_lastHorizontalBias = 0x7f0301d6;
        public static int flow_lastHorizontalStyle = 0x7f0301d7;
        public static int flow_lastVerticalBias = 0x7f0301d8;
        public static int flow_lastVerticalStyle = 0x7f0301d9;
        public static int flow_maxElementsWrap = 0x7f0301da;
        public static int flow_padding = 0x7f0301db;
        public static int flow_verticalAlign = 0x7f0301dc;
        public static int flow_verticalBias = 0x7f0301dd;
        public static int flow_verticalGap = 0x7f0301de;
        public static int flow_verticalStyle = 0x7f0301df;
        public static int flow_wrapMode = 0x7f0301e0;
        public static int font = 0x7f0301e1;
        public static int fontFamily = 0x7f0301e2;
        public static int fontProviderAuthority = 0x7f0301e3;
        public static int fontProviderCerts = 0x7f0301e4;
        public static int fontProviderFetchStrategy = 0x7f0301e5;
        public static int fontProviderFetchTimeout = 0x7f0301e6;
        public static int fontProviderPackage = 0x7f0301e7;
        public static int fontProviderQuery = 0x7f0301e8;
        public static int fontProviderSystemFontFamily = 0x7f0301e9;
        public static int fontStyle = 0x7f0301ea;
        public static int fontVariationSettings = 0x7f0301eb;
        public static int fontWeight = 0x7f0301ec;
        public static int forceApplySystemWindowInsetTop = 0x7f0301ed;
        public static int forceDefaultNavigationOnClickListener = 0x7f0301ee;
        public static int foregroundInsidePadding = 0x7f0301ef;
        public static int framePosition = 0x7f0301f0;
        public static int gapBetweenBars = 0x7f0301f1;
        public static int gestureInsetBottomIgnored = 0x7f0301f2;
        public static int goIcon = 0x7f0301f3;
        public static int haloColor = 0x7f0301f4;
        public static int haloRadius = 0x7f0301f5;
        public static int headerLayout = 0x7f0301f6;
        public static int height = 0x7f0301f7;
        public static int helperText = 0x7f0301f8;
        public static int helperTextEnabled = 0x7f0301f9;
        public static int helperTextTextAppearance = 0x7f0301fa;
        public static int helperTextTextColor = 0x7f0301fb;
        public static int hideAnimationBehavior = 0x7f0301fc;
        public static int hideMotionSpec = 0x7f0301fd;
        public static int hideNavigationIcon = 0x7f0301fe;
        public static int hideOnContentScroll = 0x7f0301ff;
        public static int hideOnScroll = 0x7f030200;
        public static int hintAnimationEnabled = 0x7f030201;
        public static int hintEnabled = 0x7f030202;
        public static int hintTextAppearance = 0x7f030203;
        public static int hintTextColor = 0x7f030204;
        public static int homeAsUpIndicator = 0x7f030205;
        public static int homeLayout = 0x7f030206;
        public static int horizontalOffset = 0x7f030207;
        public static int horizontalOffsetWithText = 0x7f030208;
        public static int hoveredFocusedTranslationZ = 0x7f030209;
        public static int icon = 0x7f03020a;
        public static int iconEndPadding = 0x7f03020b;
        public static int iconGravity = 0x7f03020c;
        public static int iconPadding = 0x7f03020d;
        public static int iconSize = 0x7f03020e;
        public static int iconStartPadding = 0x7f03020f;
        public static int iconTint = 0x7f030210;
        public static int iconTintMode = 0x7f030211;
        public static int iconifiedByDefault = 0x7f030212;
        public static int imageButtonStyle = 0x7f030213;
        public static int indeterminateAnimationType = 0x7f030214;
        public static int indeterminateProgressStyle = 0x7f030215;
        public static int indicatorColor = 0x7f030216;
        public static int indicatorDirectionCircular = 0x7f030217;
        public static int indicatorDirectionLinear = 0x7f030218;
        public static int indicatorInset = 0x7f030219;
        public static int indicatorSize = 0x7f03021a;
        public static int indicatorTrackGapSize = 0x7f03021b;
        public static int initialActivityCount = 0x7f03021c;
        public static int insetForeground = 0x7f03021d;
        public static int isLightTheme = 0x7f03021e;
        public static int isMaterial3DynamicColorApplied = 0x7f03021f;
        public static int isMaterial3Theme = 0x7f030220;
        public static int isMaterialTheme = 0x7f030221;
        public static int itemActiveIndicatorStyle = 0x7f030222;
        public static int itemBackground = 0x7f030223;
        public static int itemFillColor = 0x7f030224;
        public static int itemHorizontalPadding = 0x7f030225;
        public static int itemHorizontalTranslationEnabled = 0x7f030226;
        public static int itemIconPadding = 0x7f030227;
        public static int itemIconSize = 0x7f030228;
        public static int itemIconTint = 0x7f030229;
        public static int itemMaxLines = 0x7f03022a;
        public static int itemMinHeight = 0x7f03022b;
        public static int itemPadding = 0x7f03022c;
        public static int itemPaddingBottom = 0x7f03022d;
        public static int itemPaddingTop = 0x7f03022e;
        public static int itemRippleColor = 0x7f03022f;
        public static int itemShapeAppearance = 0x7f030230;
        public static int itemShapeAppearanceOverlay = 0x7f030231;
        public static int itemShapeFillColor = 0x7f030232;
        public static int itemShapeInsetBottom = 0x7f030233;
        public static int itemShapeInsetEnd = 0x7f030234;
        public static int itemShapeInsetStart = 0x7f030235;
        public static int itemShapeInsetTop = 0x7f030236;
        public static int itemSpacing = 0x7f030237;
        public static int itemStrokeColor = 0x7f030238;
        public static int itemStrokeWidth = 0x7f030239;
        public static int itemTextAppearance = 0x7f03023a;
        public static int itemTextAppearanceActive = 0x7f03023b;
        public static int itemTextAppearanceActiveBoldEnabled = 0x7f03023c;
        public static int itemTextAppearanceInactive = 0x7f03023d;
        public static int itemTextColor = 0x7f03023e;
        public static int itemVerticalPadding = 0x7f03023f;
        public static int keyPositionType = 0x7f030240;
        public static int keyboardIcon = 0x7f030241;
        public static int keylines = 0x7f030242;
        public static int lStar = 0x7f030243;
        public static int labelBehavior = 0x7f030244;
        public static int labelStyle = 0x7f030245;
        public static int labelVisibilityMode = 0x7f030246;
        public static int largeFontVerticalOffsetAdjustment = 0x7f030247;
        public static int lastBaselineToBottomHeight = 0x7f030248;
        public static int lastItemDecorated = 0x7f030249;
        public static int layout = 0x7f03024a;
        public static int layoutDescription = 0x7f03024b;
        public static int layoutDuringTransition = 0x7f03024c;
        public static int layoutManager = 0x7f03024d;
        public static int layout_anchor = 0x7f03024e;
        public static int layout_anchorGravity = 0x7f03024f;
        public static int layout_behavior = 0x7f030250;
        public static int layout_collapseMode = 0x7f030251;
        public static int layout_collapseParallaxMultiplier = 0x7f030252;
        public static int layout_constrainedHeight = 0x7f030253;
        public static int layout_constrainedWidth = 0x7f030254;
        public static int layout_constraintBaseline_creator = 0x7f030255;
        public static int layout_constraintBaseline_toBaselineOf = 0x7f030256;
        public static int layout_constraintBottom_creator = 0x7f030257;
        public static int layout_constraintBottom_toBottomOf = 0x7f030258;
        public static int layout_constraintBottom_toTopOf = 0x7f030259;
        public static int layout_constraintCircle = 0x7f03025a;
        public static int layout_constraintCircleAngle = 0x7f03025b;
        public static int layout_constraintCircleRadius = 0x7f03025c;
        public static int layout_constraintDimensionRatio = 0x7f03025d;
        public static int layout_constraintEnd_toEndOf = 0x7f03025e;
        public static int layout_constraintEnd_toStartOf = 0x7f03025f;
        public static int layout_constraintGuide_begin = 0x7f030260;
        public static int layout_constraintGuide_end = 0x7f030261;
        public static int layout_constraintGuide_percent = 0x7f030262;
        public static int layout_constraintHeight_default = 0x7f030263;
        public static int layout_constraintHeight_max = 0x7f030264;
        public static int layout_constraintHeight_min = 0x7f030265;
        public static int layout_constraintHeight_percent = 0x7f030266;
        public static int layout_constraintHorizontal_bias = 0x7f030267;
        public static int layout_constraintHorizontal_chainStyle = 0x7f030268;
        public static int layout_constraintHorizontal_weight = 0x7f030269;
        public static int layout_constraintLeft_creator = 0x7f03026a;
        public static int layout_constraintLeft_toLeftOf = 0x7f03026b;
        public static int layout_constraintLeft_toRightOf = 0x7f03026c;
        public static int layout_constraintRight_creator = 0x7f03026d;
        public static int layout_constraintRight_toLeftOf = 0x7f03026e;
        public static int layout_constraintRight_toRightOf = 0x7f03026f;
        public static int layout_constraintStart_toEndOf = 0x7f030270;
        public static int layout_constraintStart_toStartOf = 0x7f030271;
        public static int layout_constraintTag = 0x7f030272;
        public static int layout_constraintTop_creator = 0x7f030273;
        public static int layout_constraintTop_toBottomOf = 0x7f030274;
        public static int layout_constraintTop_toTopOf = 0x7f030275;
        public static int layout_constraintVertical_bias = 0x7f030276;
        public static int layout_constraintVertical_chainStyle = 0x7f030277;
        public static int layout_constraintVertical_weight = 0x7f030278;
        public static int layout_constraintWidth_default = 0x7f030279;
        public static int layout_constraintWidth_max = 0x7f03027a;
        public static int layout_constraintWidth_min = 0x7f03027b;
        public static int layout_constraintWidth_percent = 0x7f03027c;
        public static int layout_dodgeInsetEdges = 0x7f03027d;
        public static int layout_editor_absoluteX = 0x7f03027e;
        public static int layout_editor_absoluteY = 0x7f03027f;
        public static int layout_goneMarginBottom = 0x7f030280;
        public static int layout_goneMarginEnd = 0x7f030281;
        public static int layout_goneMarginLeft = 0x7f030282;
        public static int layout_goneMarginRight = 0x7f030283;
        public static int layout_goneMarginStart = 0x7f030284;
        public static int layout_goneMarginTop = 0x7f030285;
        public static int layout_insetEdge = 0x7f030286;
        public static int layout_keyline = 0x7f030287;
        public static int layout_optimizationLevel = 0x7f030288;
        public static int layout_scrollEffect = 0x7f030289;
        public static int layout_scrollFlags = 0x7f03028a;
        public static int layout_scrollInterpolator = 0x7f03028b;
        public static int liftOnScroll = 0x7f03028c;
        public static int liftOnScrollColor = 0x7f03028d;
        public static int liftOnScrollTargetViewId = 0x7f03028e;
        public static int limitBoundsTo = 0x7f03028f;
        public static int lineHeight = 0x7f030290;
        public static int lineSpacing = 0x7f030291;
        public static int linearProgressIndicatorStyle = 0x7f030292;
        public static int listChoiceBackgroundIndicator = 0x7f030293;
        public static int listChoiceIndicatorMultipleAnimated = 0x7f030294;
        public static int listChoiceIndicatorSingleAnimated = 0x7f030295;
        public static int listDividerAlertDialog = 0x7f030296;
        public static int listItemLayout = 0x7f030297;
        public static int listLayout = 0x7f030298;
        public static int listMenuViewStyle = 0x7f030299;
        public static int listPopupWindowStyle = 0x7f03029a;
        public static int listPreferredItemHeight = 0x7f03029b;
        public static int listPreferredItemHeightLarge = 0x7f03029c;
        public static int listPreferredItemHeightSmall = 0x7f03029d;
        public static int listPreferredItemPaddingEnd = 0x7f03029e;
        public static int listPreferredItemPaddingLeft = 0x7f03029f;
        public static int listPreferredItemPaddingRight = 0x7f0302a0;
        public static int listPreferredItemPaddingStart = 0x7f0302a1;
        public static int logo = 0x7f0302a2;
        public static int logoAdjustViewBounds = 0x7f0302a3;
        public static int logoDescription = 0x7f0302a4;
        public static int logoScaleType = 0x7f0302a5;
        public static int marginHorizontal = 0x7f0302a6;
        public static int marginLeftSystemWindowInsets = 0x7f0302a7;
        public static int marginRightSystemWindowInsets = 0x7f0302a8;
        public static int marginTopSystemWindowInsets = 0x7f0302a9;
        public static int materialAlertDialogBodyTextStyle = 0x7f0302aa;
        public static int materialAlertDialogButtonSpacerVisibility = 0x7f0302ab;
        public static int materialAlertDialogTheme = 0x7f0302ac;
        public static int materialAlertDialogTitleIconStyle = 0x7f0302ad;
        public static int materialAlertDialogTitlePanelStyle = 0x7f0302ae;
        public static int materialAlertDialogTitleTextStyle = 0x7f0302af;
        public static int materialButtonOutlinedStyle = 0x7f0302b0;
        public static int materialButtonStyle = 0x7f0302b1;
        public static int materialButtonToggleGroupStyle = 0x7f0302b2;
        public static int materialCalendarDay = 0x7f0302b3;
        public static int materialCalendarDayOfWeekLabel = 0x7f0302b4;
        public static int materialCalendarFullscreenTheme = 0x7f0302b5;
        public static int materialCalendarHeaderCancelButton = 0x7f0302b6;
        public static int materialCalendarHeaderConfirmButton = 0x7f0302b7;
        public static int materialCalendarHeaderDivider = 0x7f0302b8;
        public static int materialCalendarHeaderLayout = 0x7f0302b9;
        public static int materialCalendarHeaderSelection = 0x7f0302ba;
        public static int materialCalendarHeaderTitle = 0x7f0302bb;
        public static int materialCalendarHeaderToggleButton = 0x7f0302bc;
        public static int materialCalendarMonth = 0x7f0302bd;
        public static int materialCalendarMonthNavigationButton = 0x7f0302be;
        public static int materialCalendarStyle = 0x7f0302bf;
        public static int materialCalendarTheme = 0x7f0302c0;
        public static int materialCalendarYearNavigationButton = 0x7f0302c1;
        public static int materialCardViewElevatedStyle = 0x7f0302c2;
        public static int materialCardViewFilledStyle = 0x7f0302c3;
        public static int materialCardViewOutlinedStyle = 0x7f0302c4;
        public static int materialCardViewStyle = 0x7f0302c5;
        public static int materialCircleRadius = 0x7f0302c6;
        public static int materialClockStyle = 0x7f0302c7;
        public static int materialDisplayDividerStyle = 0x7f0302c8;
        public static int materialDividerHeavyStyle = 0x7f0302c9;
        public static int materialDividerStyle = 0x7f0302ca;
        public static int materialIconButtonFilledStyle = 0x7f0302cb;
        public static int materialIconButtonFilledTonalStyle = 0x7f0302cc;
        public static int materialIconButtonOutlinedStyle = 0x7f0302cd;
        public static int materialIconButtonStyle = 0x7f0302ce;
        public static int materialSearchBarStyle = 0x7f0302cf;
        public static int materialSearchViewPrefixStyle = 0x7f0302d0;
        public static int materialSearchViewStyle = 0x7f0302d1;
        public static int materialSearchViewToolbarHeight = 0x7f0302d2;
        public static int materialSearchViewToolbarStyle = 0x7f0302d3;
        public static int materialSwitchStyle = 0x7f0302d4;
        public static int materialThemeOverlay = 0x7f0302d5;
        public static int materialTimePickerStyle = 0x7f0302d6;
        public static int materialTimePickerTheme = 0x7f0302d7;
        public static int materialTimePickerTitleStyle = 0x7f0302d8;
        public static int maxAcceleration = 0x7f0302d9;
        public static int maxActionInlineWidth = 0x7f0302da;
        public static int maxButtonHeight = 0x7f0302db;
        public static int maxCharacterCount = 0x7f0302dc;
        public static int maxHeight = 0x7f0302dd;
        public static int maxImageSize = 0x7f0302de;
        public static int maxLines = 0x7f0302df;
        public static int maxNumber = 0x7f0302e0;
        public static int maxVelocity = 0x7f0302e1;
        public static int maxWidth = 0x7f0302e2;
        public static int measureWithLargestChild = 0x7f0302e3;
        public static int menu = 0x7f0302e4;
        public static int menuAlignmentMode = 0x7f0302e5;
        public static int menuGravity = 0x7f0302e6;
        public static int minHeight = 0x7f0302e7;
        public static int minHideDelay = 0x7f0302e8;
        public static int minSeparation = 0x7f0302e9;
        public static int minTouchTargetSize = 0x7f0302ea;
        public static int minWidth = 0x7f0302eb;
        public static int mock_diagonalsColor = 0x7f0302ec;
        public static int mock_label = 0x7f0302ed;
        public static int mock_labelBackgroundColor = 0x7f0302ee;
        public static int mock_labelColor = 0x7f0302ef;
        public static int mock_showDiagonals = 0x7f0302f0;
        public static int mock_showLabel = 0x7f0302f1;
        public static int motionDebug = 0x7f0302f2;
        public static int motionDurationExtraLong1 = 0x7f0302f3;
        public static int motionDurationExtraLong2 = 0x7f0302f4;
        public static int motionDurationExtraLong3 = 0x7f0302f5;
        public static int motionDurationExtraLong4 = 0x7f0302f6;
        public static int motionDurationLong1 = 0x7f0302f7;
        public static int motionDurationLong2 = 0x7f0302f8;
        public static int motionDurationLong3 = 0x7f0302f9;
        public static int motionDurationLong4 = 0x7f0302fa;
        public static int motionDurationMedium1 = 0x7f0302fb;
        public static int motionDurationMedium2 = 0x7f0302fc;
        public static int motionDurationMedium3 = 0x7f0302fd;
        public static int motionDurationMedium4 = 0x7f0302fe;
        public static int motionDurationShort1 = 0x7f0302ff;
        public static int motionDurationShort2 = 0x7f030300;
        public static int motionDurationShort3 = 0x7f030301;
        public static int motionDurationShort4 = 0x7f030302;
        public static int motionEasingAccelerated = 0x7f030303;
        public static int motionEasingDecelerated = 0x7f030304;
        public static int motionEasingEmphasized = 0x7f030305;
        public static int motionEasingEmphasizedAccelerateInterpolator = 0x7f030306;
        public static int motionEasingEmphasizedDecelerateInterpolator = 0x7f030307;
        public static int motionEasingEmphasizedInterpolator = 0x7f030308;
        public static int motionEasingLinear = 0x7f030309;
        public static int motionEasingLinearInterpolator = 0x7f03030a;
        public static int motionEasingStandard = 0x7f03030b;
        public static int motionEasingStandardAccelerateInterpolator = 0x7f03030c;
        public static int motionEasingStandardDecelerateInterpolator = 0x7f03030d;
        public static int motionEasingStandardInterpolator = 0x7f03030e;
        public static int motionInterpolator = 0x7f03030f;
        public static int motionPath = 0x7f030310;
        public static int motionPathRotate = 0x7f030311;
        public static int motionProgress = 0x7f030312;
        public static int motionStagger = 0x7f030313;
        public static int motionTarget = 0x7f030314;
        public static int motion_postLayoutCollision = 0x7f030315;
        public static int motion_triggerOnCollision = 0x7f030316;
        public static int moveWhenScrollAtTop = 0x7f030317;
        public static int multiChoiceItemLayout = 0x7f030318;
        public static int navigationContentDescription = 0x7f030319;
        public static int navigationIcon = 0x7f03031a;
        public static int navigationIconTint = 0x7f03031b;
        public static int navigationMode = 0x7f03031c;
        public static int navigationRailStyle = 0x7f03031d;
        public static int navigationViewStyle = 0x7f03031e;
        public static int nestedScrollFlags = 0x7f03031f;
        public static int nestedScrollViewStyle = 0x7f030320;
        public static int nestedScrollable = 0x7f030321;
        public static int number = 0x7f030322;
        public static int numericModifiers = 0x7f030323;
        public static int offsetAlignmentMode = 0x7f030324;
        public static int onCross = 0x7f030325;
        public static int onHide = 0x7f030326;
        public static int onNegativeCross = 0x7f030327;
        public static int onPositiveCross = 0x7f030328;
        public static int onShow = 0x7f030329;
        public static int onTouchUp = 0x7f03032a;
        public static int overlapAnchor = 0x7f03032b;
        public static int overlay = 0x7f03032c;
        public static int paddingBottomNoButtons = 0x7f03032d;
        public static int paddingBottomSystemWindowInsets = 0x7f03032e;
        public static int paddingEnd = 0x7f03032f;
        public static int paddingLeftSystemWindowInsets = 0x7f030330;
        public static int paddingRightSystemWindowInsets = 0x7f030331;
        public static int paddingStart = 0x7f030332;
        public static int paddingStartSystemWindowInsets = 0x7f030333;
        public static int paddingTopNoTitle = 0x7f030334;
        public static int paddingTopSystemWindowInsets = 0x7f030335;
        public static int panelBackground = 0x7f030336;
        public static int panelMenuListTheme = 0x7f030337;
        public static int panelMenuListWidth = 0x7f030338;
        public static int passwordToggleContentDescription = 0x7f030339;
        public static int passwordToggleDrawable = 0x7f03033a;
        public static int passwordToggleEnabled = 0x7f03033b;
        public static int passwordToggleTint = 0x7f03033c;
        public static int passwordToggleTintMode = 0x7f03033d;
        public static int pathMotionArc = 0x7f03033e;
        public static int path_percent = 0x7f03033f;
        public static int percentHeight = 0x7f030340;
        public static int percentWidth = 0x7f030341;
        public static int percentX = 0x7f030342;
        public static int percentY = 0x7f030343;
        public static int perpendicularPath_percent = 0x7f030344;
        public static int pivotAnchor = 0x7f030345;
        public static int placeholderText = 0x7f030346;
        public static int placeholderTextAppearance = 0x7f030347;
        public static int placeholderTextColor = 0x7f030348;
        public static int placeholder_emptyVisibility = 0x7f030349;
        public static int popupMenuBackground = 0x7f03034a;
        public static int popupMenuStyle = 0x7f03034b;
        public static int popupTheme = 0x7f03034c;
        public static int popupWindowStyle = 0x7f03034d;
        public static int prefixText = 0x7f03034e;
        public static int prefixTextAppearance = 0x7f03034f;
        public static int prefixTextColor = 0x7f030350;
        public static int preserveIconSpacing = 0x7f030351;
        public static int pressedTranslationZ = 0x7f030352;
        public static int progressBarPadding = 0x7f030353;
        public static int progressBarStyle = 0x7f030354;
        public static int queryBackground = 0x7f030355;
        public static int queryHint = 0x7f030356;
        public static int queryPatterns = 0x7f030357;
        public static int radioButtonStyle = 0x7f030358;
        public static int rangeFillColor = 0x7f030359;
        public static int ratingBarStyle = 0x7f03035a;
        public static int ratingBarStyleIndicator = 0x7f03035b;
        public static int ratingBarStyleSmall = 0x7f03035c;
        public static int recyclerViewStyle = 0x7f03035d;
        public static int region_heightLessThan = 0x7f03035e;
        public static int region_heightMoreThan = 0x7f03035f;
        public static int region_widthLessThan = 0x7f030360;
        public static int region_widthMoreThan = 0x7f030361;
        public static int removeEmbeddedFabElevation = 0x7f030362;
        public static int reverseLayout = 0x7f030363;
        public static int rippleColor = 0x7f030364;
        public static int round = 0x7f030365;
        public static int roundPercent = 0x7f030366;
        public static int saturation = 0x7f030367;
        public static int scrimAnimationDuration = 0x7f030368;
        public static int scrimBackground = 0x7f030369;
        public static int scrimVisibleHeightTrigger = 0x7f03036a;
        public static int searchHintIcon = 0x7f03036b;
        public static int searchIcon = 0x7f03036c;
        public static int searchPrefixText = 0x7f03036d;
        public static int searchViewStyle = 0x7f03036e;
        public static int seekBarStyle = 0x7f03036f;
        public static int selectableItemBackground = 0x7f030370;
        public static int selectableItemBackgroundBorderless = 0x7f030371;
        public static int selectionRequired = 0x7f030372;
        public static int selectorSize = 0x7f030373;
        public static int shapeAppearance = 0x7f030374;
        public static int shapeAppearanceCornerExtraLarge = 0x7f030375;
        public static int shapeAppearanceCornerExtraSmall = 0x7f030376;
        public static int shapeAppearanceCornerLarge = 0x7f030377;
        public static int shapeAppearanceCornerMedium = 0x7f030378;
        public static int shapeAppearanceCornerSmall = 0x7f030379;
        public static int shapeAppearanceLargeComponent = 0x7f03037a;
        public static int shapeAppearanceMediumComponent = 0x7f03037b;
        public static int shapeAppearanceOverlay = 0x7f03037c;
        public static int shapeAppearanceSmallComponent = 0x7f03037d;
        public static int shapeCornerFamily = 0x7f03037e;
        public static int shortcutMatchRequired = 0x7f03037f;
        public static int shouldRemoveExpandedCorners = 0x7f030380;
        public static int showAnimationBehavior = 0x7f030381;
        public static int showAsAction = 0x7f030382;
        public static int showDelay = 0x7f030383;
        public static int showDividers = 0x7f030384;
        public static int showMarker = 0x7f030385;
        public static int showMotionSpec = 0x7f030386;
        public static int showPaths = 0x7f030387;
        public static int showText = 0x7f030388;
        public static int showTitle = 0x7f030389;
        public static int shrinkMotionSpec = 0x7f03038a;
        public static int sideSheetDialogTheme = 0x7f03038b;
        public static int sideSheetModalStyle = 0x7f03038c;
        public static int simpleItemLayout = 0x7f03038d;
        public static int simpleItemSelectedColor = 0x7f03038e;
        public static int simpleItemSelectedRippleColor = 0x7f03038f;
        public static int simpleItems = 0x7f030390;
        public static int singleChoiceItemLayout = 0x7f030391;
        public static int singleLine = 0x7f030392;
        public static int singleSelection = 0x7f030393;
        public static int sizePercent = 0x7f030394;
        public static int sliderStyle = 0x7f030395;
        public static int snackbarButtonStyle = 0x7f030396;
        public static int snackbarStyle = 0x7f030397;
        public static int snackbarTextViewStyle = 0x7f030398;
        public static int spanCount = 0x7f030399;
        public static int spinBars = 0x7f03039a;
        public static int spinnerDropDownItemStyle = 0x7f03039b;
        public static int spinnerStyle = 0x7f03039c;
        public static int splitTrack = 0x7f03039d;
        public static int srcCompat = 0x7f03039e;
        public static int stackFromEnd = 0x7f03039f;
        public static int staggered = 0x7f0303a0;
        public static int startIconCheckable = 0x7f0303a1;
        public static int startIconContentDescription = 0x7f0303a2;
        public static int startIconDrawable = 0x7f0303a3;
        public static int startIconMinSize = 0x7f0303a4;
        public static int startIconScaleType = 0x7f0303a5;
        public static int startIconTint = 0x7f0303a6;
        public static int startIconTintMode = 0x7f0303a7;
        public static int state_above_anchor = 0x7f0303a8;
        public static int state_collapsed = 0x7f0303a9;
        public static int state_collapsible = 0x7f0303aa;
        public static int state_dragged = 0x7f0303ab;
        public static int state_error = 0x7f0303ac;
        public static int state_indeterminate = 0x7f0303ad;
        public static int state_liftable = 0x7f0303ae;
        public static int state_lifted = 0x7f0303af;
        public static int state_with_icon = 0x7f0303b0;
        public static int statusBarBackground = 0x7f0303b1;
        public static int statusBarForeground = 0x7f0303b2;
        public static int statusBarScrim = 0x7f0303b3;
        public static int strokeColor = 0x7f0303b4;
        public static int strokeWidth = 0x7f0303b5;
        public static int subMenuArrow = 0x7f0303b6;
        public static int subheaderColor = 0x7f0303b7;
        public static int subheaderInsetEnd = 0x7f0303b8;
        public static int subheaderInsetStart = 0x7f0303b9;
        public static int subheaderTextAppearance = 0x7f0303ba;
        public static int submitBackground = 0x7f0303bb;
        public static int subtitle = 0x7f0303bc;
        public static int subtitleCentered = 0x7f0303bd;
        public static int subtitleTextAppearance = 0x7f0303be;
        public static int subtitleTextColor = 0x7f0303bf;
        public static int subtitleTextStyle = 0x7f0303c0;
        public static int suffixText = 0x7f0303c1;
        public static int suffixTextAppearance = 0x7f0303c2;
        public static int suffixTextColor = 0x7f0303c3;
        public static int suggestionRowLayout = 0x7f0303c4;
        public static int switchMinWidth = 0x7f0303c5;
        public static int switchPadding = 0x7f0303c6;
        public static int switchStyle = 0x7f0303c7;
        public static int switchTextAppearance = 0x7f0303c8;
        public static int tabBackground = 0x7f0303c9;
        public static int tabContentStart = 0x7f0303ca;
        public static int tabGravity = 0x7f0303cb;
        public static int tabIconTint = 0x7f0303cc;
        public static int tabIconTintMode = 0x7f0303cd;
        public static int tabIndicator = 0x7f0303ce;
        public static int tabIndicatorAnimationDuration = 0x7f0303cf;
        public static int tabIndicatorAnimationMode = 0x7f0303d0;
        public static int tabIndicatorColor = 0x7f0303d1;
        public static int tabIndicatorFullWidth = 0x7f0303d2;
        public static int tabIndicatorGravity = 0x7f0303d3;
        public static int tabIndicatorHeight = 0x7f0303d4;
        public static int tabInlineLabel = 0x7f0303d5;
        public static int tabMaxWidth = 0x7f0303d6;
        public static int tabMinWidth = 0x7f0303d7;
        public static int tabMode = 0x7f0303d8;
        public static int tabPadding = 0x7f0303d9;
        public static int tabPaddingBottom = 0x7f0303da;
        public static int tabPaddingEnd = 0x7f0303db;
        public static int tabPaddingStart = 0x7f0303dc;
        public static int tabPaddingTop = 0x7f0303dd;
        public static int tabRippleColor = 0x7f0303de;
        public static int tabSecondaryStyle = 0x7f0303df;
        public static int tabSelectedTextAppearance = 0x7f0303e0;
        public static int tabSelectedTextColor = 0x7f0303e1;
        public static int tabStyle = 0x7f0303e2;
        public static int tabTextAppearance = 0x7f0303e3;
        public static int tabTextColor = 0x7f0303e4;
        public static int tabUnboundedRipple = 0x7f0303e5;
        public static int targetId = 0x7f0303e6;
        public static int telltales_tailColor = 0x7f0303e7;
        public static int telltales_tailScale = 0x7f0303e8;
        public static int telltales_velocityMode = 0x7f0303e9;
        public static int textAllCaps = 0x7f0303ea;
        public static int textAppearanceBody1 = 0x7f0303eb;
        public static int textAppearanceBody2 = 0x7f0303ec;
        public static int textAppearanceBodyLarge = 0x7f0303ed;
        public static int textAppearanceBodyMedium = 0x7f0303ee;
        public static int textAppearanceBodySmall = 0x7f0303ef;
        public static int textAppearanceButton = 0x7f0303f0;
        public static int textAppearanceCaption = 0x7f0303f1;
        public static int textAppearanceDisplayLarge = 0x7f0303f2;
        public static int textAppearanceDisplayMedium = 0x7f0303f3;
        public static int textAppearanceDisplaySmall = 0x7f0303f4;
        public static int textAppearanceHeadline1 = 0x7f0303f5;
        public static int textAppearanceHeadline2 = 0x7f0303f6;
        public static int textAppearanceHeadline3 = 0x7f0303f7;
        public static int textAppearanceHeadline4 = 0x7f0303f8;
        public static int textAppearanceHeadline5 = 0x7f0303f9;
        public static int textAppearanceHeadline6 = 0x7f0303fa;
        public static int textAppearanceHeadlineLarge = 0x7f0303fb;
        public static int textAppearanceHeadlineMedium = 0x7f0303fc;
        public static int textAppearanceHeadlineSmall = 0x7f0303fd;
        public static int textAppearanceLabelLarge = 0x7f0303fe;
        public static int textAppearanceLabelMedium = 0x7f0303ff;
        public static int textAppearanceLabelSmall = 0x7f030400;
        public static int textAppearanceLargePopupMenu = 0x7f030401;
        public static int textAppearanceLineHeightEnabled = 0x7f030402;
        public static int textAppearanceListItem = 0x7f030403;
        public static int textAppearanceListItemSecondary = 0x7f030404;
        public static int textAppearanceListItemSmall = 0x7f030405;
        public static int textAppearanceOverline = 0x7f030406;
        public static int textAppearancePopupMenuHeader = 0x7f030407;
        public static int textAppearanceSearchResultSubtitle = 0x7f030408;
        public static int textAppearanceSearchResultTitle = 0x7f030409;
        public static int textAppearanceSmallPopupMenu = 0x7f03040a;
        public static int textAppearanceSubtitle1 = 0x7f03040b;
        public static int textAppearanceSubtitle2 = 0x7f03040c;
        public static int textAppearanceTitleLarge = 0x7f03040d;
        public static int textAppearanceTitleMedium = 0x7f03040e;
        public static int textAppearanceTitleSmall = 0x7f03040f;
        public static int textColorAlertDialogListItem = 0x7f030410;
        public static int textColorSearchUrl = 0x7f030411;
        public static int textEndPadding = 0x7f030412;
        public static int textInputFilledDenseStyle = 0x7f030413;
        public static int textInputFilledExposedDropdownMenuStyle = 0x7f030414;
        public static int textInputFilledStyle = 0x7f030415;
        public static int textInputLayoutFocusedRectEnabled = 0x7f030416;
        public static int textInputOutlinedDenseStyle = 0x7f030417;
        public static int textInputOutlinedExposedDropdownMenuStyle = 0x7f030418;
        public static int textInputOutlinedStyle = 0x7f030419;
        public static int textInputStyle = 0x7f03041a;
        public static int textLocale = 0x7f03041b;
        public static int textStartPadding = 0x7f03041c;
        public static int theme = 0x7f03041d;
        public static int thickness = 0x7f03041e;
        public static int thumbColor = 0x7f03041f;
        public static int thumbElevation = 0x7f030420;
        public static int thumbHeight = 0x7f030421;
        public static int thumbIcon = 0x7f030422;
        public static int thumbIconSize = 0x7f030423;
        public static int thumbIconTint = 0x7f030424;
        public static int thumbIconTintMode = 0x7f030425;
        public static int thumbRadius = 0x7f030426;
        public static int thumbStrokeColor = 0x7f030427;
        public static int thumbStrokeWidth = 0x7f030428;
        public static int thumbTextPadding = 0x7f030429;
        public static int thumbTint = 0x7f03042a;
        public static int thumbTintMode = 0x7f03042b;
        public static int thumbTrackGapSize = 0x7f03042c;
        public static int thumbWidth = 0x7f03042d;
        public static int tickColor = 0x7f03042e;
        public static int tickColorActive = 0x7f03042f;
        public static int tickColorInactive = 0x7f030430;
        public static int tickMark = 0x7f030431;
        public static int tickMarkTint = 0x7f030432;
        public static int tickMarkTintMode = 0x7f030433;
        public static int tickRadiusActive = 0x7f030434;
        public static int tickRadiusInactive = 0x7f030435;
        public static int tickVisible = 0x7f030436;
        public static int tint = 0x7f030437;
        public static int tintMode = 0x7f030438;
        public static int tintNavigationIcon = 0x7f030439;
        public static int title = 0x7f03043a;
        public static int titleCentered = 0x7f03043b;
        public static int titleCollapseMode = 0x7f03043c;
        public static int titleEnabled = 0x7f03043d;
        public static int titleMargin = 0x7f03043e;
        public static int titleMarginBottom = 0x7f03043f;
        public static int titleMarginEnd = 0x7f030440;
        public static int titleMarginStart = 0x7f030441;
        public static int titleMarginTop = 0x7f030442;
        public static int titleMargins = 0x7f030443;
        public static int titlePositionInterpolator = 0x7f030444;
        public static int titleTextAppearance = 0x7f030445;
        public static int titleTextColor = 0x7f030446;
        public static int titleTextEllipsize = 0x7f030447;
        public static int titleTextStyle = 0x7f030448;
        public static int toggleCheckedStateOnClick = 0x7f030449;
        public static int toolbarId = 0x7f03044a;
        public static int toolbarNavigationButtonStyle = 0x7f03044b;
        public static int toolbarStyle = 0x7f03044c;
        public static int toolbarSurfaceStyle = 0x7f03044d;
        public static int tooltipForegroundColor = 0x7f03044e;
        public static int tooltipFrameBackground = 0x7f03044f;
        public static int tooltipStyle = 0x7f030450;
        public static int tooltipText = 0x7f030451;
        public static int topInsetScrimEnabled = 0x7f030452;
        public static int touchAnchorId = 0x7f030453;
        public static int touchAnchorSide = 0x7f030454;
        public static int touchRegionId = 0x7f030455;
        public static int track = 0x7f030456;
        public static int trackColor = 0x7f030457;
        public static int trackColorActive = 0x7f030458;
        public static int trackColorInactive = 0x7f030459;
        public static int trackCornerRadius = 0x7f03045a;
        public static int trackDecoration = 0x7f03045b;
        public static int trackDecorationTint = 0x7f03045c;
        public static int trackDecorationTintMode = 0x7f03045d;
        public static int trackHeight = 0x7f03045e;
        public static int trackInsideCornerSize = 0x7f03045f;
        public static int trackStopIndicatorSize = 0x7f030460;
        public static int trackThickness = 0x7f030461;
        public static int trackTint = 0x7f030462;
        public static int trackTintMode = 0x7f030463;
        public static int transitionDisable = 0x7f030464;
        public static int transitionEasing = 0x7f030465;
        public static int transitionFlags = 0x7f030466;
        public static int transitionPathRotate = 0x7f030467;
        public static int transitionShapeAppearance = 0x7f030468;
        public static int triggerId = 0x7f030469;
        public static int triggerReceiver = 0x7f03046a;
        public static int triggerSlack = 0x7f03046b;
        public static int ttcIndex = 0x7f03046c;
        public static int useCompatPadding = 0x7f03046d;
        public static int useDrawerArrowDrawable = 0x7f03046e;
        public static int useMaterialThemeColors = 0x7f03046f;
        public static int values = 0x7f030470;
        public static int verticalOffset = 0x7f030471;
        public static int verticalOffsetWithText = 0x7f030472;
        public static int viewInflaterClass = 0x7f030473;
        public static int visibilityMode = 0x7f030474;
        public static int voiceIcon = 0x7f030475;
        public static int warmth = 0x7f030476;
        public static int waveDecay = 0x7f030477;
        public static int waveOffset = 0x7f030478;
        public static int wavePeriod = 0x7f030479;
        public static int waveShape = 0x7f03047a;
        public static int waveVariesBy = 0x7f03047b;
        public static int windowActionBar = 0x7f03047c;
        public static int windowActionBarOverlay = 0x7f03047d;
        public static int windowActionModeOverlay = 0x7f03047e;
        public static int windowFixedHeightMajor = 0x7f03047f;
        public static int windowFixedHeightMinor = 0x7f030480;
        public static int windowFixedWidthMajor = 0x7f030481;
        public static int windowFixedWidthMinor = 0x7f030482;
        public static int windowMinWidthMajor = 0x7f030483;
        public static int windowMinWidthMinor = 0x7f030484;
        public static int windowNoTitle = 0x7f030485;
        public static int yearSelectedStyle = 0x7f030486;
        public static int yearStyle = 0x7f030487;
        public static int yearTodayStyle = 0x7f030488;

        private attr() {
        }
    }

    public static final class bool {
        public static int abc_action_bar_embed_tabs = 0x7f040000;
        public static int abc_config_actionMenuItemAllCaps = 0x7f040001;
        public static int mtrl_btn_textappearance_all_caps = 0x7f040005;

        /* JADX INFO: Added by JADX */
        public static final int enable_system_alarm_service_default = 0x7f040002;

        /* JADX INFO: Added by JADX */
        public static final int enable_system_foreground_service_default = 0x7f040003;

        /* JADX INFO: Added by JADX */
        public static final int enable_system_job_service_default = 0x7f040004;

        /* JADX INFO: Added by JADX */
        public static final int workmanager_test_configuration = 0x7f040006;

        private bool() {
        }
    }

    public static final class color {
        public static int abc_background_cache_hint_selector_material_dark = 0x7f050000;
        public static int abc_background_cache_hint_selector_material_light = 0x7f050001;
        public static int abc_btn_colored_borderless_text_material = 0x7f050002;
        public static int abc_btn_colored_text_material = 0x7f050003;
        public static int abc_color_highlight_material = 0x7f050004;
        public static int abc_decor_view_status_guard = 0x7f050005;
        public static int abc_decor_view_status_guard_light = 0x7f050006;
        public static int abc_hint_foreground_material_dark = 0x7f050007;
        public static int abc_hint_foreground_material_light = 0x7f050008;
        public static int abc_primary_text_disable_only_material_dark = 0x7f050009;
        public static int abc_primary_text_disable_only_material_light = 0x7f05000a;
        public static int abc_primary_text_material_dark = 0x7f05000b;
        public static int abc_primary_text_material_light = 0x7f05000c;
        public static int abc_search_url_text = 0x7f05000d;
        public static int abc_search_url_text_normal = 0x7f05000e;
        public static int abc_search_url_text_pressed = 0x7f05000f;
        public static int abc_search_url_text_selected = 0x7f050010;
        public static int abc_secondary_text_material_dark = 0x7f050011;
        public static int abc_secondary_text_material_light = 0x7f050012;
        public static int abc_tint_btn_checkable = 0x7f050013;
        public static int abc_tint_default = 0x7f050014;
        public static int abc_tint_edittext = 0x7f050015;
        public static int abc_tint_seek_thumb = 0x7f050016;
        public static int abc_tint_spinner = 0x7f050017;
        public static int abc_tint_switch_track = 0x7f050018;
        public static int accent_material_dark = 0x7f050019;
        public static int accent_material_light = 0x7f05001a;
        public static int androidx_core_ripple_material_light = 0x7f05001b;
        public static int androidx_core_secondary_text_default_material_light = 0x7f05001c;
        public static int background_floating_material_dark = 0x7f05001d;
        public static int background_floating_material_light = 0x7f05001e;
        public static int background_material_dark = 0x7f05001f;
        public static int background_material_light = 0x7f050020;
        public static int bright_foreground_disabled_material_dark = 0x7f050021;
        public static int bright_foreground_disabled_material_light = 0x7f050022;
        public static int bright_foreground_inverse_material_dark = 0x7f050023;
        public static int bright_foreground_inverse_material_light = 0x7f050024;
        public static int bright_foreground_material_dark = 0x7f050025;
        public static int bright_foreground_material_light = 0x7f050026;
        public static int button_material_dark = 0x7f050027;
        public static int button_material_light = 0x7f050028;
        public static int call_notification_answer_color = 0x7f050029;
        public static int call_notification_decline_color = 0x7f05002a;
        public static int cardview_dark_background = 0x7f05002b;
        public static int cardview_light_background = 0x7f05002c;
        public static int cardview_shadow_end_color = 0x7f05002d;
        public static int cardview_shadow_start_color = 0x7f05002e;
        public static int design_bottom_navigation_shadow_color = 0x7f05002f;
        public static int design_box_stroke_color = 0x7f050030;
        public static int design_dark_default_color_background = 0x7f050031;
        public static int design_dark_default_color_error = 0x7f050032;
        public static int design_dark_default_color_on_background = 0x7f050033;
        public static int design_dark_default_color_on_error = 0x7f050034;
        public static int design_dark_default_color_on_primary = 0x7f050035;
        public static int design_dark_default_color_on_secondary = 0x7f050036;
        public static int design_dark_default_color_on_surface = 0x7f050037;
        public static int design_dark_default_color_primary = 0x7f050038;
        public static int design_dark_default_color_primary_dark = 0x7f050039;
        public static int design_dark_default_color_primary_variant = 0x7f05003a;
        public static int design_dark_default_color_secondary = 0x7f05003b;
        public static int design_dark_default_color_secondary_variant = 0x7f05003c;
        public static int design_dark_default_color_surface = 0x7f05003d;
        public static int design_default_color_background = 0x7f05003e;
        public static int design_default_color_error = 0x7f05003f;
        public static int design_default_color_on_background = 0x7f050040;
        public static int design_default_color_on_error = 0x7f050041;
        public static int design_default_color_on_primary = 0x7f050042;
        public static int design_default_color_on_secondary = 0x7f050043;
        public static int design_default_color_on_surface = 0x7f050044;
        public static int design_default_color_primary = 0x7f050045;
        public static int design_default_color_primary_dark = 0x7f050046;
        public static int design_default_color_primary_variant = 0x7f050047;
        public static int design_default_color_secondary = 0x7f050048;
        public static int design_default_color_secondary_variant = 0x7f050049;
        public static int design_default_color_surface = 0x7f05004a;
        public static int design_error = 0x7f05004b;
        public static int design_fab_shadow_end_color = 0x7f05004c;
        public static int design_fab_shadow_mid_color = 0x7f05004d;
        public static int design_fab_shadow_start_color = 0x7f05004e;
        public static int design_fab_stroke_end_inner_color = 0x7f05004f;
        public static int design_fab_stroke_end_outer_color = 0x7f050050;
        public static int design_fab_stroke_top_inner_color = 0x7f050051;
        public static int design_fab_stroke_top_outer_color = 0x7f050052;
        public static int design_icon_tint = 0x7f050053;
        public static int design_snackbar_background_color = 0x7f050054;
        public static int dim_foreground_disabled_material_dark = 0x7f050055;
        public static int dim_foreground_disabled_material_light = 0x7f050056;
        public static int dim_foreground_material_dark = 0x7f050057;
        public static int dim_foreground_material_light = 0x7f050058;
        public static int error_color_material_dark = 0x7f050059;
        public static int error_color_material_light = 0x7f05005a;
        public static int foreground_material_dark = 0x7f05005b;
        public static int foreground_material_light = 0x7f05005c;
        public static int highlighted_text_material_dark = 0x7f05005d;
        public static int highlighted_text_material_light = 0x7f05005e;
        public static int m3_appbar_overlay_color = 0x7f05005f;
        public static int m3_assist_chip_icon_tint_color = 0x7f050060;
        public static int m3_assist_chip_stroke_color = 0x7f050061;
        public static int m3_bottom_sheet_drag_handle_color = 0x7f050062;
        public static int m3_button_background_color_selector = 0x7f050063;
        public static int m3_button_foreground_color_selector = 0x7f050064;
        public static int m3_button_outline_color_selector = 0x7f050065;
        public static int m3_button_ripple_color = 0x7f050066;
        public static int m3_button_ripple_color_selector = 0x7f050067;
        public static int m3_calendar_item_disabled_text = 0x7f050068;
        public static int m3_calendar_item_stroke_color = 0x7f050069;
        public static int m3_card_foreground_color = 0x7f05006a;
        public static int m3_card_ripple_color = 0x7f05006b;
        public static int m3_card_stroke_color = 0x7f05006c;
        public static int m3_checkbox_button_icon_tint = 0x7f05006d;
        public static int m3_checkbox_button_tint = 0x7f05006e;
        public static int m3_chip_assist_text_color = 0x7f05006f;
        public static int m3_chip_background_color = 0x7f050070;
        public static int m3_chip_ripple_color = 0x7f050071;
        public static int m3_chip_stroke_color = 0x7f050072;
        public static int m3_chip_text_color = 0x7f050073;
        public static int m3_dark_default_color_primary_text = 0x7f050074;
        public static int m3_dark_default_color_secondary_text = 0x7f050075;
        public static int m3_dark_highlighted_text = 0x7f050076;
        public static int m3_dark_hint_foreground = 0x7f050077;
        public static int m3_dark_primary_text_disable_only = 0x7f050078;
        public static int m3_default_color_primary_text = 0x7f050079;
        public static int m3_default_color_secondary_text = 0x7f05007a;
        public static int m3_dynamic_dark_default_color_primary_text = 0x7f05007b;
        public static int m3_dynamic_dark_default_color_secondary_text = 0x7f05007c;
        public static int m3_dynamic_dark_highlighted_text = 0x7f05007d;
        public static int m3_dynamic_dark_hint_foreground = 0x7f05007e;
        public static int m3_dynamic_dark_primary_text_disable_only = 0x7f05007f;
        public static int m3_dynamic_default_color_primary_text = 0x7f050080;
        public static int m3_dynamic_default_color_secondary_text = 0x7f050081;
        public static int m3_dynamic_highlighted_text = 0x7f050082;
        public static int m3_dynamic_hint_foreground = 0x7f050083;
        public static int m3_dynamic_primary_text_disable_only = 0x7f050084;
        public static int m3_efab_ripple_color_selector = 0x7f050085;
        public static int m3_elevated_chip_background_color = 0x7f050086;
        public static int m3_fab_efab_background_color_selector = 0x7f050087;
        public static int m3_fab_efab_foreground_color_selector = 0x7f050088;
        public static int m3_fab_ripple_color_selector = 0x7f050089;
        public static int m3_filled_icon_button_container_color_selector = 0x7f05008a;
        public static int m3_highlighted_text = 0x7f05008b;
        public static int m3_hint_foreground = 0x7f05008c;
        public static int m3_icon_button_icon_color_selector = 0x7f05008d;
        public static int m3_navigation_bar_item_with_indicator_icon_tint = 0x7f05008e;
        public static int m3_navigation_bar_item_with_indicator_label_tint = 0x7f05008f;
        public static int m3_navigation_bar_ripple_color_selector = 0x7f050090;
        public static int m3_navigation_item_background_color = 0x7f050091;
        public static int m3_navigation_item_icon_tint = 0x7f050092;
        public static int m3_navigation_item_ripple_color = 0x7f050093;
        public static int m3_navigation_item_text_color = 0x7f050094;
        public static int m3_navigation_rail_item_with_indicator_icon_tint = 0x7f050095;
        public static int m3_navigation_rail_item_with_indicator_label_tint = 0x7f050096;
        public static int m3_navigation_rail_ripple_color_selector = 0x7f050097;
        public static int m3_popupmenu_overlay_color = 0x7f050098;
        public static int m3_primary_text_disable_only = 0x7f050099;
        public static int m3_radiobutton_button_tint = 0x7f05009a;
        public static int m3_radiobutton_ripple_tint = 0x7f05009b;
        public static int m3_ref_palette_black = 0x7f05009c;
        public static int m3_ref_palette_dynamic_neutral0 = 0x7f05009d;
        public static int m3_ref_palette_dynamic_neutral10 = 0x7f05009e;
        public static int m3_ref_palette_dynamic_neutral100 = 0x7f05009f;
        public static int m3_ref_palette_dynamic_neutral12 = 0x7f0500a0;
        public static int m3_ref_palette_dynamic_neutral17 = 0x7f0500a1;
        public static int m3_ref_palette_dynamic_neutral20 = 0x7f0500a2;
        public static int m3_ref_palette_dynamic_neutral22 = 0x7f0500a3;
        public static int m3_ref_palette_dynamic_neutral24 = 0x7f0500a4;
        public static int m3_ref_palette_dynamic_neutral30 = 0x7f0500a5;
        public static int m3_ref_palette_dynamic_neutral4 = 0x7f0500a6;
        public static int m3_ref_palette_dynamic_neutral40 = 0x7f0500a7;
        public static int m3_ref_palette_dynamic_neutral50 = 0x7f0500a8;
        public static int m3_ref_palette_dynamic_neutral6 = 0x7f0500a9;
        public static int m3_ref_palette_dynamic_neutral60 = 0x7f0500aa;
        public static int m3_ref_palette_dynamic_neutral70 = 0x7f0500ab;
        public static int m3_ref_palette_dynamic_neutral80 = 0x7f0500ac;
        public static int m3_ref_palette_dynamic_neutral87 = 0x7f0500ad;
        public static int m3_ref_palette_dynamic_neutral90 = 0x7f0500ae;
        public static int m3_ref_palette_dynamic_neutral92 = 0x7f0500af;
        public static int m3_ref_palette_dynamic_neutral94 = 0x7f0500b0;
        public static int m3_ref_palette_dynamic_neutral95 = 0x7f0500b1;
        public static int m3_ref_palette_dynamic_neutral96 = 0x7f0500b2;
        public static int m3_ref_palette_dynamic_neutral98 = 0x7f0500b3;
        public static int m3_ref_palette_dynamic_neutral99 = 0x7f0500b4;
        public static int m3_ref_palette_dynamic_neutral_variant0 = 0x7f0500b5;
        public static int m3_ref_palette_dynamic_neutral_variant10 = 0x7f0500b6;
        public static int m3_ref_palette_dynamic_neutral_variant100 = 0x7f0500b7;
        public static int m3_ref_palette_dynamic_neutral_variant12 = 0x7f0500b8;
        public static int m3_ref_palette_dynamic_neutral_variant17 = 0x7f0500b9;
        public static int m3_ref_palette_dynamic_neutral_variant20 = 0x7f0500ba;
        public static int m3_ref_palette_dynamic_neutral_variant22 = 0x7f0500bb;
        public static int m3_ref_palette_dynamic_neutral_variant24 = 0x7f0500bc;
        public static int m3_ref_palette_dynamic_neutral_variant30 = 0x7f0500bd;
        public static int m3_ref_palette_dynamic_neutral_variant4 = 0x7f0500be;
        public static int m3_ref_palette_dynamic_neutral_variant40 = 0x7f0500bf;
        public static int m3_ref_palette_dynamic_neutral_variant50 = 0x7f0500c0;
        public static int m3_ref_palette_dynamic_neutral_variant6 = 0x7f0500c1;
        public static int m3_ref_palette_dynamic_neutral_variant60 = 0x7f0500c2;
        public static int m3_ref_palette_dynamic_neutral_variant70 = 0x7f0500c3;
        public static int m3_ref_palette_dynamic_neutral_variant80 = 0x7f0500c4;
        public static int m3_ref_palette_dynamic_neutral_variant87 = 0x7f0500c5;
        public static int m3_ref_palette_dynamic_neutral_variant90 = 0x7f0500c6;
        public static int m3_ref_palette_dynamic_neutral_variant92 = 0x7f0500c7;
        public static int m3_ref_palette_dynamic_neutral_variant94 = 0x7f0500c8;
        public static int m3_ref_palette_dynamic_neutral_variant95 = 0x7f0500c9;
        public static int m3_ref_palette_dynamic_neutral_variant96 = 0x7f0500ca;
        public static int m3_ref_palette_dynamic_neutral_variant98 = 0x7f0500cb;
        public static int m3_ref_palette_dynamic_neutral_variant99 = 0x7f0500cc;
        public static int m3_ref_palette_dynamic_primary0 = 0x7f0500cd;
        public static int m3_ref_palette_dynamic_primary10 = 0x7f0500ce;
        public static int m3_ref_palette_dynamic_primary100 = 0x7f0500cf;
        public static int m3_ref_palette_dynamic_primary20 = 0x7f0500d0;
        public static int m3_ref_palette_dynamic_primary30 = 0x7f0500d1;
        public static int m3_ref_palette_dynamic_primary40 = 0x7f0500d2;
        public static int m3_ref_palette_dynamic_primary50 = 0x7f0500d3;
        public static int m3_ref_palette_dynamic_primary60 = 0x7f0500d4;
        public static int m3_ref_palette_dynamic_primary70 = 0x7f0500d5;
        public static int m3_ref_palette_dynamic_primary80 = 0x7f0500d6;
        public static int m3_ref_palette_dynamic_primary90 = 0x7f0500d7;
        public static int m3_ref_palette_dynamic_primary95 = 0x7f0500d8;
        public static int m3_ref_palette_dynamic_primary99 = 0x7f0500d9;
        public static int m3_ref_palette_dynamic_secondary0 = 0x7f0500da;
        public static int m3_ref_palette_dynamic_secondary10 = 0x7f0500db;
        public static int m3_ref_palette_dynamic_secondary100 = 0x7f0500dc;
        public static int m3_ref_palette_dynamic_secondary20 = 0x7f0500dd;
        public static int m3_ref_palette_dynamic_secondary30 = 0x7f0500de;
        public static int m3_ref_palette_dynamic_secondary40 = 0x7f0500df;
        public static int m3_ref_palette_dynamic_secondary50 = 0x7f0500e0;
        public static int m3_ref_palette_dynamic_secondary60 = 0x7f0500e1;
        public static int m3_ref_palette_dynamic_secondary70 = 0x7f0500e2;
        public static int m3_ref_palette_dynamic_secondary80 = 0x7f0500e3;
        public static int m3_ref_palette_dynamic_secondary90 = 0x7f0500e4;
        public static int m3_ref_palette_dynamic_secondary95 = 0x7f0500e5;
        public static int m3_ref_palette_dynamic_secondary99 = 0x7f0500e6;
        public static int m3_ref_palette_dynamic_tertiary0 = 0x7f0500e7;
        public static int m3_ref_palette_dynamic_tertiary10 = 0x7f0500e8;
        public static int m3_ref_palette_dynamic_tertiary100 = 0x7f0500e9;
        public static int m3_ref_palette_dynamic_tertiary20 = 0x7f0500ea;
        public static int m3_ref_palette_dynamic_tertiary30 = 0x7f0500eb;
        public static int m3_ref_palette_dynamic_tertiary40 = 0x7f0500ec;
        public static int m3_ref_palette_dynamic_tertiary50 = 0x7f0500ed;
        public static int m3_ref_palette_dynamic_tertiary60 = 0x7f0500ee;
        public static int m3_ref_palette_dynamic_tertiary70 = 0x7f0500ef;
        public static int m3_ref_palette_dynamic_tertiary80 = 0x7f0500f0;
        public static int m3_ref_palette_dynamic_tertiary90 = 0x7f0500f1;
        public static int m3_ref_palette_dynamic_tertiary95 = 0x7f0500f2;
        public static int m3_ref_palette_dynamic_tertiary99 = 0x7f0500f3;
        public static int m3_ref_palette_error0 = 0x7f0500f4;
        public static int m3_ref_palette_error10 = 0x7f0500f5;
        public static int m3_ref_palette_error100 = 0x7f0500f6;
        public static int m3_ref_palette_error20 = 0x7f0500f7;
        public static int m3_ref_palette_error30 = 0x7f0500f8;
        public static int m3_ref_palette_error40 = 0x7f0500f9;
        public static int m3_ref_palette_error50 = 0x7f0500fa;
        public static int m3_ref_palette_error60 = 0x7f0500fb;
        public static int m3_ref_palette_error70 = 0x7f0500fc;
        public static int m3_ref_palette_error80 = 0x7f0500fd;
        public static int m3_ref_palette_error90 = 0x7f0500fe;
        public static int m3_ref_palette_error95 = 0x7f0500ff;
        public static int m3_ref_palette_error99 = 0x7f050100;
        public static int m3_ref_palette_neutral0 = 0x7f050101;
        public static int m3_ref_palette_neutral10 = 0x7f050102;
        public static int m3_ref_palette_neutral100 = 0x7f050103;
        public static int m3_ref_palette_neutral12 = 0x7f050104;
        public static int m3_ref_palette_neutral17 = 0x7f050105;
        public static int m3_ref_palette_neutral20 = 0x7f050106;
        public static int m3_ref_palette_neutral22 = 0x7f050107;
        public static int m3_ref_palette_neutral24 = 0x7f050108;
        public static int m3_ref_palette_neutral30 = 0x7f050109;
        public static int m3_ref_palette_neutral4 = 0x7f05010a;
        public static int m3_ref_palette_neutral40 = 0x7f05010b;
        public static int m3_ref_palette_neutral50 = 0x7f05010c;
        public static int m3_ref_palette_neutral6 = 0x7f05010d;
        public static int m3_ref_palette_neutral60 = 0x7f05010e;
        public static int m3_ref_palette_neutral70 = 0x7f05010f;
        public static int m3_ref_palette_neutral80 = 0x7f050110;
        public static int m3_ref_palette_neutral87 = 0x7f050111;
        public static int m3_ref_palette_neutral90 = 0x7f050112;
        public static int m3_ref_palette_neutral92 = 0x7f050113;
        public static int m3_ref_palette_neutral94 = 0x7f050114;
        public static int m3_ref_palette_neutral95 = 0x7f050115;
        public static int m3_ref_palette_neutral96 = 0x7f050116;
        public static int m3_ref_palette_neutral98 = 0x7f050117;
        public static int m3_ref_palette_neutral99 = 0x7f050118;
        public static int m3_ref_palette_neutral_variant0 = 0x7f050119;
        public static int m3_ref_palette_neutral_variant10 = 0x7f05011a;
        public static int m3_ref_palette_neutral_variant100 = 0x7f05011b;
        public static int m3_ref_palette_neutral_variant20 = 0x7f05011c;
        public static int m3_ref_palette_neutral_variant30 = 0x7f05011d;
        public static int m3_ref_palette_neutral_variant40 = 0x7f05011e;
        public static int m3_ref_palette_neutral_variant50 = 0x7f05011f;
        public static int m3_ref_palette_neutral_variant60 = 0x7f050120;
        public static int m3_ref_palette_neutral_variant70 = 0x7f050121;
        public static int m3_ref_palette_neutral_variant80 = 0x7f050122;
        public static int m3_ref_palette_neutral_variant90 = 0x7f050123;
        public static int m3_ref_palette_neutral_variant95 = 0x7f050124;
        public static int m3_ref_palette_neutral_variant99 = 0x7f050125;
        public static int m3_ref_palette_primary0 = 0x7f050126;
        public static int m3_ref_palette_primary10 = 0x7f050127;
        public static int m3_ref_palette_primary100 = 0x7f050128;
        public static int m3_ref_palette_primary20 = 0x7f050129;
        public static int m3_ref_palette_primary30 = 0x7f05012a;
        public static int m3_ref_palette_primary40 = 0x7f05012b;
        public static int m3_ref_palette_primary50 = 0x7f05012c;
        public static int m3_ref_palette_primary60 = 0x7f05012d;
        public static int m3_ref_palette_primary70 = 0x7f05012e;
        public static int m3_ref_palette_primary80 = 0x7f05012f;
        public static int m3_ref_palette_primary90 = 0x7f050130;
        public static int m3_ref_palette_primary95 = 0x7f050131;
        public static int m3_ref_palette_primary99 = 0x7f050132;
        public static int m3_ref_palette_secondary0 = 0x7f050133;
        public static int m3_ref_palette_secondary10 = 0x7f050134;
        public static int m3_ref_palette_secondary100 = 0x7f050135;
        public static int m3_ref_palette_secondary20 = 0x7f050136;
        public static int m3_ref_palette_secondary30 = 0x7f050137;
        public static int m3_ref_palette_secondary40 = 0x7f050138;
        public static int m3_ref_palette_secondary50 = 0x7f050139;
        public static int m3_ref_palette_secondary60 = 0x7f05013a;
        public static int m3_ref_palette_secondary70 = 0x7f05013b;
        public static int m3_ref_palette_secondary80 = 0x7f05013c;
        public static int m3_ref_palette_secondary90 = 0x7f05013d;
        public static int m3_ref_palette_secondary95 = 0x7f05013e;
        public static int m3_ref_palette_secondary99 = 0x7f05013f;
        public static int m3_ref_palette_tertiary0 = 0x7f050140;
        public static int m3_ref_palette_tertiary10 = 0x7f050141;
        public static int m3_ref_palette_tertiary100 = 0x7f050142;
        public static int m3_ref_palette_tertiary20 = 0x7f050143;
        public static int m3_ref_palette_tertiary30 = 0x7f050144;
        public static int m3_ref_palette_tertiary40 = 0x7f050145;
        public static int m3_ref_palette_tertiary50 = 0x7f050146;
        public static int m3_ref_palette_tertiary60 = 0x7f050147;
        public static int m3_ref_palette_tertiary70 = 0x7f050148;
        public static int m3_ref_palette_tertiary80 = 0x7f050149;
        public static int m3_ref_palette_tertiary90 = 0x7f05014a;
        public static int m3_ref_palette_tertiary95 = 0x7f05014b;
        public static int m3_ref_palette_tertiary99 = 0x7f05014c;
        public static int m3_ref_palette_white = 0x7f05014d;
        public static int m3_selection_control_ripple_color_selector = 0x7f05014e;
        public static int m3_simple_item_ripple_color = 0x7f05014f;
        public static int m3_slider_active_track_color = 0x7f050150;
        public static int m3_slider_active_track_color_legacy = 0x7f050151;
        public static int m3_slider_halo_color_legacy = 0x7f050152;
        public static int m3_slider_inactive_track_color = 0x7f050153;
        public static int m3_slider_inactive_track_color_legacy = 0x7f050154;
        public static int m3_slider_thumb_color = 0x7f050155;
        public static int m3_slider_thumb_color_legacy = 0x7f050156;
        public static int m3_switch_thumb_tint = 0x7f050157;
        public static int m3_switch_track_tint = 0x7f050158;
        public static int m3_sys_color_dark_background = 0x7f050159;
        public static int m3_sys_color_dark_error = 0x7f05015a;
        public static int m3_sys_color_dark_error_container = 0x7f05015b;
        public static int m3_sys_color_dark_inverse_on_surface = 0x7f05015c;
        public static int m3_sys_color_dark_inverse_primary = 0x7f05015d;
        public static int m3_sys_color_dark_inverse_surface = 0x7f05015e;
        public static int m3_sys_color_dark_on_background = 0x7f05015f;
        public static int m3_sys_color_dark_on_error = 0x7f050160;
        public static int m3_sys_color_dark_on_error_container = 0x7f050161;
        public static int m3_sys_color_dark_on_primary = 0x7f050162;
        public static int m3_sys_color_dark_on_primary_container = 0x7f050163;
        public static int m3_sys_color_dark_on_secondary = 0x7f050164;
        public static int m3_sys_color_dark_on_secondary_container = 0x7f050165;
        public static int m3_sys_color_dark_on_surface = 0x7f050166;
        public static int m3_sys_color_dark_on_surface_variant = 0x7f050167;
        public static int m3_sys_color_dark_on_tertiary = 0x7f050168;
        public static int m3_sys_color_dark_on_tertiary_container = 0x7f050169;
        public static int m3_sys_color_dark_outline = 0x7f05016a;
        public static int m3_sys_color_dark_outline_variant = 0x7f05016b;
        public static int m3_sys_color_dark_primary = 0x7f05016c;
        public static int m3_sys_color_dark_primary_container = 0x7f05016d;
        public static int m3_sys_color_dark_secondary = 0x7f05016e;
        public static int m3_sys_color_dark_secondary_container = 0x7f05016f;
        public static int m3_sys_color_dark_surface = 0x7f050170;
        public static int m3_sys_color_dark_surface_bright = 0x7f050171;
        public static int m3_sys_color_dark_surface_container = 0x7f050172;
        public static int m3_sys_color_dark_surface_container_high = 0x7f050173;
        public static int m3_sys_color_dark_surface_container_highest = 0x7f050174;
        public static int m3_sys_color_dark_surface_container_low = 0x7f050175;
        public static int m3_sys_color_dark_surface_container_lowest = 0x7f050176;
        public static int m3_sys_color_dark_surface_dim = 0x7f050177;
        public static int m3_sys_color_dark_surface_variant = 0x7f050178;
        public static int m3_sys_color_dark_tertiary = 0x7f050179;
        public static int m3_sys_color_dark_tertiary_container = 0x7f05017a;
        public static int m3_sys_color_dynamic_dark_background = 0x7f05017b;
        public static int m3_sys_color_dynamic_dark_error = 0x7f05017c;
        public static int m3_sys_color_dynamic_dark_error_container = 0x7f05017d;
        public static int m3_sys_color_dynamic_dark_inverse_on_surface = 0x7f05017e;
        public static int m3_sys_color_dynamic_dark_inverse_primary = 0x7f05017f;
        public static int m3_sys_color_dynamic_dark_inverse_surface = 0x7f050180;
        public static int m3_sys_color_dynamic_dark_on_background = 0x7f050181;
        public static int m3_sys_color_dynamic_dark_on_error = 0x7f050182;
        public static int m3_sys_color_dynamic_dark_on_error_container = 0x7f050183;
        public static int m3_sys_color_dynamic_dark_on_primary = 0x7f050184;
        public static int m3_sys_color_dynamic_dark_on_primary_container = 0x7f050185;
        public static int m3_sys_color_dynamic_dark_on_secondary = 0x7f050186;
        public static int m3_sys_color_dynamic_dark_on_secondary_container = 0x7f050187;
        public static int m3_sys_color_dynamic_dark_on_surface = 0x7f050188;
        public static int m3_sys_color_dynamic_dark_on_surface_variant = 0x7f050189;
        public static int m3_sys_color_dynamic_dark_on_tertiary = 0x7f05018a;
        public static int m3_sys_color_dynamic_dark_on_tertiary_container = 0x7f05018b;
        public static int m3_sys_color_dynamic_dark_outline = 0x7f05018c;
        public static int m3_sys_color_dynamic_dark_outline_variant = 0x7f05018d;
        public static int m3_sys_color_dynamic_dark_primary = 0x7f05018e;
        public static int m3_sys_color_dynamic_dark_primary_container = 0x7f05018f;
        public static int m3_sys_color_dynamic_dark_secondary = 0x7f050190;
        public static int m3_sys_color_dynamic_dark_secondary_container = 0x7f050191;
        public static int m3_sys_color_dynamic_dark_surface = 0x7f050192;
        public static int m3_sys_color_dynamic_dark_surface_bright = 0x7f050193;
        public static int m3_sys_color_dynamic_dark_surface_container = 0x7f050194;
        public static int m3_sys_color_dynamic_dark_surface_container_high = 0x7f050195;
        public static int m3_sys_color_dynamic_dark_surface_container_highest = 0x7f050196;
        public static int m3_sys_color_dynamic_dark_surface_container_low = 0x7f050197;
        public static int m3_sys_color_dynamic_dark_surface_container_lowest = 0x7f050198;
        public static int m3_sys_color_dynamic_dark_surface_dim = 0x7f050199;
        public static int m3_sys_color_dynamic_dark_surface_variant = 0x7f05019a;
        public static int m3_sys_color_dynamic_dark_tertiary = 0x7f05019b;
        public static int m3_sys_color_dynamic_dark_tertiary_container = 0x7f05019c;
        public static int m3_sys_color_dynamic_light_background = 0x7f05019d;
        public static int m3_sys_color_dynamic_light_error = 0x7f05019e;
        public static int m3_sys_color_dynamic_light_error_container = 0x7f05019f;
        public static int m3_sys_color_dynamic_light_inverse_on_surface = 0x7f0501a0;
        public static int m3_sys_color_dynamic_light_inverse_primary = 0x7f0501a1;
        public static int m3_sys_color_dynamic_light_inverse_surface = 0x7f0501a2;
        public static int m3_sys_color_dynamic_light_on_background = 0x7f0501a3;
        public static int m3_sys_color_dynamic_light_on_error = 0x7f0501a4;
        public static int m3_sys_color_dynamic_light_on_error_container = 0x7f0501a5;
        public static int m3_sys_color_dynamic_light_on_primary = 0x7f0501a6;
        public static int m3_sys_color_dynamic_light_on_primary_container = 0x7f0501a7;
        public static int m3_sys_color_dynamic_light_on_secondary = 0x7f0501a8;
        public static int m3_sys_color_dynamic_light_on_secondary_container = 0x7f0501a9;
        public static int m3_sys_color_dynamic_light_on_surface = 0x7f0501aa;
        public static int m3_sys_color_dynamic_light_on_surface_variant = 0x7f0501ab;
        public static int m3_sys_color_dynamic_light_on_tertiary = 0x7f0501ac;
        public static int m3_sys_color_dynamic_light_on_tertiary_container = 0x7f0501ad;
        public static int m3_sys_color_dynamic_light_outline = 0x7f0501ae;
        public static int m3_sys_color_dynamic_light_outline_variant = 0x7f0501af;
        public static int m3_sys_color_dynamic_light_primary = 0x7f0501b0;
        public static int m3_sys_color_dynamic_light_primary_container = 0x7f0501b1;
        public static int m3_sys_color_dynamic_light_secondary = 0x7f0501b2;
        public static int m3_sys_color_dynamic_light_secondary_container = 0x7f0501b3;
        public static int m3_sys_color_dynamic_light_surface = 0x7f0501b4;
        public static int m3_sys_color_dynamic_light_surface_bright = 0x7f0501b5;
        public static int m3_sys_color_dynamic_light_surface_container = 0x7f0501b6;
        public static int m3_sys_color_dynamic_light_surface_container_high = 0x7f0501b7;
        public static int m3_sys_color_dynamic_light_surface_container_highest = 0x7f0501b8;
        public static int m3_sys_color_dynamic_light_surface_container_low = 0x7f0501b9;
        public static int m3_sys_color_dynamic_light_surface_container_lowest = 0x7f0501ba;
        public static int m3_sys_color_dynamic_light_surface_dim = 0x7f0501bb;
        public static int m3_sys_color_dynamic_light_surface_variant = 0x7f0501bc;
        public static int m3_sys_color_dynamic_light_tertiary = 0x7f0501bd;
        public static int m3_sys_color_dynamic_light_tertiary_container = 0x7f0501be;
        public static int m3_sys_color_dynamic_on_primary_fixed = 0x7f0501bf;
        public static int m3_sys_color_dynamic_on_primary_fixed_variant = 0x7f0501c0;
        public static int m3_sys_color_dynamic_on_secondary_fixed = 0x7f0501c1;
        public static int m3_sys_color_dynamic_on_secondary_fixed_variant = 0x7f0501c2;
        public static int m3_sys_color_dynamic_on_tertiary_fixed = 0x7f0501c3;
        public static int m3_sys_color_dynamic_on_tertiary_fixed_variant = 0x7f0501c4;
        public static int m3_sys_color_dynamic_primary_fixed = 0x7f0501c5;
        public static int m3_sys_color_dynamic_primary_fixed_dim = 0x7f0501c6;
        public static int m3_sys_color_dynamic_secondary_fixed = 0x7f0501c7;
        public static int m3_sys_color_dynamic_secondary_fixed_dim = 0x7f0501c8;
        public static int m3_sys_color_dynamic_tertiary_fixed = 0x7f0501c9;
        public static int m3_sys_color_dynamic_tertiary_fixed_dim = 0x7f0501ca;
        public static int m3_sys_color_light_background = 0x7f0501cb;
        public static int m3_sys_color_light_error = 0x7f0501cc;
        public static int m3_sys_color_light_error_container = 0x7f0501cd;
        public static int m3_sys_color_light_inverse_on_surface = 0x7f0501ce;
        public static int m3_sys_color_light_inverse_primary = 0x7f0501cf;
        public static int m3_sys_color_light_inverse_surface = 0x7f0501d0;
        public static int m3_sys_color_light_on_background = 0x7f0501d1;
        public static int m3_sys_color_light_on_error = 0x7f0501d2;
        public static int m3_sys_color_light_on_error_container = 0x7f0501d3;
        public static int m3_sys_color_light_on_primary = 0x7f0501d4;
        public static int m3_sys_color_light_on_primary_container = 0x7f0501d5;
        public static int m3_sys_color_light_on_secondary = 0x7f0501d6;
        public static int m3_sys_color_light_on_secondary_container = 0x7f0501d7;
        public static int m3_sys_color_light_on_surface = 0x7f0501d8;
        public static int m3_sys_color_light_on_surface_variant = 0x7f0501d9;
        public static int m3_sys_color_light_on_tertiary = 0x7f0501da;
        public static int m3_sys_color_light_on_tertiary_container = 0x7f0501db;
        public static int m3_sys_color_light_outline = 0x7f0501dc;
        public static int m3_sys_color_light_outline_variant = 0x7f0501dd;
        public static int m3_sys_color_light_primary = 0x7f0501de;
        public static int m3_sys_color_light_primary_container = 0x7f0501df;
        public static int m3_sys_color_light_secondary = 0x7f0501e0;
        public static int m3_sys_color_light_secondary_container = 0x7f0501e1;
        public static int m3_sys_color_light_surface = 0x7f0501e2;
        public static int m3_sys_color_light_surface_bright = 0x7f0501e3;
        public static int m3_sys_color_light_surface_container = 0x7f0501e4;
        public static int m3_sys_color_light_surface_container_high = 0x7f0501e5;
        public static int m3_sys_color_light_surface_container_highest = 0x7f0501e6;
        public static int m3_sys_color_light_surface_container_low = 0x7f0501e7;
        public static int m3_sys_color_light_surface_container_lowest = 0x7f0501e8;
        public static int m3_sys_color_light_surface_dim = 0x7f0501e9;
        public static int m3_sys_color_light_surface_variant = 0x7f0501ea;
        public static int m3_sys_color_light_tertiary = 0x7f0501eb;
        public static int m3_sys_color_light_tertiary_container = 0x7f0501ec;
        public static int m3_sys_color_on_primary_fixed = 0x7f0501ed;
        public static int m3_sys_color_on_primary_fixed_variant = 0x7f0501ee;
        public static int m3_sys_color_on_secondary_fixed = 0x7f0501ef;
        public static int m3_sys_color_on_secondary_fixed_variant = 0x7f0501f0;
        public static int m3_sys_color_on_tertiary_fixed = 0x7f0501f1;
        public static int m3_sys_color_on_tertiary_fixed_variant = 0x7f0501f2;
        public static int m3_sys_color_primary_fixed = 0x7f0501f3;
        public static int m3_sys_color_primary_fixed_dim = 0x7f0501f4;
        public static int m3_sys_color_secondary_fixed = 0x7f0501f5;
        public static int m3_sys_color_secondary_fixed_dim = 0x7f0501f6;
        public static int m3_sys_color_tertiary_fixed = 0x7f0501f7;
        public static int m3_sys_color_tertiary_fixed_dim = 0x7f0501f8;
        public static int m3_tabs_icon_color = 0x7f0501f9;
        public static int m3_tabs_icon_color_secondary = 0x7f0501fa;
        public static int m3_tabs_ripple_color = 0x7f0501fb;
        public static int m3_tabs_ripple_color_secondary = 0x7f0501fc;
        public static int m3_tabs_text_color = 0x7f0501fd;
        public static int m3_tabs_text_color_secondary = 0x7f0501fe;
        public static int m3_text_button_background_color_selector = 0x7f0501ff;
        public static int m3_text_button_foreground_color_selector = 0x7f050200;
        public static int m3_text_button_ripple_color_selector = 0x7f050201;
        public static int m3_textfield_filled_background_color = 0x7f050202;
        public static int m3_textfield_indicator_text_color = 0x7f050203;
        public static int m3_textfield_input_text_color = 0x7f050204;
        public static int m3_textfield_label_color = 0x7f050205;
        public static int m3_textfield_stroke_color = 0x7f050206;
        public static int m3_timepicker_button_background_color = 0x7f050207;
        public static int m3_timepicker_button_ripple_color = 0x7f050208;
        public static int m3_timepicker_button_text_color = 0x7f050209;
        public static int m3_timepicker_clock_text_color = 0x7f05020a;
        public static int m3_timepicker_display_background_color = 0x7f05020b;
        public static int m3_timepicker_display_ripple_color = 0x7f05020c;
        public static int m3_timepicker_display_text_color = 0x7f05020d;
        public static int m3_timepicker_secondary_text_button_ripple_color = 0x7f05020e;
        public static int m3_timepicker_secondary_text_button_text_color = 0x7f05020f;
        public static int m3_timepicker_time_input_stroke_color = 0x7f050210;
        public static int m3_tonal_button_ripple_color_selector = 0x7f050211;
        public static int material_blue_grey_800 = 0x7f050212;
        public static int material_blue_grey_900 = 0x7f050213;
        public static int material_blue_grey_950 = 0x7f050214;
        public static int material_cursor_color = 0x7f050215;
        public static int material_deep_teal_200 = 0x7f050216;
        public static int material_deep_teal_500 = 0x7f050217;
        public static int material_divider_color = 0x7f050218;
        public static int material_dynamic_color_dark_error = 0x7f050219;
        public static int material_dynamic_color_dark_error_container = 0x7f05021a;
        public static int material_dynamic_color_dark_on_error = 0x7f05021b;
        public static int material_dynamic_color_dark_on_error_container = 0x7f05021c;
        public static int material_dynamic_color_light_error = 0x7f05021d;
        public static int material_dynamic_color_light_error_container = 0x7f05021e;
        public static int material_dynamic_color_light_on_error = 0x7f05021f;
        public static int material_dynamic_color_light_on_error_container = 0x7f050220;
        public static int material_dynamic_neutral0 = 0x7f050221;
        public static int material_dynamic_neutral10 = 0x7f050222;
        public static int material_dynamic_neutral100 = 0x7f050223;
        public static int material_dynamic_neutral20 = 0x7f050224;
        public static int material_dynamic_neutral30 = 0x7f050225;
        public static int material_dynamic_neutral40 = 0x7f050226;
        public static int material_dynamic_neutral50 = 0x7f050227;
        public static int material_dynamic_neutral60 = 0x7f050228;
        public static int material_dynamic_neutral70 = 0x7f050229;
        public static int material_dynamic_neutral80 = 0x7f05022a;
        public static int material_dynamic_neutral90 = 0x7f05022b;
        public static int material_dynamic_neutral95 = 0x7f05022c;
        public static int material_dynamic_neutral99 = 0x7f05022d;
        public static int material_dynamic_neutral_variant0 = 0x7f05022e;
        public static int material_dynamic_neutral_variant10 = 0x7f05022f;
        public static int material_dynamic_neutral_variant100 = 0x7f050230;
        public static int material_dynamic_neutral_variant20 = 0x7f050231;
        public static int material_dynamic_neutral_variant30 = 0x7f050232;
        public static int material_dynamic_neutral_variant40 = 0x7f050233;
        public static int material_dynamic_neutral_variant50 = 0x7f050234;
        public static int material_dynamic_neutral_variant60 = 0x7f050235;
        public static int material_dynamic_neutral_variant70 = 0x7f050236;
        public static int material_dynamic_neutral_variant80 = 0x7f050237;
        public static int material_dynamic_neutral_variant90 = 0x7f050238;
        public static int material_dynamic_neutral_variant95 = 0x7f050239;
        public static int material_dynamic_neutral_variant99 = 0x7f05023a;
        public static int material_dynamic_primary0 = 0x7f05023b;
        public static int material_dynamic_primary10 = 0x7f05023c;
        public static int material_dynamic_primary100 = 0x7f05023d;
        public static int material_dynamic_primary20 = 0x7f05023e;
        public static int material_dynamic_primary30 = 0x7f05023f;
        public static int material_dynamic_primary40 = 0x7f050240;
        public static int material_dynamic_primary50 = 0x7f050241;
        public static int material_dynamic_primary60 = 0x7f050242;
        public static int material_dynamic_primary70 = 0x7f050243;
        public static int material_dynamic_primary80 = 0x7f050244;
        public static int material_dynamic_primary90 = 0x7f050245;
        public static int material_dynamic_primary95 = 0x7f050246;
        public static int material_dynamic_primary99 = 0x7f050247;
        public static int material_dynamic_secondary0 = 0x7f050248;
        public static int material_dynamic_secondary10 = 0x7f050249;
        public static int material_dynamic_secondary100 = 0x7f05024a;
        public static int material_dynamic_secondary20 = 0x7f05024b;
        public static int material_dynamic_secondary30 = 0x7f05024c;
        public static int material_dynamic_secondary40 = 0x7f05024d;
        public static int material_dynamic_secondary50 = 0x7f05024e;
        public static int material_dynamic_secondary60 = 0x7f05024f;
        public static int material_dynamic_secondary70 = 0x7f050250;
        public static int material_dynamic_secondary80 = 0x7f050251;
        public static int material_dynamic_secondary90 = 0x7f050252;
        public static int material_dynamic_secondary95 = 0x7f050253;
        public static int material_dynamic_secondary99 = 0x7f050254;
        public static int material_dynamic_tertiary0 = 0x7f050255;
        public static int material_dynamic_tertiary10 = 0x7f050256;
        public static int material_dynamic_tertiary100 = 0x7f050257;
        public static int material_dynamic_tertiary20 = 0x7f050258;
        public static int material_dynamic_tertiary30 = 0x7f050259;
        public static int material_dynamic_tertiary40 = 0x7f05025a;
        public static int material_dynamic_tertiary50 = 0x7f05025b;
        public static int material_dynamic_tertiary60 = 0x7f05025c;
        public static int material_dynamic_tertiary70 = 0x7f05025d;
        public static int material_dynamic_tertiary80 = 0x7f05025e;
        public static int material_dynamic_tertiary90 = 0x7f05025f;
        public static int material_dynamic_tertiary95 = 0x7f050260;
        public static int material_dynamic_tertiary99 = 0x7f050261;
        public static int material_grey_100 = 0x7f050262;
        public static int material_grey_300 = 0x7f050263;
        public static int material_grey_50 = 0x7f050264;
        public static int material_grey_600 = 0x7f050265;
        public static int material_grey_800 = 0x7f050266;
        public static int material_grey_850 = 0x7f050267;
        public static int material_grey_900 = 0x7f050268;
        public static int material_harmonized_color_error = 0x7f050269;
        public static int material_harmonized_color_error_container = 0x7f05026a;
        public static int material_harmonized_color_on_error = 0x7f05026b;
        public static int material_harmonized_color_on_error_container = 0x7f05026c;
        public static int material_on_background_disabled = 0x7f05026d;
        public static int material_on_background_emphasis_high_type = 0x7f05026e;
        public static int material_on_background_emphasis_medium = 0x7f05026f;
        public static int material_on_primary_disabled = 0x7f050270;
        public static int material_on_primary_emphasis_high_type = 0x7f050271;
        public static int material_on_primary_emphasis_medium = 0x7f050272;
        public static int material_on_surface_disabled = 0x7f050273;
        public static int material_on_surface_emphasis_high_type = 0x7f050274;
        public static int material_on_surface_emphasis_medium = 0x7f050275;
        public static int material_on_surface_stroke = 0x7f050276;
        public static int material_personalized__highlighted_text = 0x7f050277;
        public static int material_personalized__highlighted_text_inverse = 0x7f050278;
        public static int material_personalized_color_background = 0x7f050279;
        public static int material_personalized_color_control_activated = 0x7f05027a;
        public static int material_personalized_color_control_highlight = 0x7f05027b;
        public static int material_personalized_color_control_normal = 0x7f05027c;
        public static int material_personalized_color_error = 0x7f05027d;
        public static int material_personalized_color_error_container = 0x7f05027e;
        public static int material_personalized_color_on_background = 0x7f05027f;
        public static int material_personalized_color_on_error = 0x7f050280;
        public static int material_personalized_color_on_error_container = 0x7f050281;
        public static int material_personalized_color_on_primary = 0x7f050282;
        public static int material_personalized_color_on_primary_container = 0x7f050283;
        public static int material_personalized_color_on_secondary = 0x7f050284;
        public static int material_personalized_color_on_secondary_container = 0x7f050285;
        public static int material_personalized_color_on_surface = 0x7f050286;
        public static int material_personalized_color_on_surface_inverse = 0x7f050287;
        public static int material_personalized_color_on_surface_variant = 0x7f050288;
        public static int material_personalized_color_on_tertiary = 0x7f050289;
        public static int material_personalized_color_on_tertiary_container = 0x7f05028a;
        public static int material_personalized_color_outline = 0x7f05028b;
        public static int material_personalized_color_outline_variant = 0x7f05028c;
        public static int material_personalized_color_primary = 0x7f05028d;
        public static int material_personalized_color_primary_container = 0x7f05028e;
        public static int material_personalized_color_primary_inverse = 0x7f05028f;
        public static int material_personalized_color_primary_text = 0x7f050290;
        public static int material_personalized_color_primary_text_inverse = 0x7f050291;
        public static int material_personalized_color_secondary = 0x7f050292;
        public static int material_personalized_color_secondary_container = 0x7f050293;
        public static int material_personalized_color_secondary_text = 0x7f050294;
        public static int material_personalized_color_secondary_text_inverse = 0x7f050295;
        public static int material_personalized_color_surface = 0x7f050296;
        public static int material_personalized_color_surface_bright = 0x7f050297;
        public static int material_personalized_color_surface_container = 0x7f050298;
        public static int material_personalized_color_surface_container_high = 0x7f050299;
        public static int material_personalized_color_surface_container_highest = 0x7f05029a;
        public static int material_personalized_color_surface_container_low = 0x7f05029b;
        public static int material_personalized_color_surface_container_lowest = 0x7f05029c;
        public static int material_personalized_color_surface_dim = 0x7f05029d;
        public static int material_personalized_color_surface_inverse = 0x7f05029e;
        public static int material_personalized_color_surface_variant = 0x7f05029f;
        public static int material_personalized_color_tertiary = 0x7f0502a0;
        public static int material_personalized_color_tertiary_container = 0x7f0502a1;
        public static int material_personalized_color_text_hint_foreground_inverse = 0x7f0502a2;
        public static int material_personalized_color_text_primary_inverse = 0x7f0502a3;
        public static int material_personalized_color_text_primary_inverse_disable_only = 0x7f0502a4;
        public static int material_personalized_color_text_secondary_and_tertiary_inverse = 0x7f0502a5;
        public static int material_personalized_color_text_secondary_and_tertiary_inverse_disabled = 0x7f0502a6;
        public static int material_personalized_hint_foreground = 0x7f0502a7;
        public static int material_personalized_hint_foreground_inverse = 0x7f0502a8;
        public static int material_personalized_primary_inverse_text_disable_only = 0x7f0502a9;
        public static int material_personalized_primary_text_disable_only = 0x7f0502aa;
        public static int material_slider_active_tick_marks_color = 0x7f0502ab;
        public static int material_slider_active_track_color = 0x7f0502ac;
        public static int material_slider_halo_color = 0x7f0502ad;
        public static int material_slider_inactive_tick_marks_color = 0x7f0502ae;
        public static int material_slider_inactive_track_color = 0x7f0502af;
        public static int material_slider_thumb_color = 0x7f0502b0;
        public static int material_timepicker_button_background = 0x7f0502b1;
        public static int material_timepicker_button_stroke = 0x7f0502b2;
        public static int material_timepicker_clock_text_color = 0x7f0502b3;
        public static int material_timepicker_clockface = 0x7f0502b4;
        public static int material_timepicker_modebutton_tint = 0x7f0502b5;
        public static int mtrl_btn_bg_color_selector = 0x7f0502b6;
        public static int mtrl_btn_ripple_color = 0x7f0502b7;
        public static int mtrl_btn_stroke_color_selector = 0x7f0502b8;
        public static int mtrl_btn_text_btn_bg_color_selector = 0x7f0502b9;
        public static int mtrl_btn_text_btn_ripple_color = 0x7f0502ba;
        public static int mtrl_btn_text_color_disabled = 0x7f0502bb;
        public static int mtrl_btn_text_color_selector = 0x7f0502bc;
        public static int mtrl_btn_transparent_bg_color = 0x7f0502bd;
        public static int mtrl_calendar_item_stroke_color = 0x7f0502be;
        public static int mtrl_calendar_selected_range = 0x7f0502bf;
        public static int mtrl_card_view_foreground = 0x7f0502c0;
        public static int mtrl_card_view_ripple = 0x7f0502c1;
        public static int mtrl_chip_background_color = 0x7f0502c2;
        public static int mtrl_chip_close_icon_tint = 0x7f0502c3;
        public static int mtrl_chip_surface_color = 0x7f0502c4;
        public static int mtrl_chip_text_color = 0x7f0502c5;
        public static int mtrl_choice_chip_background_color = 0x7f0502c6;
        public static int mtrl_choice_chip_ripple_color = 0x7f0502c7;
        public static int mtrl_choice_chip_text_color = 0x7f0502c8;
        public static int mtrl_error = 0x7f0502c9;
        public static int mtrl_fab_bg_color_selector = 0x7f0502ca;
        public static int mtrl_fab_icon_text_color_selector = 0x7f0502cb;
        public static int mtrl_fab_ripple_color = 0x7f0502cc;
        public static int mtrl_filled_background_color = 0x7f0502cd;
        public static int mtrl_filled_icon_tint = 0x7f0502ce;
        public static int mtrl_filled_stroke_color = 0x7f0502cf;
        public static int mtrl_indicator_text_color = 0x7f0502d0;
        public static int mtrl_navigation_bar_colored_item_tint = 0x7f0502d1;
        public static int mtrl_navigation_bar_colored_ripple_color = 0x7f0502d2;
        public static int mtrl_navigation_bar_item_tint = 0x7f0502d3;
        public static int mtrl_navigation_bar_ripple_color = 0x7f0502d4;
        public static int mtrl_navigation_item_background_color = 0x7f0502d5;
        public static int mtrl_navigation_item_icon_tint = 0x7f0502d6;
        public static int mtrl_navigation_item_text_color = 0x7f0502d7;
        public static int mtrl_on_primary_text_btn_text_color_selector = 0x7f0502d8;
        public static int mtrl_on_surface_ripple_color = 0x7f0502d9;
        public static int mtrl_outlined_icon_tint = 0x7f0502da;
        public static int mtrl_outlined_stroke_color = 0x7f0502db;
        public static int mtrl_popupmenu_overlay_color = 0x7f0502dc;
        public static int mtrl_scrim_color = 0x7f0502dd;
        public static int mtrl_switch_thumb_icon_tint = 0x7f0502de;
        public static int mtrl_switch_thumb_tint = 0x7f0502df;
        public static int mtrl_switch_track_decoration_tint = 0x7f0502e0;
        public static int mtrl_switch_track_tint = 0x7f0502e1;
        public static int mtrl_tabs_colored_ripple_color = 0x7f0502e2;
        public static int mtrl_tabs_icon_color_selector = 0x7f0502e3;
        public static int mtrl_tabs_icon_color_selector_colored = 0x7f0502e4;
        public static int mtrl_tabs_legacy_text_color_selector = 0x7f0502e5;
        public static int mtrl_tabs_ripple_color = 0x7f0502e6;
        public static int mtrl_text_btn_text_color_selector = 0x7f0502e7;
        public static int mtrl_textinput_default_box_stroke_color = 0x7f0502e8;
        public static int mtrl_textinput_disabled_color = 0x7f0502e9;
        public static int mtrl_textinput_filled_box_default_background_color = 0x7f0502ea;
        public static int mtrl_textinput_focused_box_stroke_color = 0x7f0502eb;
        public static int mtrl_textinput_hovered_box_stroke_color = 0x7f0502ec;
        public static int notification_action_color_filter = 0x7f0502ed;
        public static int notification_icon_bg_color = 0x7f0502ee;
        public static int primary_dark_material_dark = 0x7f0502ef;
        public static int primary_dark_material_light = 0x7f0502f0;
        public static int primary_material_dark = 0x7f0502f1;
        public static int primary_material_light = 0x7f0502f2;
        public static int primary_text_default_material_dark = 0x7f0502f3;
        public static int primary_text_default_material_light = 0x7f0502f4;
        public static int primary_text_disabled_material_dark = 0x7f0502f5;
        public static int primary_text_disabled_material_light = 0x7f0502f6;
        public static int ripple_material_dark = 0x7f0502f7;
        public static int ripple_material_light = 0x7f0502f8;
        public static int secondary_text_default_material_dark = 0x7f0502f9;
        public static int secondary_text_default_material_light = 0x7f0502fa;
        public static int secondary_text_disabled_material_dark = 0x7f0502fb;
        public static int secondary_text_disabled_material_light = 0x7f0502fc;
        public static int switch_thumb_disabled_material_dark = 0x7f0502fd;
        public static int switch_thumb_disabled_material_light = 0x7f0502fe;
        public static int switch_thumb_material_dark = 0x7f0502ff;
        public static int switch_thumb_material_light = 0x7f050300;
        public static int switch_thumb_normal_material_dark = 0x7f050301;
        public static int switch_thumb_normal_material_light = 0x7f050302;
        public static int tooltip_background_dark = 0x7f050303;
        public static int tooltip_background_light = 0x7f050304;

        private color() {
        }
    }

    public static final class dimen {
        public static int abc_action_bar_content_inset_material = 0x7f060000;
        public static int abc_action_bar_content_inset_with_nav = 0x7f060001;
        public static int abc_action_bar_default_height_material = 0x7f060002;
        public static int abc_action_bar_default_padding_end_material = 0x7f060003;
        public static int abc_action_bar_default_padding_start_material = 0x7f060004;
        public static int abc_action_bar_elevation_material = 0x7f060005;
        public static int abc_action_bar_icon_vertical_padding_material = 0x7f060006;
        public static int abc_action_bar_overflow_padding_end_material = 0x7f060007;
        public static int abc_action_bar_overflow_padding_start_material = 0x7f060008;
        public static int abc_action_bar_stacked_max_height = 0x7f060009;
        public static int abc_action_bar_stacked_tab_max_width = 0x7f06000a;
        public static int abc_action_bar_subtitle_bottom_margin_material = 0x7f06000b;
        public static int abc_action_bar_subtitle_top_margin_material = 0x7f06000c;
        public static int abc_action_button_min_height_material = 0x7f06000d;
        public static int abc_action_button_min_width_material = 0x7f06000e;
        public static int abc_action_button_min_width_overflow_material = 0x7f06000f;
        public static int abc_alert_dialog_button_bar_height = 0x7f060010;
        public static int abc_alert_dialog_button_dimen = 0x7f060011;
        public static int abc_button_inset_horizontal_material = 0x7f060012;
        public static int abc_button_inset_vertical_material = 0x7f060013;
        public static int abc_button_padding_horizontal_material = 0x7f060014;
        public static int abc_button_padding_vertical_material = 0x7f060015;
        public static int abc_cascading_menus_min_smallest_width = 0x7f060016;
        public static int abc_config_prefDialogWidth = 0x7f060017;
        public static int abc_control_corner_material = 0x7f060018;
        public static int abc_control_inset_material = 0x7f060019;
        public static int abc_control_padding_material = 0x7f06001a;
        public static int abc_dialog_corner_radius_material = 0x7f06001b;
        public static int abc_dialog_fixed_height_major = 0x7f06001c;
        public static int abc_dialog_fixed_height_minor = 0x7f06001d;
        public static int abc_dialog_fixed_width_major = 0x7f06001e;
        public static int abc_dialog_fixed_width_minor = 0x7f06001f;
        public static int abc_dialog_list_padding_bottom_no_buttons = 0x7f060020;
        public static int abc_dialog_list_padding_top_no_title = 0x7f060021;
        public static int abc_dialog_min_width_major = 0x7f060022;
        public static int abc_dialog_min_width_minor = 0x7f060023;
        public static int abc_dialog_padding_material = 0x7f060024;
        public static int abc_dialog_padding_top_material = 0x7f060025;
        public static int abc_dialog_title_divider_material = 0x7f060026;
        public static int abc_disabled_alpha_material_dark = 0x7f060027;
        public static int abc_disabled_alpha_material_light = 0x7f060028;
        public static int abc_dropdownitem_icon_width = 0x7f060029;
        public static int abc_dropdownitem_text_padding_left = 0x7f06002a;
        public static int abc_dropdownitem_text_padding_right = 0x7f06002b;
        public static int abc_edit_text_inset_bottom_material = 0x7f06002c;
        public static int abc_edit_text_inset_horizontal_material = 0x7f06002d;
        public static int abc_edit_text_inset_top_material = 0x7f06002e;
        public static int abc_floating_window_z = 0x7f06002f;
        public static int abc_list_item_height_large_material = 0x7f060030;
        public static int abc_list_item_height_material = 0x7f060031;
        public static int abc_list_item_height_small_material = 0x7f060032;
        public static int abc_list_item_padding_horizontal_material = 0x7f060033;
        public static int abc_panel_menu_list_width = 0x7f060034;
        public static int abc_progress_bar_height_material = 0x7f060035;
        public static int abc_search_view_preferred_height = 0x7f060036;
        public static int abc_search_view_preferred_width = 0x7f060037;
        public static int abc_seekbar_track_background_height_material = 0x7f060038;
        public static int abc_seekbar_track_progress_height_material = 0x7f060039;
        public static int abc_select_dialog_padding_start_material = 0x7f06003a;
        public static int abc_star_big = 0x7f06003b;
        public static int abc_star_medium = 0x7f06003c;
        public static int abc_star_small = 0x7f06003d;
        public static int abc_switch_padding = 0x7f06003e;
        public static int abc_text_size_body_1_material = 0x7f06003f;
        public static int abc_text_size_body_2_material = 0x7f060040;
        public static int abc_text_size_button_material = 0x7f060041;
        public static int abc_text_size_caption_material = 0x7f060042;
        public static int abc_text_size_display_1_material = 0x7f060043;
        public static int abc_text_size_display_2_material = 0x7f060044;
        public static int abc_text_size_display_3_material = 0x7f060045;
        public static int abc_text_size_display_4_material = 0x7f060046;
        public static int abc_text_size_headline_material = 0x7f060047;
        public static int abc_text_size_large_material = 0x7f060048;
        public static int abc_text_size_medium_material = 0x7f060049;
        public static int abc_text_size_menu_header_material = 0x7f06004a;
        public static int abc_text_size_menu_material = 0x7f06004b;
        public static int abc_text_size_small_material = 0x7f06004c;
        public static int abc_text_size_subhead_material = 0x7f06004d;
        public static int abc_text_size_subtitle_material_toolbar = 0x7f06004e;
        public static int abc_text_size_title_material = 0x7f06004f;
        public static int abc_text_size_title_material_toolbar = 0x7f060050;
        public static int appcompat_dialog_background_inset = 0x7f060051;
        public static int cardview_compat_inset_shadow = 0x7f060052;
        public static int cardview_default_elevation = 0x7f060053;
        public static int cardview_default_radius = 0x7f060054;
        public static int clock_face_margin_start = 0x7f060055;
        public static int compat_button_inset_horizontal_material = 0x7f060056;
        public static int compat_button_inset_vertical_material = 0x7f060057;
        public static int compat_button_padding_horizontal_material = 0x7f060058;
        public static int compat_button_padding_vertical_material = 0x7f060059;
        public static int compat_control_corner_material = 0x7f06005a;
        public static int compat_notification_large_icon_max_height = 0x7f06005b;
        public static int compat_notification_large_icon_max_width = 0x7f06005c;
        public static int def_drawer_elevation = 0x7f06005d;
        public static int design_appbar_elevation = 0x7f06005e;
        public static int design_bottom_navigation_active_item_max_width = 0x7f06005f;
        public static int design_bottom_navigation_active_item_min_width = 0x7f060060;
        public static int design_bottom_navigation_active_text_size = 0x7f060061;
        public static int design_bottom_navigation_elevation = 0x7f060062;
        public static int design_bottom_navigation_height = 0x7f060063;
        public static int design_bottom_navigation_icon_size = 0x7f060064;
        public static int design_bottom_navigation_item_max_width = 0x7f060065;
        public static int design_bottom_navigation_item_min_width = 0x7f060066;
        public static int design_bottom_navigation_label_padding = 0x7f060067;
        public static int design_bottom_navigation_margin = 0x7f060068;
        public static int design_bottom_navigation_shadow_height = 0x7f060069;
        public static int design_bottom_navigation_text_size = 0x7f06006a;
        public static int design_bottom_sheet_elevation = 0x7f06006b;
        public static int design_bottom_sheet_modal_elevation = 0x7f06006c;
        public static int design_bottom_sheet_peek_height_min = 0x7f06006d;
        public static int design_fab_border_width = 0x7f06006e;
        public static int design_fab_elevation = 0x7f06006f;
        public static int design_fab_image_size = 0x7f060070;
        public static int design_fab_size_mini = 0x7f060071;
        public static int design_fab_size_normal = 0x7f060072;
        public static int design_fab_translation_z_hovered_focused = 0x7f060073;
        public static int design_fab_translation_z_pressed = 0x7f060074;
        public static int design_navigation_elevation = 0x7f060075;
        public static int design_navigation_icon_padding = 0x7f060076;
        public static int design_navigation_icon_size = 0x7f060077;
        public static int design_navigation_item_horizontal_padding = 0x7f060078;
        public static int design_navigation_item_icon_padding = 0x7f060079;
        public static int design_navigation_item_vertical_padding = 0x7f06007a;
        public static int design_navigation_max_width = 0x7f06007b;
        public static int design_navigation_padding_bottom = 0x7f06007c;
        public static int design_navigation_separator_vertical_padding = 0x7f06007d;
        public static int design_snackbar_action_inline_max_width = 0x7f06007e;
        public static int design_snackbar_action_text_color_alpha = 0x7f06007f;
        public static int design_snackbar_background_corner_radius = 0x7f060080;
        public static int design_snackbar_elevation = 0x7f060081;
        public static int design_snackbar_extra_spacing_horizontal = 0x7f060082;
        public static int design_snackbar_max_width = 0x7f060083;
        public static int design_snackbar_min_width = 0x7f060084;
        public static int design_snackbar_padding_horizontal = 0x7f060085;
        public static int design_snackbar_padding_vertical = 0x7f060086;
        public static int design_snackbar_padding_vertical_2lines = 0x7f060087;
        public static int design_snackbar_text_size = 0x7f060088;
        public static int design_tab_max_width = 0x7f060089;
        public static int design_tab_scrollable_min_width = 0x7f06008a;
        public static int design_tab_text_size = 0x7f06008b;
        public static int design_tab_text_size_2line = 0x7f06008c;
        public static int design_textinput_caption_translate_y = 0x7f06008d;
        public static int disabled_alpha_material_dark = 0x7f06008e;
        public static int disabled_alpha_material_light = 0x7f06008f;
        public static int fastscroll_default_thickness = 0x7f060090;
        public static int fastscroll_margin = 0x7f060091;
        public static int fastscroll_minimum_range = 0x7f060092;
        public static int highlight_alpha_material_colored = 0x7f060093;
        public static int highlight_alpha_material_dark = 0x7f060094;
        public static int highlight_alpha_material_light = 0x7f060095;
        public static int hint_alpha_material_dark = 0x7f060096;
        public static int hint_alpha_material_light = 0x7f060097;
        public static int hint_pressed_alpha_material_dark = 0x7f060098;
        public static int hint_pressed_alpha_material_light = 0x7f060099;
        public static int item_touch_helper_max_drag_scroll_per_frame = 0x7f06009a;
        public static int item_touch_helper_swipe_escape_max_velocity = 0x7f06009b;
        public static int item_touch_helper_swipe_escape_velocity = 0x7f06009c;
        public static int m3_alert_dialog_action_bottom_padding = 0x7f06009d;
        public static int m3_alert_dialog_action_top_padding = 0x7f06009e;
        public static int m3_alert_dialog_corner_size = 0x7f06009f;
        public static int m3_alert_dialog_elevation = 0x7f0600a0;
        public static int m3_alert_dialog_icon_margin = 0x7f0600a1;
        public static int m3_alert_dialog_icon_size = 0x7f0600a2;
        public static int m3_alert_dialog_title_bottom_margin = 0x7f0600a3;
        public static int m3_appbar_expanded_title_margin_bottom = 0x7f0600a4;
        public static int m3_appbar_expanded_title_margin_horizontal = 0x7f0600a5;
        public static int m3_appbar_scrim_height_trigger = 0x7f0600a6;
        public static int m3_appbar_scrim_height_trigger_large = 0x7f0600a7;
        public static int m3_appbar_scrim_height_trigger_medium = 0x7f0600a8;
        public static int m3_appbar_size_compact = 0x7f0600a9;
        public static int m3_appbar_size_large = 0x7f0600aa;
        public static int m3_appbar_size_medium = 0x7f0600ab;
        public static int m3_back_progress_bottom_container_max_scale_x_distance = 0x7f0600ac;
        public static int m3_back_progress_bottom_container_max_scale_y_distance = 0x7f0600ad;
        public static int m3_back_progress_main_container_max_translation_y = 0x7f0600ae;
        public static int m3_back_progress_main_container_min_edge_gap = 0x7f0600af;
        public static int m3_back_progress_side_container_max_scale_x_distance_grow = 0x7f0600b0;
        public static int m3_back_progress_side_container_max_scale_x_distance_shrink = 0x7f0600b1;
        public static int m3_back_progress_side_container_max_scale_y_distance = 0x7f0600b2;
        public static int m3_badge_horizontal_offset = 0x7f0600b3;
        public static int m3_badge_offset = 0x7f0600b4;
        public static int m3_badge_size = 0x7f0600b5;
        public static int m3_badge_vertical_offset = 0x7f0600b6;
        public static int m3_badge_with_text_horizontal_offset = 0x7f0600b7;
        public static int m3_badge_with_text_offset = 0x7f0600b8;
        public static int m3_badge_with_text_size = 0x7f0600b9;
        public static int m3_badge_with_text_vertical_offset = 0x7f0600ba;
        public static int m3_badge_with_text_vertical_padding = 0x7f0600bb;
        public static int m3_bottom_nav_item_active_indicator_height = 0x7f0600bc;
        public static int m3_bottom_nav_item_active_indicator_margin_horizontal = 0x7f0600bd;
        public static int m3_bottom_nav_item_active_indicator_width = 0x7f0600be;
        public static int m3_bottom_nav_item_padding_bottom = 0x7f0600bf;
        public static int m3_bottom_nav_item_padding_top = 0x7f0600c0;
        public static int m3_bottom_nav_min_height = 0x7f0600c1;
        public static int m3_bottom_sheet_drag_handle_bottom_padding = 0x7f0600c2;
        public static int m3_bottom_sheet_elevation = 0x7f0600c3;
        public static int m3_bottom_sheet_modal_elevation = 0x7f0600c4;
        public static int m3_bottomappbar_fab_cradle_margin = 0x7f0600c5;
        public static int m3_bottomappbar_fab_cradle_rounded_corner_radius = 0x7f0600c6;
        public static int m3_bottomappbar_fab_cradle_vertical_offset = 0x7f0600c7;
        public static int m3_bottomappbar_fab_end_margin = 0x7f0600c8;
        public static int m3_bottomappbar_height = 0x7f0600c9;
        public static int m3_bottomappbar_horizontal_padding = 0x7f0600ca;
        public static int m3_btn_dialog_btn_min_width = 0x7f0600cb;
        public static int m3_btn_dialog_btn_spacing = 0x7f0600cc;
        public static int m3_btn_disabled_elevation = 0x7f0600cd;
        public static int m3_btn_disabled_translation_z = 0x7f0600ce;
        public static int m3_btn_elevated_btn_elevation = 0x7f0600cf;
        public static int m3_btn_elevation = 0x7f0600d0;
        public static int m3_btn_icon_btn_padding_left = 0x7f0600d1;
        public static int m3_btn_icon_btn_padding_right = 0x7f0600d2;
        public static int m3_btn_icon_only_default_padding = 0x7f0600d3;
        public static int m3_btn_icon_only_default_size = 0x7f0600d4;
        public static int m3_btn_icon_only_icon_padding = 0x7f0600d5;
        public static int m3_btn_icon_only_min_width = 0x7f0600d6;
        public static int m3_btn_inset = 0x7f0600d7;
        public static int m3_btn_max_width = 0x7f0600d8;
        public static int m3_btn_padding_bottom = 0x7f0600d9;
        public static int m3_btn_padding_left = 0x7f0600da;
        public static int m3_btn_padding_right = 0x7f0600db;
        public static int m3_btn_padding_top = 0x7f0600dc;
        public static int m3_btn_stroke_size = 0x7f0600dd;
        public static int m3_btn_text_btn_icon_padding_left = 0x7f0600de;
        public static int m3_btn_text_btn_icon_padding_right = 0x7f0600df;
        public static int m3_btn_text_btn_padding_left = 0x7f0600e0;
        public static int m3_btn_text_btn_padding_right = 0x7f0600e1;
        public static int m3_btn_translation_z_base = 0x7f0600e2;
        public static int m3_btn_translation_z_hovered = 0x7f0600e3;
        public static int m3_card_disabled_z = 0x7f0600e4;
        public static int m3_card_dragged_z = 0x7f0600e5;
        public static int m3_card_elevated_disabled_z = 0x7f0600e6;
        public static int m3_card_elevated_dragged_z = 0x7f0600e7;
        public static int m3_card_elevated_elevation = 0x7f0600e8;
        public static int m3_card_elevated_hovered_z = 0x7f0600e9;
        public static int m3_card_elevation = 0x7f0600ea;
        public static int m3_card_hovered_z = 0x7f0600eb;
        public static int m3_card_stroke_width = 0x7f0600ec;
        public static int m3_carousel_debug_keyline_width = 0x7f0600ed;
        public static int m3_carousel_extra_small_item_size = 0x7f0600ee;
        public static int m3_carousel_gone_size = 0x7f0600ef;
        public static int m3_carousel_small_item_default_corner_size = 0x7f0600f0;
        public static int m3_carousel_small_item_size_max = 0x7f0600f1;
        public static int m3_carousel_small_item_size_min = 0x7f0600f2;
        public static int m3_chip_checked_hovered_translation_z = 0x7f0600f3;
        public static int m3_chip_corner_size = 0x7f0600f4;
        public static int m3_chip_disabled_translation_z = 0x7f0600f5;
        public static int m3_chip_dragged_translation_z = 0x7f0600f6;
        public static int m3_chip_elevated_elevation = 0x7f0600f7;
        public static int m3_chip_hovered_translation_z = 0x7f0600f8;
        public static int m3_chip_icon_size = 0x7f0600f9;
        public static int m3_comp_assist_chip_container_height = 0x7f0600fa;
        public static int m3_comp_assist_chip_elevated_container_elevation = 0x7f0600fb;
        public static int m3_comp_assist_chip_flat_container_elevation = 0x7f0600fc;
        public static int m3_comp_assist_chip_flat_outline_width = 0x7f0600fd;
        public static int m3_comp_assist_chip_with_icon_icon_size = 0x7f0600fe;
        public static int m3_comp_badge_large_size = 0x7f0600ff;
        public static int m3_comp_badge_size = 0x7f060100;
        public static int m3_comp_bottom_app_bar_container_elevation = 0x7f060101;
        public static int m3_comp_bottom_app_bar_container_height = 0x7f060102;
        public static int m3_comp_checkbox_selected_disabled_container_opacity = 0x7f060103;
        public static int m3_comp_date_picker_modal_date_today_container_outline_width = 0x7f060104;
        public static int m3_comp_date_picker_modal_header_container_height = 0x7f060105;
        public static int m3_comp_date_picker_modal_range_selection_header_container_height = 0x7f060106;
        public static int m3_comp_divider_thickness = 0x7f060107;
        public static int m3_comp_elevated_button_container_elevation = 0x7f060108;
        public static int m3_comp_elevated_button_disabled_container_elevation = 0x7f060109;
        public static int m3_comp_elevated_card_container_elevation = 0x7f06010a;
        public static int m3_comp_elevated_card_icon_size = 0x7f06010b;
        public static int m3_comp_extended_fab_primary_container_elevation = 0x7f06010c;
        public static int m3_comp_extended_fab_primary_container_height = 0x7f06010d;
        public static int m3_comp_extended_fab_primary_focus_container_elevation = 0x7f06010e;
        public static int m3_comp_extended_fab_primary_focus_state_layer_opacity = 0x7f06010f;
        public static int m3_comp_extended_fab_primary_hover_container_elevation = 0x7f060110;
        public static int m3_comp_extended_fab_primary_hover_state_layer_opacity = 0x7f060111;
        public static int m3_comp_extended_fab_primary_icon_size = 0x7f060112;
        public static int m3_comp_extended_fab_primary_pressed_container_elevation = 0x7f060113;
        public static int m3_comp_extended_fab_primary_pressed_state_layer_opacity = 0x7f060114;
        public static int m3_comp_fab_primary_container_elevation = 0x7f060115;
        public static int m3_comp_fab_primary_container_height = 0x7f060116;
        public static int m3_comp_fab_primary_focus_state_layer_opacity = 0x7f060117;
        public static int m3_comp_fab_primary_hover_container_elevation = 0x7f060118;
        public static int m3_comp_fab_primary_hover_state_layer_opacity = 0x7f060119;
        public static int m3_comp_fab_primary_icon_size = 0x7f06011a;
        public static int m3_comp_fab_primary_large_container_height = 0x7f06011b;
        public static int m3_comp_fab_primary_large_icon_size = 0x7f06011c;
        public static int m3_comp_fab_primary_pressed_container_elevation = 0x7f06011d;
        public static int m3_comp_fab_primary_pressed_state_layer_opacity = 0x7f06011e;
        public static int m3_comp_fab_primary_small_container_height = 0x7f06011f;
        public static int m3_comp_fab_primary_small_icon_size = 0x7f060120;
        public static int m3_comp_filled_autocomplete_menu_container_elevation = 0x7f060121;
        public static int m3_comp_filled_button_container_elevation = 0x7f060122;
        public static int m3_comp_filled_button_with_icon_icon_size = 0x7f060123;
        public static int m3_comp_filled_card_container_elevation = 0x7f060124;
        public static int m3_comp_filled_card_dragged_state_layer_opacity = 0x7f060125;
        public static int m3_comp_filled_card_focus_state_layer_opacity = 0x7f060126;
        public static int m3_comp_filled_card_hover_state_layer_opacity = 0x7f060127;
        public static int m3_comp_filled_card_icon_size = 0x7f060128;
        public static int m3_comp_filled_card_pressed_state_layer_opacity = 0x7f060129;
        public static int m3_comp_filled_text_field_disabled_active_indicator_opacity = 0x7f06012a;
        public static int m3_comp_filter_chip_container_height = 0x7f06012b;
        public static int m3_comp_filter_chip_elevated_container_elevation = 0x7f06012c;
        public static int m3_comp_filter_chip_flat_container_elevation = 0x7f06012d;
        public static int m3_comp_filter_chip_flat_unselected_outline_width = 0x7f06012e;
        public static int m3_comp_filter_chip_with_icon_icon_size = 0x7f06012f;
        public static int m3_comp_input_chip_container_elevation = 0x7f060130;
        public static int m3_comp_input_chip_container_height = 0x7f060131;
        public static int m3_comp_input_chip_unselected_outline_width = 0x7f060132;
        public static int m3_comp_input_chip_with_avatar_avatar_size = 0x7f060133;
        public static int m3_comp_input_chip_with_leading_icon_leading_icon_size = 0x7f060134;
        public static int m3_comp_menu_container_elevation = 0x7f060135;
        public static int m3_comp_navigation_bar_active_indicator_height = 0x7f060136;
        public static int m3_comp_navigation_bar_active_indicator_width = 0x7f060137;
        public static int m3_comp_navigation_bar_container_elevation = 0x7f060138;
        public static int m3_comp_navigation_bar_container_height = 0x7f060139;
        public static int m3_comp_navigation_bar_focus_state_layer_opacity = 0x7f06013a;
        public static int m3_comp_navigation_bar_hover_state_layer_opacity = 0x7f06013b;
        public static int m3_comp_navigation_bar_icon_size = 0x7f06013c;
        public static int m3_comp_navigation_bar_pressed_state_layer_opacity = 0x7f06013d;
        public static int m3_comp_navigation_drawer_container_width = 0x7f06013e;
        public static int m3_comp_navigation_drawer_focus_state_layer_opacity = 0x7f06013f;
        public static int m3_comp_navigation_drawer_hover_state_layer_opacity = 0x7f060140;
        public static int m3_comp_navigation_drawer_icon_size = 0x7f060141;
        public static int m3_comp_navigation_drawer_modal_container_elevation = 0x7f060142;
        public static int m3_comp_navigation_drawer_pressed_state_layer_opacity = 0x7f060143;
        public static int m3_comp_navigation_drawer_standard_container_elevation = 0x7f060144;
        public static int m3_comp_navigation_rail_active_indicator_height = 0x7f060145;
        public static int m3_comp_navigation_rail_active_indicator_width = 0x7f060146;
        public static int m3_comp_navigation_rail_container_elevation = 0x7f060147;
        public static int m3_comp_navigation_rail_container_width = 0x7f060148;
        public static int m3_comp_navigation_rail_focus_state_layer_opacity = 0x7f060149;
        public static int m3_comp_navigation_rail_hover_state_layer_opacity = 0x7f06014a;
        public static int m3_comp_navigation_rail_icon_size = 0x7f06014b;
        public static int m3_comp_navigation_rail_pressed_state_layer_opacity = 0x7f06014c;
        public static int m3_comp_outlined_autocomplete_menu_container_elevation = 0x7f06014d;
        public static int m3_comp_outlined_button_disabled_outline_opacity = 0x7f06014e;
        public static int m3_comp_outlined_button_outline_width = 0x7f06014f;
        public static int m3_comp_outlined_card_container_elevation = 0x7f060150;
        public static int m3_comp_outlined_card_disabled_outline_opacity = 0x7f060151;
        public static int m3_comp_outlined_card_icon_size = 0x7f060152;
        public static int m3_comp_outlined_card_outline_width = 0x7f060153;
        public static int m3_comp_outlined_icon_button_unselected_outline_width = 0x7f060154;
        public static int m3_comp_outlined_text_field_disabled_input_text_opacity = 0x7f060155;
        public static int m3_comp_outlined_text_field_disabled_label_text_opacity = 0x7f060156;
        public static int m3_comp_outlined_text_field_disabled_supporting_text_opacity = 0x7f060157;
        public static int m3_comp_outlined_text_field_focus_outline_width = 0x7f060158;
        public static int m3_comp_outlined_text_field_outline_width = 0x7f060159;
        public static int m3_comp_primary_navigation_tab_active_focus_state_layer_opacity = 0x7f06015a;
        public static int m3_comp_primary_navigation_tab_active_hover_state_layer_opacity = 0x7f06015b;
        public static int m3_comp_primary_navigation_tab_active_indicator_height = 0x7f06015c;
        public static int m3_comp_primary_navigation_tab_active_pressed_state_layer_opacity = 0x7f06015d;
        public static int m3_comp_primary_navigation_tab_inactive_focus_state_layer_opacity = 0x7f06015e;
        public static int m3_comp_primary_navigation_tab_inactive_hover_state_layer_opacity = 0x7f06015f;
        public static int m3_comp_primary_navigation_tab_inactive_pressed_state_layer_opacity = 0x7f060160;
        public static int m3_comp_primary_navigation_tab_with_icon_icon_size = 0x7f060161;
        public static int m3_comp_progress_indicator_active_indicator_track_space = 0x7f060162;
        public static int m3_comp_progress_indicator_stop_indicator_size = 0x7f060163;
        public static int m3_comp_progress_indicator_track_thickness = 0x7f060164;
        public static int m3_comp_radio_button_disabled_selected_icon_opacity = 0x7f060165;
        public static int m3_comp_radio_button_disabled_unselected_icon_opacity = 0x7f060166;
        public static int m3_comp_radio_button_selected_focus_state_layer_opacity = 0x7f060167;
        public static int m3_comp_radio_button_selected_hover_state_layer_opacity = 0x7f060168;
        public static int m3_comp_radio_button_selected_pressed_state_layer_opacity = 0x7f060169;
        public static int m3_comp_radio_button_unselected_focus_state_layer_opacity = 0x7f06016a;
        public static int m3_comp_radio_button_unselected_hover_state_layer_opacity = 0x7f06016b;
        public static int m3_comp_radio_button_unselected_pressed_state_layer_opacity = 0x7f06016c;
        public static int m3_comp_scrim_container_opacity = 0x7f06016d;
        public static int m3_comp_search_bar_avatar_size = 0x7f06016e;
        public static int m3_comp_search_bar_container_elevation = 0x7f06016f;
        public static int m3_comp_search_bar_container_height = 0x7f060170;
        public static int m3_comp_search_bar_hover_state_layer_opacity = 0x7f060171;
        public static int m3_comp_search_bar_pressed_state_layer_opacity = 0x7f060172;
        public static int m3_comp_search_view_container_elevation = 0x7f060173;
        public static int m3_comp_search_view_docked_header_container_height = 0x7f060174;
        public static int m3_comp_search_view_full_screen_header_container_height = 0x7f060175;
        public static int m3_comp_secondary_navigation_tab_active_indicator_height = 0x7f060176;
        public static int m3_comp_secondary_navigation_tab_focus_state_layer_opacity = 0x7f060177;
        public static int m3_comp_secondary_navigation_tab_hover_state_layer_opacity = 0x7f060178;
        public static int m3_comp_secondary_navigation_tab_pressed_state_layer_opacity = 0x7f060179;
        public static int m3_comp_sheet_bottom_docked_drag_handle_height = 0x7f06017a;
        public static int m3_comp_sheet_bottom_docked_drag_handle_width = 0x7f06017b;
        public static int m3_comp_sheet_bottom_docked_modal_container_elevation = 0x7f06017c;
        public static int m3_comp_sheet_bottom_docked_standard_container_elevation = 0x7f06017d;
        public static int m3_comp_sheet_side_docked_container_width = 0x7f06017e;
        public static int m3_comp_sheet_side_docked_modal_container_elevation = 0x7f06017f;
        public static int m3_comp_sheet_side_docked_standard_container_elevation = 0x7f060180;
        public static int m3_comp_slider_active_handle_height = 0x7f060181;
        public static int m3_comp_slider_active_handle_leading_space = 0x7f060182;
        public static int m3_comp_slider_active_handle_width = 0x7f060183;
        public static int m3_comp_slider_disabled_active_track_opacity = 0x7f060184;
        public static int m3_comp_slider_disabled_handle_opacity = 0x7f060185;
        public static int m3_comp_slider_disabled_inactive_track_opacity = 0x7f060186;
        public static int m3_comp_slider_inactive_track_height = 0x7f060187;
        public static int m3_comp_slider_stop_indicator_size = 0x7f060188;
        public static int m3_comp_snackbar_container_elevation = 0x7f060189;
        public static int m3_comp_suggestion_chip_container_height = 0x7f06018a;
        public static int m3_comp_suggestion_chip_elevated_container_elevation = 0x7f06018b;
        public static int m3_comp_suggestion_chip_flat_container_elevation = 0x7f06018c;
        public static int m3_comp_suggestion_chip_flat_outline_width = 0x7f06018d;
        public static int m3_comp_suggestion_chip_with_leading_icon_leading_icon_size = 0x7f06018e;
        public static int m3_comp_switch_disabled_selected_handle_opacity = 0x7f06018f;
        public static int m3_comp_switch_disabled_selected_icon_opacity = 0x7f060190;
        public static int m3_comp_switch_disabled_track_opacity = 0x7f060191;
        public static int m3_comp_switch_disabled_unselected_handle_opacity = 0x7f060192;
        public static int m3_comp_switch_disabled_unselected_icon_opacity = 0x7f060193;
        public static int m3_comp_switch_selected_focus_state_layer_opacity = 0x7f060194;
        public static int m3_comp_switch_selected_hover_state_layer_opacity = 0x7f060195;
        public static int m3_comp_switch_selected_pressed_state_layer_opacity = 0x7f060196;
        public static int m3_comp_switch_track_height = 0x7f060197;
        public static int m3_comp_switch_track_width = 0x7f060198;
        public static int m3_comp_switch_unselected_focus_state_layer_opacity = 0x7f060199;
        public static int m3_comp_switch_unselected_hover_state_layer_opacity = 0x7f06019a;
        public static int m3_comp_switch_unselected_pressed_state_layer_opacity = 0x7f06019b;
        public static int m3_comp_text_button_focus_state_layer_opacity = 0x7f06019c;
        public static int m3_comp_text_button_hover_state_layer_opacity = 0x7f06019d;
        public static int m3_comp_text_button_pressed_state_layer_opacity = 0x7f06019e;
        public static int m3_comp_time_input_time_input_field_focus_outline_width = 0x7f06019f;
        public static int m3_comp_time_picker_container_elevation = 0x7f0601a0;
        public static int m3_comp_time_picker_period_selector_focus_state_layer_opacity = 0x7f0601a1;
        public static int m3_comp_time_picker_period_selector_hover_state_layer_opacity = 0x7f0601a2;
        public static int m3_comp_time_picker_period_selector_outline_width = 0x7f0601a3;
        public static int m3_comp_time_picker_period_selector_pressed_state_layer_opacity = 0x7f0601a4;
        public static int m3_comp_time_picker_time_selector_focus_state_layer_opacity = 0x7f0601a5;
        public static int m3_comp_time_picker_time_selector_hover_state_layer_opacity = 0x7f0601a6;
        public static int m3_comp_time_picker_time_selector_pressed_state_layer_opacity = 0x7f0601a7;
        public static int m3_comp_top_app_bar_large_container_height = 0x7f0601a8;
        public static int m3_comp_top_app_bar_medium_container_height = 0x7f0601a9;
        public static int m3_comp_top_app_bar_small_container_elevation = 0x7f0601aa;
        public static int m3_comp_top_app_bar_small_container_height = 0x7f0601ab;
        public static int m3_comp_top_app_bar_small_on_scroll_container_elevation = 0x7f0601ac;
        public static int m3_datepicker_elevation = 0x7f0601ad;
        public static int m3_divider_heavy_thickness = 0x7f0601ae;
        public static int m3_extended_fab_bottom_padding = 0x7f0601af;
        public static int m3_extended_fab_end_padding = 0x7f0601b0;
        public static int m3_extended_fab_icon_padding = 0x7f0601b1;
        public static int m3_extended_fab_min_height = 0x7f0601b2;
        public static int m3_extended_fab_start_padding = 0x7f0601b3;
        public static int m3_extended_fab_top_padding = 0x7f0601b4;
        public static int m3_fab_border_width = 0x7f0601b5;
        public static int m3_fab_corner_size = 0x7f0601b6;
        public static int m3_fab_translation_z_hovered_focused = 0x7f0601b7;
        public static int m3_fab_translation_z_pressed = 0x7f0601b8;
        public static int m3_large_fab_max_image_size = 0x7f0601b9;
        public static int m3_large_fab_size = 0x7f0601ba;
        public static int m3_large_text_vertical_offset_adjustment = 0x7f0601bb;
        public static int m3_menu_elevation = 0x7f0601bc;
        public static int m3_nav_badge_with_text_vertical_offset = 0x7f0601bd;
        public static int m3_navigation_drawer_layout_corner_size = 0x7f0601be;
        public static int m3_navigation_item_active_indicator_label_padding = 0x7f0601bf;
        public static int m3_navigation_item_horizontal_padding = 0x7f0601c0;
        public static int m3_navigation_item_icon_padding = 0x7f0601c1;
        public static int m3_navigation_item_shape_inset_bottom = 0x7f0601c2;
        public static int m3_navigation_item_shape_inset_end = 0x7f0601c3;
        public static int m3_navigation_item_shape_inset_start = 0x7f0601c4;
        public static int m3_navigation_item_shape_inset_top = 0x7f0601c5;
        public static int m3_navigation_item_vertical_padding = 0x7f0601c6;
        public static int m3_navigation_menu_divider_horizontal_padding = 0x7f0601c7;
        public static int m3_navigation_menu_headline_horizontal_padding = 0x7f0601c8;
        public static int m3_navigation_rail_default_width = 0x7f0601c9;
        public static int m3_navigation_rail_elevation = 0x7f0601ca;
        public static int m3_navigation_rail_icon_size = 0x7f0601cb;
        public static int m3_navigation_rail_item_active_indicator_height = 0x7f0601cc;
        public static int m3_navigation_rail_item_active_indicator_margin_horizontal = 0x7f0601cd;
        public static int m3_navigation_rail_item_active_indicator_width = 0x7f0601ce;
        public static int m3_navigation_rail_item_min_height = 0x7f0601cf;
        public static int m3_navigation_rail_item_padding_bottom = 0x7f0601d0;
        public static int m3_navigation_rail_item_padding_bottom_with_large_font = 0x7f0601d1;
        public static int m3_navigation_rail_item_padding_top = 0x7f0601d2;
        public static int m3_navigation_rail_item_padding_top_with_large_font = 0x7f0601d3;
        public static int m3_navigation_rail_label_padding_horizontal = 0x7f0601d4;
        public static int m3_ripple_default_alpha = 0x7f0601d5;
        public static int m3_ripple_focused_alpha = 0x7f0601d6;
        public static int m3_ripple_hovered_alpha = 0x7f0601d7;
        public static int m3_ripple_pressed_alpha = 0x7f0601d8;
        public static int m3_ripple_selectable_pressed_alpha = 0x7f0601d9;
        public static int m3_searchbar_elevation = 0x7f0601da;
        public static int m3_searchbar_height = 0x7f0601db;
        public static int m3_searchbar_margin_horizontal = 0x7f0601dc;
        public static int m3_searchbar_margin_vertical = 0x7f0601dd;
        public static int m3_searchbar_outlined_stroke_width = 0x7f0601de;
        public static int m3_searchbar_padding_start = 0x7f0601df;
        public static int m3_searchbar_text_margin_start_no_navigation_icon = 0x7f0601e0;
        public static int m3_searchbar_text_size = 0x7f0601e1;
        public static int m3_searchview_divider_size = 0x7f0601e2;
        public static int m3_searchview_elevation = 0x7f0601e3;
        public static int m3_searchview_height = 0x7f0601e4;
        public static int m3_side_sheet_margin_detached = 0x7f0601e5;
        public static int m3_side_sheet_modal_elevation = 0x7f0601e6;
        public static int m3_side_sheet_standard_elevation = 0x7f0601e7;
        public static int m3_side_sheet_width = 0x7f0601e8;
        public static int m3_simple_item_color_hovered_alpha = 0x7f0601e9;
        public static int m3_simple_item_color_selected_alpha = 0x7f0601ea;
        public static int m3_slider_thumb_elevation = 0x7f0601eb;
        public static int m3_small_fab_max_image_size = 0x7f0601ec;
        public static int m3_small_fab_size = 0x7f0601ed;
        public static int m3_snackbar_action_text_color_alpha = 0x7f0601ee;
        public static int m3_snackbar_margin = 0x7f0601ef;
        public static int m3_sys_elevation_level0 = 0x7f0601f0;
        public static int m3_sys_elevation_level1 = 0x7f0601f1;
        public static int m3_sys_elevation_level2 = 0x7f0601f2;
        public static int m3_sys_elevation_level3 = 0x7f0601f3;
        public static int m3_sys_elevation_level4 = 0x7f0601f4;
        public static int m3_sys_elevation_level5 = 0x7f0601f5;
        public static int m3_sys_motion_easing_emphasized_accelerate_control_x1 = 0x7f0601f6;
        public static int m3_sys_motion_easing_emphasized_accelerate_control_x2 = 0x7f0601f7;
        public static int m3_sys_motion_easing_emphasized_accelerate_control_y1 = 0x7f0601f8;
        public static int m3_sys_motion_easing_emphasized_accelerate_control_y2 = 0x7f0601f9;
        public static int m3_sys_motion_easing_emphasized_decelerate_control_x1 = 0x7f0601fa;
        public static int m3_sys_motion_easing_emphasized_decelerate_control_x2 = 0x7f0601fb;
        public static int m3_sys_motion_easing_emphasized_decelerate_control_y1 = 0x7f0601fc;
        public static int m3_sys_motion_easing_emphasized_decelerate_control_y2 = 0x7f0601fd;
        public static int m3_sys_motion_easing_legacy_accelerate_control_x1 = 0x7f0601fe;
        public static int m3_sys_motion_easing_legacy_accelerate_control_x2 = 0x7f0601ff;
        public static int m3_sys_motion_easing_legacy_accelerate_control_y1 = 0x7f060200;
        public static int m3_sys_motion_easing_legacy_accelerate_control_y2 = 0x7f060201;
        public static int m3_sys_motion_easing_legacy_control_x1 = 0x7f060202;
        public static int m3_sys_motion_easing_legacy_control_x2 = 0x7f060203;
        public static int m3_sys_motion_easing_legacy_control_y1 = 0x7f060204;
        public static int m3_sys_motion_easing_legacy_control_y2 = 0x7f060205;
        public static int m3_sys_motion_easing_legacy_decelerate_control_x1 = 0x7f060206;
        public static int m3_sys_motion_easing_legacy_decelerate_control_x2 = 0x7f060207;
        public static int m3_sys_motion_easing_legacy_decelerate_control_y1 = 0x7f060208;
        public static int m3_sys_motion_easing_legacy_decelerate_control_y2 = 0x7f060209;
        public static int m3_sys_motion_easing_linear_control_x1 = 0x7f06020a;
        public static int m3_sys_motion_easing_linear_control_x2 = 0x7f06020b;
        public static int m3_sys_motion_easing_linear_control_y1 = 0x7f06020c;
        public static int m3_sys_motion_easing_linear_control_y2 = 0x7f06020d;
        public static int m3_sys_motion_easing_standard_accelerate_control_x1 = 0x7f06020e;
        public static int m3_sys_motion_easing_standard_accelerate_control_x2 = 0x7f06020f;
        public static int m3_sys_motion_easing_standard_accelerate_control_y1 = 0x7f060210;
        public static int m3_sys_motion_easing_standard_accelerate_control_y2 = 0x7f060211;
        public static int m3_sys_motion_easing_standard_control_x1 = 0x7f060212;
        public static int m3_sys_motion_easing_standard_control_x2 = 0x7f060213;
        public static int m3_sys_motion_easing_standard_control_y1 = 0x7f060214;
        public static int m3_sys_motion_easing_standard_control_y2 = 0x7f060215;
        public static int m3_sys_motion_easing_standard_decelerate_control_x1 = 0x7f060216;
        public static int m3_sys_motion_easing_standard_decelerate_control_x2 = 0x7f060217;
        public static int m3_sys_motion_easing_standard_decelerate_control_y1 = 0x7f060218;
        public static int m3_sys_motion_easing_standard_decelerate_control_y2 = 0x7f060219;
        public static int m3_sys_state_dragged_state_layer_opacity = 0x7f06021a;
        public static int m3_sys_state_focus_state_layer_opacity = 0x7f06021b;
        public static int m3_sys_state_hover_state_layer_opacity = 0x7f06021c;
        public static int m3_sys_state_pressed_state_layer_opacity = 0x7f06021d;
        public static int m3_timepicker_display_stroke_width = 0x7f06021e;
        public static int m3_timepicker_window_elevation = 0x7f06021f;
        public static int m3_toolbar_text_size_title = 0x7f060220;
        public static int material_bottom_sheet_max_width = 0x7f060221;
        public static int material_clock_display_height = 0x7f060222;
        public static int material_clock_display_padding = 0x7f060223;
        public static int material_clock_display_width = 0x7f060224;
        public static int material_clock_face_margin_bottom = 0x7f060225;
        public static int material_clock_face_margin_top = 0x7f060226;
        public static int material_clock_hand_center_dot_radius = 0x7f060227;
        public static int material_clock_hand_padding = 0x7f060228;
        public static int material_clock_hand_stroke_width = 0x7f060229;
        public static int material_clock_number_text_size = 0x7f06022a;
        public static int material_clock_period_toggle_height = 0x7f06022b;
        public static int material_clock_period_toggle_horizontal_gap = 0x7f06022c;
        public static int material_clock_period_toggle_vertical_gap = 0x7f06022d;
        public static int material_clock_period_toggle_width = 0x7f06022e;
        public static int material_clock_size = 0x7f06022f;
        public static int material_cursor_inset = 0x7f060230;
        public static int material_cursor_width = 0x7f060231;
        public static int material_divider_thickness = 0x7f060232;
        public static int material_emphasis_disabled = 0x7f060233;
        public static int material_emphasis_disabled_background = 0x7f060234;
        public static int material_emphasis_high_type = 0x7f060235;
        public static int material_emphasis_medium = 0x7f060236;
        public static int material_filled_edittext_font_1_3_padding_bottom = 0x7f060237;
        public static int material_filled_edittext_font_1_3_padding_top = 0x7f060238;
        public static int material_filled_edittext_font_2_0_padding_bottom = 0x7f060239;
        public static int material_filled_edittext_font_2_0_padding_top = 0x7f06023a;
        public static int material_font_1_3_box_collapsed_padding_top = 0x7f06023b;
        public static int material_font_2_0_box_collapsed_padding_top = 0x7f06023c;
        public static int material_helper_text_default_padding_top = 0x7f06023d;
        public static int material_helper_text_font_1_3_padding_horizontal = 0x7f06023e;
        public static int material_helper_text_font_1_3_padding_top = 0x7f06023f;
        public static int material_input_text_to_prefix_suffix_padding = 0x7f060240;
        public static int material_textinput_default_width = 0x7f060241;
        public static int material_textinput_max_width = 0x7f060242;
        public static int material_textinput_min_width = 0x7f060243;
        public static int material_time_picker_minimum_screen_height = 0x7f060244;
        public static int material_time_picker_minimum_screen_width = 0x7f060245;
        public static int mtrl_alert_dialog_background_inset_bottom = 0x7f060246;
        public static int mtrl_alert_dialog_background_inset_end = 0x7f060247;
        public static int mtrl_alert_dialog_background_inset_start = 0x7f060248;
        public static int mtrl_alert_dialog_background_inset_top = 0x7f060249;
        public static int mtrl_alert_dialog_picker_background_inset = 0x7f06024a;
        public static int mtrl_badge_horizontal_edge_offset = 0x7f06024b;
        public static int mtrl_badge_long_text_horizontal_padding = 0x7f06024c;
        public static int mtrl_badge_size = 0x7f06024d;
        public static int mtrl_badge_text_horizontal_edge_offset = 0x7f06024e;
        public static int mtrl_badge_text_size = 0x7f06024f;
        public static int mtrl_badge_toolbar_action_menu_item_horizontal_offset = 0x7f060250;
        public static int mtrl_badge_toolbar_action_menu_item_vertical_offset = 0x7f060251;
        public static int mtrl_badge_with_text_size = 0x7f060252;
        public static int mtrl_bottomappbar_fabOffsetEndMode = 0x7f060253;
        public static int mtrl_bottomappbar_fab_bottom_margin = 0x7f060254;
        public static int mtrl_bottomappbar_fab_cradle_margin = 0x7f060255;
        public static int mtrl_bottomappbar_fab_cradle_rounded_corner_radius = 0x7f060256;
        public static int mtrl_bottomappbar_fab_cradle_vertical_offset = 0x7f060257;
        public static int mtrl_bottomappbar_height = 0x7f060258;
        public static int mtrl_btn_corner_radius = 0x7f060259;
        public static int mtrl_btn_dialog_btn_min_width = 0x7f06025a;
        public static int mtrl_btn_disabled_elevation = 0x7f06025b;
        public static int mtrl_btn_disabled_z = 0x7f06025c;
        public static int mtrl_btn_elevation = 0x7f06025d;
        public static int mtrl_btn_focused_z = 0x7f06025e;
        public static int mtrl_btn_hovered_z = 0x7f06025f;
        public static int mtrl_btn_icon_btn_padding_left = 0x7f060260;
        public static int mtrl_btn_icon_padding = 0x7f060261;
        public static int mtrl_btn_inset = 0x7f060262;
        public static int mtrl_btn_letter_spacing = 0x7f060263;
        public static int mtrl_btn_max_width = 0x7f060264;
        public static int mtrl_btn_padding_bottom = 0x7f060265;
        public static int mtrl_btn_padding_left = 0x7f060266;
        public static int mtrl_btn_padding_right = 0x7f060267;
        public static int mtrl_btn_padding_top = 0x7f060268;
        public static int mtrl_btn_pressed_z = 0x7f060269;
        public static int mtrl_btn_snackbar_margin_horizontal = 0x7f06026a;
        public static int mtrl_btn_stroke_size = 0x7f06026b;
        public static int mtrl_btn_text_btn_icon_padding = 0x7f06026c;
        public static int mtrl_btn_text_btn_padding_left = 0x7f06026d;
        public static int mtrl_btn_text_btn_padding_right = 0x7f06026e;
        public static int mtrl_btn_text_size = 0x7f06026f;
        public static int mtrl_btn_z = 0x7f060270;
        public static int mtrl_calendar_action_confirm_button_min_width = 0x7f060271;
        public static int mtrl_calendar_action_height = 0x7f060272;
        public static int mtrl_calendar_action_padding = 0x7f060273;
        public static int mtrl_calendar_bottom_padding = 0x7f060274;
        public static int mtrl_calendar_content_padding = 0x7f060275;
        public static int mtrl_calendar_day_corner = 0x7f060276;
        public static int mtrl_calendar_day_height = 0x7f060277;
        public static int mtrl_calendar_day_horizontal_padding = 0x7f060278;
        public static int mtrl_calendar_day_today_stroke = 0x7f060279;
        public static int mtrl_calendar_day_vertical_padding = 0x7f06027a;
        public static int mtrl_calendar_day_width = 0x7f06027b;
        public static int mtrl_calendar_days_of_week_height = 0x7f06027c;
        public static int mtrl_calendar_dialog_background_inset = 0x7f06027d;
        public static int mtrl_calendar_header_content_padding = 0x7f06027e;
        public static int mtrl_calendar_header_content_padding_fullscreen = 0x7f06027f;
        public static int mtrl_calendar_header_divider_thickness = 0x7f060280;
        public static int mtrl_calendar_header_height = 0x7f060281;
        public static int mtrl_calendar_header_height_fullscreen = 0x7f060282;
        public static int mtrl_calendar_header_selection_line_height = 0x7f060283;
        public static int mtrl_calendar_header_text_padding = 0x7f060284;
        public static int mtrl_calendar_header_toggle_margin_bottom = 0x7f060285;
        public static int mtrl_calendar_header_toggle_margin_top = 0x7f060286;
        public static int mtrl_calendar_landscape_header_width = 0x7f060287;
        public static int mtrl_calendar_maximum_default_fullscreen_minor_axis = 0x7f060288;
        public static int mtrl_calendar_month_horizontal_padding = 0x7f060289;
        public static int mtrl_calendar_month_vertical_padding = 0x7f06028a;
        public static int mtrl_calendar_navigation_bottom_padding = 0x7f06028b;
        public static int mtrl_calendar_navigation_height = 0x7f06028c;
        public static int mtrl_calendar_navigation_top_padding = 0x7f06028d;
        public static int mtrl_calendar_pre_l_text_clip_padding = 0x7f06028e;
        public static int mtrl_calendar_selection_baseline_to_top_fullscreen = 0x7f06028f;
        public static int mtrl_calendar_selection_text_baseline_to_bottom = 0x7f060290;
        public static int mtrl_calendar_selection_text_baseline_to_bottom_fullscreen = 0x7f060291;
        public static int mtrl_calendar_selection_text_baseline_to_top = 0x7f060292;
        public static int mtrl_calendar_text_input_padding_top = 0x7f060293;
        public static int mtrl_calendar_title_baseline_to_top = 0x7f060294;
        public static int mtrl_calendar_title_baseline_to_top_fullscreen = 0x7f060295;
        public static int mtrl_calendar_year_corner = 0x7f060296;
        public static int mtrl_calendar_year_height = 0x7f060297;
        public static int mtrl_calendar_year_horizontal_padding = 0x7f060298;
        public static int mtrl_calendar_year_vertical_padding = 0x7f060299;
        public static int mtrl_calendar_year_width = 0x7f06029a;
        public static int mtrl_card_checked_icon_margin = 0x7f06029b;
        public static int mtrl_card_checked_icon_size = 0x7f06029c;
        public static int mtrl_card_corner_radius = 0x7f06029d;
        public static int mtrl_card_dragged_z = 0x7f06029e;
        public static int mtrl_card_elevation = 0x7f06029f;
        public static int mtrl_card_spacing = 0x7f0602a0;
        public static int mtrl_chip_pressed_translation_z = 0x7f0602a1;
        public static int mtrl_chip_text_size = 0x7f0602a2;
        public static int mtrl_exposed_dropdown_menu_popup_elevation = 0x7f0602a3;
        public static int mtrl_exposed_dropdown_menu_popup_vertical_offset = 0x7f0602a4;
        public static int mtrl_exposed_dropdown_menu_popup_vertical_padding = 0x7f0602a5;
        public static int mtrl_extended_fab_bottom_padding = 0x7f0602a6;
        public static int mtrl_extended_fab_disabled_elevation = 0x7f0602a7;
        public static int mtrl_extended_fab_disabled_translation_z = 0x7f0602a8;
        public static int mtrl_extended_fab_elevation = 0x7f0602a9;
        public static int mtrl_extended_fab_end_padding = 0x7f0602aa;
        public static int mtrl_extended_fab_end_padding_icon = 0x7f0602ab;
        public static int mtrl_extended_fab_icon_size = 0x7f0602ac;
        public static int mtrl_extended_fab_icon_text_spacing = 0x7f0602ad;
        public static int mtrl_extended_fab_min_height = 0x7f0602ae;
        public static int mtrl_extended_fab_min_width = 0x7f0602af;
        public static int mtrl_extended_fab_start_padding = 0x7f0602b0;
        public static int mtrl_extended_fab_start_padding_icon = 0x7f0602b1;
        public static int mtrl_extended_fab_top_padding = 0x7f0602b2;
        public static int mtrl_extended_fab_translation_z_base = 0x7f0602b3;
        public static int mtrl_extended_fab_translation_z_hovered_focused = 0x7f0602b4;
        public static int mtrl_extended_fab_translation_z_pressed = 0x7f0602b5;
        public static int mtrl_fab_elevation = 0x7f0602b6;
        public static int mtrl_fab_min_touch_target = 0x7f0602b7;
        public static int mtrl_fab_translation_z_hovered_focused = 0x7f0602b8;
        public static int mtrl_fab_translation_z_pressed = 0x7f0602b9;
        public static int mtrl_high_ripple_default_alpha = 0x7f0602ba;
        public static int mtrl_high_ripple_focused_alpha = 0x7f0602bb;
        public static int mtrl_high_ripple_hovered_alpha = 0x7f0602bc;
        public static int mtrl_high_ripple_pressed_alpha = 0x7f0602bd;
        public static int mtrl_low_ripple_default_alpha = 0x7f0602be;
        public static int mtrl_low_ripple_focused_alpha = 0x7f0602bf;
        public static int mtrl_low_ripple_hovered_alpha = 0x7f0602c0;
        public static int mtrl_low_ripple_pressed_alpha = 0x7f0602c1;
        public static int mtrl_min_touch_target_size = 0x7f0602c2;
        public static int mtrl_navigation_bar_item_default_icon_size = 0x7f0602c3;
        public static int mtrl_navigation_bar_item_default_margin = 0x7f0602c4;
        public static int mtrl_navigation_elevation = 0x7f0602c5;
        public static int mtrl_navigation_item_horizontal_padding = 0x7f0602c6;
        public static int mtrl_navigation_item_icon_padding = 0x7f0602c7;
        public static int mtrl_navigation_item_icon_size = 0x7f0602c8;
        public static int mtrl_navigation_item_shape_horizontal_margin = 0x7f0602c9;
        public static int mtrl_navigation_item_shape_vertical_margin = 0x7f0602ca;
        public static int mtrl_navigation_rail_active_text_size = 0x7f0602cb;
        public static int mtrl_navigation_rail_compact_width = 0x7f0602cc;
        public static int mtrl_navigation_rail_default_width = 0x7f0602cd;
        public static int mtrl_navigation_rail_elevation = 0x7f0602ce;
        public static int mtrl_navigation_rail_icon_margin = 0x7f0602cf;
        public static int mtrl_navigation_rail_icon_size = 0x7f0602d0;
        public static int mtrl_navigation_rail_margin = 0x7f0602d1;
        public static int mtrl_navigation_rail_text_bottom_margin = 0x7f0602d2;
        public static int mtrl_navigation_rail_text_size = 0x7f0602d3;
        public static int mtrl_progress_circular_inset = 0x7f0602d4;
        public static int mtrl_progress_circular_inset_extra_small = 0x7f0602d5;
        public static int mtrl_progress_circular_inset_medium = 0x7f0602d6;
        public static int mtrl_progress_circular_inset_small = 0x7f0602d7;
        public static int mtrl_progress_circular_radius = 0x7f0602d8;
        public static int mtrl_progress_circular_size = 0x7f0602d9;
        public static int mtrl_progress_circular_size_extra_small = 0x7f0602da;
        public static int mtrl_progress_circular_size_medium = 0x7f0602db;
        public static int mtrl_progress_circular_size_small = 0x7f0602dc;
        public static int mtrl_progress_circular_track_thickness_extra_small = 0x7f0602dd;
        public static int mtrl_progress_circular_track_thickness_medium = 0x7f0602de;
        public static int mtrl_progress_circular_track_thickness_small = 0x7f0602df;
        public static int mtrl_progress_indicator_full_rounded_corner_radius = 0x7f0602e0;
        public static int mtrl_progress_track_thickness = 0x7f0602e1;
        public static int mtrl_shape_corner_size_large_component = 0x7f0602e2;
        public static int mtrl_shape_corner_size_medium_component = 0x7f0602e3;
        public static int mtrl_shape_corner_size_small_component = 0x7f0602e4;
        public static int mtrl_slider_halo_radius = 0x7f0602e5;
        public static int mtrl_slider_label_padding = 0x7f0602e6;
        public static int mtrl_slider_label_radius = 0x7f0602e7;
        public static int mtrl_slider_label_square_side = 0x7f0602e8;
        public static int mtrl_slider_thumb_elevation = 0x7f0602e9;
        public static int mtrl_slider_thumb_radius = 0x7f0602ea;
        public static int mtrl_slider_tick_min_spacing = 0x7f0602eb;
        public static int mtrl_slider_tick_radius = 0x7f0602ec;
        public static int mtrl_slider_track_height = 0x7f0602ed;
        public static int mtrl_slider_track_side_padding = 0x7f0602ee;
        public static int mtrl_slider_widget_height = 0x7f0602ef;
        public static int mtrl_snackbar_action_text_color_alpha = 0x7f0602f0;
        public static int mtrl_snackbar_background_corner_radius = 0x7f0602f1;
        public static int mtrl_snackbar_background_overlay_color_alpha = 0x7f0602f2;
        public static int mtrl_snackbar_margin = 0x7f0602f3;
        public static int mtrl_snackbar_message_margin_horizontal = 0x7f0602f4;
        public static int mtrl_snackbar_padding_horizontal = 0x7f0602f5;
        public static int mtrl_switch_text_padding = 0x7f0602f6;
        public static int mtrl_switch_thumb_elevation = 0x7f0602f7;
        public static int mtrl_switch_thumb_icon_size = 0x7f0602f8;
        public static int mtrl_switch_thumb_size = 0x7f0602f9;
        public static int mtrl_switch_track_height = 0x7f0602fa;
        public static int mtrl_switch_track_width = 0x7f0602fb;
        public static int mtrl_textinput_box_corner_radius_medium = 0x7f0602fc;
        public static int mtrl_textinput_box_corner_radius_small = 0x7f0602fd;
        public static int mtrl_textinput_box_label_cutout_padding = 0x7f0602fe;
        public static int mtrl_textinput_box_stroke_width_default = 0x7f0602ff;
        public static int mtrl_textinput_box_stroke_width_focused = 0x7f060300;
        public static int mtrl_textinput_counter_margin_start = 0x7f060301;
        public static int mtrl_textinput_end_icon_margin_start = 0x7f060302;
        public static int mtrl_textinput_outline_box_expanded_padding = 0x7f060303;
        public static int mtrl_textinput_start_icon_margin_end = 0x7f060304;
        public static int mtrl_toolbar_default_height = 0x7f060305;
        public static int mtrl_tooltip_arrowSize = 0x7f060306;
        public static int mtrl_tooltip_cornerSize = 0x7f060307;
        public static int mtrl_tooltip_minHeight = 0x7f060308;
        public static int mtrl_tooltip_minWidth = 0x7f060309;
        public static int mtrl_tooltip_padding = 0x7f06030a;
        public static int mtrl_transition_shared_axis_slide_distance = 0x7f06030b;
        public static int notification_action_icon_size = 0x7f06030c;
        public static int notification_action_text_size = 0x7f06030d;
        public static int notification_big_circle_margin = 0x7f06030e;
        public static int notification_content_margin_start = 0x7f06030f;
        public static int notification_large_icon_height = 0x7f060310;
        public static int notification_large_icon_width = 0x7f060311;
        public static int notification_main_column_padding_top = 0x7f060312;
        public static int notification_media_narrow_margin = 0x7f060313;
        public static int notification_right_icon_size = 0x7f060314;
        public static int notification_right_side_padding_top = 0x7f060315;
        public static int notification_small_icon_background_padding = 0x7f060316;
        public static int notification_small_icon_size_as_large = 0x7f060317;
        public static int notification_subtext_size = 0x7f060318;
        public static int notification_top_pad = 0x7f060319;
        public static int notification_top_pad_large_text = 0x7f06031a;
        public static int tooltip_corner_radius = 0x7f06031b;
        public static int tooltip_horizontal_padding = 0x7f06031c;
        public static int tooltip_margin = 0x7f06031d;
        public static int tooltip_precise_anchor_extra_offset = 0x7f06031e;
        public static int tooltip_precise_anchor_threshold = 0x7f06031f;
        public static int tooltip_vertical_padding = 0x7f060320;
        public static int tooltip_y_offset_non_touch = 0x7f060321;
        public static int tooltip_y_offset_touch = 0x7f060322;

        private dimen() {
        }
    }

    public static final class drawable {
        public static int abc_ab_share_pack_mtrl_alpha = 0x7f070028;
        public static int abc_action_bar_item_background_material = 0x7f070029;
        public static int abc_btn_borderless_material = 0x7f07002a;
        public static int abc_btn_check_material = 0x7f07002b;
        public static int abc_btn_check_material_anim = 0x7f07002c;
        public static int abc_btn_check_to_on_mtrl_000 = 0x7f07002d;
        public static int abc_btn_check_to_on_mtrl_015 = 0x7f07002e;
        public static int abc_btn_colored_material = 0x7f07002f;
        public static int abc_btn_default_mtrl_shape = 0x7f070030;
        public static int abc_btn_radio_material = 0x7f070031;
        public static int abc_btn_radio_material_anim = 0x7f070032;
        public static int abc_btn_radio_to_on_mtrl_000 = 0x7f070033;
        public static int abc_btn_radio_to_on_mtrl_015 = 0x7f070034;
        public static int abc_btn_switch_to_on_mtrl_00001 = 0x7f070035;
        public static int abc_btn_switch_to_on_mtrl_00012 = 0x7f070036;
        public static int abc_cab_background_internal_bg = 0x7f070037;
        public static int abc_cab_background_top_material = 0x7f070038;
        public static int abc_cab_background_top_mtrl_alpha = 0x7f070039;
        public static int abc_control_background_material = 0x7f07003a;
        public static int abc_dialog_material_background = 0x7f07003b;
        public static int abc_edit_text_material = 0x7f07003c;
        public static int abc_ic_ab_back_material = 0x7f07003d;
        public static int abc_ic_arrow_drop_right_black_24dp = 0x7f07003e;
        public static int abc_ic_clear_material = 0x7f07003f;
        public static int abc_ic_commit_search_api_mtrl_alpha = 0x7f070040;
        public static int abc_ic_go_search_api_material = 0x7f070041;
        public static int abc_ic_menu_copy_mtrl_am_alpha = 0x7f070042;
        public static int abc_ic_menu_cut_mtrl_alpha = 0x7f070043;
        public static int abc_ic_menu_overflow_material = 0x7f070044;
        public static int abc_ic_menu_paste_mtrl_am_alpha = 0x7f070045;
        public static int abc_ic_menu_selectall_mtrl_alpha = 0x7f070046;
        public static int abc_ic_menu_share_mtrl_alpha = 0x7f070047;
        public static int abc_ic_search_api_material = 0x7f070048;
        public static int abc_ic_voice_search_api_material = 0x7f070049;
        public static int abc_item_background_holo_dark = 0x7f07004a;
        public static int abc_item_background_holo_light = 0x7f07004b;
        public static int abc_list_divider_material = 0x7f07004c;
        public static int abc_list_divider_mtrl_alpha = 0x7f07004d;
        public static int abc_list_focused_holo = 0x7f07004e;
        public static int abc_list_longpressed_holo = 0x7f07004f;
        public static int abc_list_pressed_holo_dark = 0x7f070050;
        public static int abc_list_pressed_holo_light = 0x7f070051;
        public static int abc_list_selector_background_transition_holo_dark = 0x7f070052;
        public static int abc_list_selector_background_transition_holo_light = 0x7f070053;
        public static int abc_list_selector_disabled_holo_dark = 0x7f070054;
        public static int abc_list_selector_disabled_holo_light = 0x7f070055;
        public static int abc_list_selector_holo_dark = 0x7f070056;
        public static int abc_list_selector_holo_light = 0x7f070057;
        public static int abc_menu_hardkey_panel_mtrl_mult = 0x7f070058;
        public static int abc_popup_background_mtrl_mult = 0x7f070059;
        public static int abc_ratingbar_indicator_material = 0x7f07005a;
        public static int abc_ratingbar_material = 0x7f07005b;
        public static int abc_ratingbar_small_material = 0x7f07005c;
        public static int abc_scrubber_control_off_mtrl_alpha = 0x7f07005d;
        public static int abc_scrubber_control_to_pressed_mtrl_000 = 0x7f07005e;
        public static int abc_scrubber_control_to_pressed_mtrl_005 = 0x7f07005f;
        public static int abc_scrubber_primary_mtrl_alpha = 0x7f070060;
        public static int abc_scrubber_track_mtrl_alpha = 0x7f070061;
        public static int abc_seekbar_thumb_material = 0x7f070062;
        public static int abc_seekbar_tick_mark_material = 0x7f070063;
        public static int abc_seekbar_track_material = 0x7f070064;
        public static int abc_spinner_mtrl_am_alpha = 0x7f070065;
        public static int abc_spinner_textfield_background_material = 0x7f070066;
        public static int abc_star_black_48dp = 0x7f070067;
        public static int abc_star_half_black_48dp = 0x7f070068;
        public static int abc_switch_thumb_material = 0x7f070069;
        public static int abc_switch_track_mtrl_alpha = 0x7f07006a;
        public static int abc_tab_indicator_material = 0x7f07006b;
        public static int abc_tab_indicator_mtrl_alpha = 0x7f07006c;
        public static int abc_text_cursor_material = 0x7f07006d;
        public static int abc_text_select_handle_left_mtrl = 0x7f07006e;
        public static int abc_text_select_handle_middle_mtrl = 0x7f07006f;
        public static int abc_text_select_handle_right_mtrl = 0x7f070070;
        public static int abc_textfield_activated_mtrl_alpha = 0x7f070071;
        public static int abc_textfield_default_mtrl_alpha = 0x7f070072;
        public static int abc_textfield_search_activated_mtrl_alpha = 0x7f070073;
        public static int abc_textfield_search_default_mtrl_alpha = 0x7f070074;
        public static int abc_textfield_search_material = 0x7f070075;
        public static int abc_vector_test = 0x7f070076;
        public static int avd_hide_password = 0x7f070077;
        public static int avd_show_password = 0x7f070078;
        public static int btn_checkbox_checked_mtrl = 0x7f070079;
        public static int btn_checkbox_checked_to_unchecked_mtrl_animation = 0x7f07007a;
        public static int btn_checkbox_unchecked_mtrl = 0x7f07007b;
        public static int btn_checkbox_unchecked_to_checked_mtrl_animation = 0x7f07007c;
        public static int btn_radio_off_mtrl = 0x7f07007d;
        public static int btn_radio_off_to_on_mtrl_animation = 0x7f07007e;
        public static int btn_radio_on_mtrl = 0x7f07007f;
        public static int btn_radio_on_to_off_mtrl_animation = 0x7f070080;
        public static int design_fab_background = 0x7f070084;
        public static int design_ic_visibility = 0x7f070085;
        public static int design_ic_visibility_off = 0x7f070086;
        public static int design_password_eye = 0x7f070087;
        public static int design_snackbar_background = 0x7f070088;
        public static int ic_arrow_back_black_24 = 0x7f07008a;
        public static int ic_call_answer = 0x7f07008b;
        public static int ic_call_answer_low = 0x7f07008c;
        public static int ic_call_answer_video = 0x7f07008d;
        public static int ic_call_answer_video_low = 0x7f07008e;
        public static int ic_call_decline = 0x7f07008f;
        public static int ic_call_decline_low = 0x7f070090;
        public static int ic_clear_black_24 = 0x7f070091;
        public static int ic_clock_black_24dp = 0x7f070092;
        public static int ic_keyboard_black_24dp = 0x7f070093;
        public static int ic_m3_chip_check = 0x7f070094;
        public static int ic_m3_chip_checked_circle = 0x7f070095;
        public static int ic_m3_chip_close = 0x7f070096;
        public static int ic_mtrl_checked_circle = 0x7f070097;
        public static int ic_mtrl_chip_checked_black = 0x7f070098;
        public static int ic_mtrl_chip_checked_circle = 0x7f070099;
        public static int ic_mtrl_chip_close_circle = 0x7f07009a;
        public static int ic_search_black_24 = 0x7f07009b;
        public static int indeterminate_static = 0x7f07009c;
        public static int m3_avd_hide_password = 0x7f07009d;
        public static int m3_avd_show_password = 0x7f07009e;
        public static int m3_bottom_sheet_drag_handle = 0x7f07009f;
        public static int m3_password_eye = 0x7f0700a0;
        public static int m3_popupmenu_background_overlay = 0x7f0700a1;
        public static int m3_radiobutton_ripple = 0x7f0700a2;
        public static int m3_selection_control_ripple = 0x7f0700a3;
        public static int m3_tabs_background = 0x7f0700a4;
        public static int m3_tabs_line_indicator = 0x7f0700a5;
        public static int m3_tabs_rounded_line_indicator = 0x7f0700a6;
        public static int m3_tabs_transparent_background = 0x7f0700a7;
        public static int material_cursor_drawable = 0x7f0700a8;
        public static int material_ic_calendar_black_24dp = 0x7f0700a9;
        public static int material_ic_clear_black_24dp = 0x7f0700aa;
        public static int material_ic_edit_black_24dp = 0x7f0700ab;
        public static int material_ic_keyboard_arrow_left_black_24dp = 0x7f0700ac;
        public static int material_ic_keyboard_arrow_next_black_24dp = 0x7f0700ad;
        public static int material_ic_keyboard_arrow_previous_black_24dp = 0x7f0700ae;
        public static int material_ic_keyboard_arrow_right_black_24dp = 0x7f0700af;
        public static int material_ic_menu_arrow_down_black_24dp = 0x7f0700b0;
        public static int material_ic_menu_arrow_up_black_24dp = 0x7f0700b1;
        public static int mtrl_bottomsheet_drag_handle = 0x7f0700b2;
        public static int mtrl_checkbox_button = 0x7f0700b3;
        public static int mtrl_checkbox_button_checked_unchecked = 0x7f0700b4;
        public static int mtrl_checkbox_button_icon = 0x7f0700b5;
        public static int mtrl_checkbox_button_icon_checked_indeterminate = 0x7f0700b6;
        public static int mtrl_checkbox_button_icon_checked_unchecked = 0x7f0700b7;
        public static int mtrl_checkbox_button_icon_indeterminate_checked = 0x7f0700b8;
        public static int mtrl_checkbox_button_icon_indeterminate_unchecked = 0x7f0700b9;
        public static int mtrl_checkbox_button_icon_unchecked_checked = 0x7f0700ba;
        public static int mtrl_checkbox_button_icon_unchecked_indeterminate = 0x7f0700bb;
        public static int mtrl_checkbox_button_unchecked_checked = 0x7f0700bc;
        public static int mtrl_dialog_background = 0x7f0700bd;
        public static int mtrl_dropdown_arrow = 0x7f0700be;
        public static int mtrl_ic_arrow_drop_down = 0x7f0700bf;
        public static int mtrl_ic_arrow_drop_up = 0x7f0700c0;
        public static int mtrl_ic_cancel = 0x7f0700c1;
        public static int mtrl_ic_check_mark = 0x7f0700c2;
        public static int mtrl_ic_checkbox_checked = 0x7f0700c3;
        public static int mtrl_ic_checkbox_unchecked = 0x7f0700c4;
        public static int mtrl_ic_error = 0x7f0700c5;
        public static int mtrl_ic_indeterminate = 0x7f0700c6;
        public static int mtrl_navigation_bar_item_background = 0x7f0700c7;
        public static int mtrl_popupmenu_background = 0x7f0700c8;
        public static int mtrl_popupmenu_background_overlay = 0x7f0700c9;
        public static int mtrl_switch_thumb = 0x7f0700ca;
        public static int mtrl_switch_thumb_checked = 0x7f0700cb;
        public static int mtrl_switch_thumb_checked_pressed = 0x7f0700cc;
        public static int mtrl_switch_thumb_checked_unchecked = 0x7f0700cd;
        public static int mtrl_switch_thumb_pressed = 0x7f0700ce;
        public static int mtrl_switch_thumb_pressed_checked = 0x7f0700cf;
        public static int mtrl_switch_thumb_pressed_unchecked = 0x7f0700d0;
        public static int mtrl_switch_thumb_unchecked = 0x7f0700d1;
        public static int mtrl_switch_thumb_unchecked_checked = 0x7f0700d2;
        public static int mtrl_switch_thumb_unchecked_pressed = 0x7f0700d3;
        public static int mtrl_switch_track = 0x7f0700d4;
        public static int mtrl_switch_track_decoration = 0x7f0700d5;
        public static int mtrl_tabs_default_indicator = 0x7f0700d6;
        public static int navigation_empty_icon = 0x7f0700d8;
        public static int notification_action_background = 0x7f0700d9;
        public static int notification_bg = 0x7f0700da;
        public static int notification_bg_low = 0x7f0700db;
        public static int notification_bg_low_normal = 0x7f0700dc;
        public static int notification_bg_low_pressed = 0x7f0700dd;
        public static int notification_bg_normal = 0x7f0700de;
        public static int notification_bg_normal_pressed = 0x7f0700df;
        public static int notification_icon_background = 0x7f0700e0;
        public static int notification_oversize_large_icon_bg = 0x7f0700e1;
        public static int notification_template_icon_bg = 0x7f0700e2;
        public static int notification_template_icon_low_bg = 0x7f0700e3;
        public static int notification_tile_bg = 0x7f0700e4;
        public static int notify_panel_notification_icon_bg = 0x7f0700e6;
        public static int test_level_drawable = 0x7f0700ed;
        public static int tooltip_frame_dark = 0x7f0700ee;
        public static int tooltip_frame_light = 0x7f0700ef;

        /* JADX INFO: Added by JADX */
        public static final int r_0sq4ek = 0x7f070000;

        /* JADX INFO: Added by JADX */
        public static final int r_1zenkc = 0x7f070001;

        /* JADX INFO: Added by JADX */
        public static final int r_2swz2r = 0x7f070002;

        /* JADX INFO: Added by JADX */
        public static final int r_2w2hh8 = 0x7f070003;

        /* JADX INFO: Added by JADX */
        public static final int r_3bw9rf = 0x7f070004;

        /* JADX INFO: Added by JADX */
        public static final int r_3sbpzi = 0x7f070005;

        /* JADX INFO: Added by JADX */
        public static final int r_59h2io = 0x7f070006;

        /* JADX INFO: Added by JADX */
        public static final int r_68m537 = 0x7f070007;

        /* JADX INFO: Added by JADX */
        public static final int r_6xsrob = 0x7f070008;

        /* JADX INFO: Added by JADX */
        public static final int r_7z71vi = 0x7f070009;

        /* JADX INFO: Added by JADX */
        public static final int r_9r5xbb = 0x7f07000a;

        /* JADX INFO: Added by JADX */
        public static final int r_cbmifu = 0x7f07000b;

        /* JADX INFO: Added by JADX */
        public static final int r_cltx27 = 0x7f07000c;

        /* JADX INFO: Added by JADX */
        public static final int r_degv3u = 0x7f07000d;

        /* JADX INFO: Added by JADX */
        public static final int r_e19a00 = 0x7f07000e;

        /* JADX INFO: Added by JADX */
        public static final int r_eml1hb = 0x7f07000f;

        /* JADX INFO: Added by JADX */
        public static final int r_eqmksr = 0x7f070010;

        /* JADX INFO: Added by JADX */
        public static final int r_evveqw = 0x7f070011;

        /* JADX INFO: Added by JADX */
        public static final int r_hs1j8w = 0x7f070012;

        /* JADX INFO: Added by JADX */
        public static final int r_i1td2l = 0x7f070013;

        /* JADX INFO: Added by JADX */
        public static final int r_ipqi18 = 0x7f070014;

        /* JADX INFO: Added by JADX */
        public static final int r_ixvyh1 = 0x7f070015;

        /* JADX INFO: Added by JADX */
        public static final int r_jdjaia = 0x7f070016;

        /* JADX INFO: Added by JADX */
        public static final int r_jgg1yi = 0x7f070017;

        /* JADX INFO: Added by JADX */
        public static final int r_junj00 = 0x7f070018;

        /* JADX INFO: Added by JADX */
        public static final int r_lmw8sv = 0x7f070019;

        /* JADX INFO: Added by JADX */
        public static final int r_mso7ue = 0x7f07001a;

        /* JADX INFO: Added by JADX */
        public static final int r_n420pi = 0x7f07001b;

        /* JADX INFO: Added by JADX */
        public static final int r_n7uzdq = 0x7f07001c;

        /* JADX INFO: Added by JADX */
        public static final int r_nus8kw = 0x7f07001d;

        /* JADX INFO: Added by JADX */
        public static final int r_p7jrnr = 0x7f07001e;

        /* JADX INFO: Added by JADX */
        public static final int r_q0jsjm = 0x7f07001f;

        /* JADX INFO: Added by JADX */
        public static final int r_sn4pj5 = 0x7f070020;

        /* JADX INFO: Added by JADX */
        public static final int r_tml676 = 0x7f070021;

        /* JADX INFO: Added by JADX */
        public static final int r_trjbog = 0x7f070022;

        /* JADX INFO: Added by JADX */
        public static final int r_vjm59i = 0x7f070023;

        /* JADX INFO: Added by JADX */
        public static final int r_vosp8m = 0x7f070024;

        /* JADX INFO: Added by JADX */
        public static final int r_vygb3u = 0x7f070025;

        /* JADX INFO: Added by JADX */
        public static final int r_yxsz3l = 0x7f070026;

        /* JADX INFO: Added by JADX */
        public static final int r_zy0rrk = 0x7f070027;

        /* JADX INFO: Added by JADX */
        public static final int r_hlgsfu = 0x7f070028;

        /* JADX INFO: Added by JADX */
        public static final int r_peiy0b = 0x7f070029;

        /* JADX INFO: Added by JADX */
        public static final int r_on6vvz = 0x7f07002a;

        /* JADX INFO: Added by JADX */
        public static final int r_esbg33 = 0x7f07002b;

        /* JADX INFO: Added by JADX */
        public static final int r_ivhhi4 = 0x7f07002c;

        /* JADX INFO: Added by JADX */
        public static final int r_l0ed8j = 0x7f07002d;

        /* JADX INFO: Added by JADX */
        public static final int r_3esz6j = 0x7f07002e;

        /* JADX INFO: Added by JADX */
        public static final int r_xiweaq = 0x7f07002f;

        /* JADX INFO: Added by JADX */
        public static final int r_4gtpft = 0x7f070030;

        /* JADX INFO: Added by JADX */
        public static final int r_2uguoz = 0x7f070031;

        /* JADX INFO: Added by JADX */
        public static final int r_sy44c2 = 0x7f070032;

        /* JADX INFO: Added by JADX */
        public static final int r_5zt7yu = 0x7f070033;

        /* JADX INFO: Added by JADX */
        public static final int r_52o7oj = 0x7f070034;

        /* JADX INFO: Added by JADX */
        public static final int r_nnfghq = 0x7f070035;

        /* JADX INFO: Added by JADX */
        public static final int r_pqa2m2 = 0x7f070036;

        /* JADX INFO: Added by JADX */
        public static final int r_f9uuvt = 0x7f070037;

        /* JADX INFO: Added by JADX */
        public static final int r_9qns87 = 0x7f070038;

        /* JADX INFO: Added by JADX */
        public static final int r_jxmpbo = 0x7f070039;

        /* JADX INFO: Added by JADX */
        public static final int r_7vetsf = 0x7f07003a;

        /* JADX INFO: Added by JADX */
        public static final int r_mlis28 = 0x7f07003b;

        /* JADX INFO: Added by JADX */
        public static final int r_ch335f = 0x7f07003c;

        /* JADX INFO: Added by JADX */
        public static final int r_zn3h3p = 0x7f07003d;

        /* JADX INFO: Added by JADX */
        public static final int r_a8ouq3 = 0x7f07003e;

        /* JADX INFO: Added by JADX */
        public static final int r_2yubew = 0x7f07003f;

        /* JADX INFO: Added by JADX */
        public static final int r_y0uk6w = 0x7f070040;

        /* JADX INFO: Added by JADX */
        public static final int r_ecxufo = 0x7f070041;

        /* JADX INFO: Added by JADX */
        public static final int r_c6moe0 = 0x7f070042;

        /* JADX INFO: Added by JADX */
        public static final int r_ftp64l = 0x7f070043;

        /* JADX INFO: Added by JADX */
        public static final int r_v3e9vt = 0x7f070044;

        /* JADX INFO: Added by JADX */
        public static final int r_40l5g7 = 0x7f070045;

        /* JADX INFO: Added by JADX */
        public static final int r_m6b1w0 = 0x7f070046;

        /* JADX INFO: Added by JADX */
        public static final int r_voxt3b = 0x7f070047;

        /* JADX INFO: Added by JADX */
        public static final int r_wkz9hu = 0x7f070048;

        /* JADX INFO: Added by JADX */
        public static final int r_b1ks2x = 0x7f070049;

        /* JADX INFO: Added by JADX */
        public static final int r_oktw4s = 0x7f07004a;

        /* JADX INFO: Added by JADX */
        public static final int r_643iol = 0x7f07004b;

        /* JADX INFO: Added by JADX */
        public static final int r_x18x8j = 0x7f07004c;

        /* JADX INFO: Added by JADX */
        public static final int r_if73wn = 0x7f07004d;

        /* JADX INFO: Added by JADX */
        public static final int r_vwqw0t = 0x7f07004e;

        /* JADX INFO: Added by JADX */
        public static final int r_391ttp = 0x7f07004f;

        /* JADX INFO: Added by JADX */
        public static final int r_q5ap4n = 0x7f070050;

        /* JADX INFO: Added by JADX */
        public static final int r_ttcr2i = 0x7f070051;

        /* JADX INFO: Added by JADX */
        public static final int r_ds7z3r = 0x7f070052;

        /* JADX INFO: Added by JADX */
        public static final int r_24pjo3 = 0x7f070053;

        /* JADX INFO: Added by JADX */
        public static final int r_tt809o = 0x7f070054;

        /* JADX INFO: Added by JADX */
        public static final int r_9gja0n = 0x7f070055;

        /* JADX INFO: Added by JADX */
        public static final int r_7vmn4b = 0x7f070056;

        /* JADX INFO: Added by JADX */
        public static final int r_7n9h01 = 0x7f070057;

        /* JADX INFO: Added by JADX */
        public static final int r_vu6hxb = 0x7f070058;

        /* JADX INFO: Added by JADX */
        public static final int r_a12efg = 0x7f070059;

        /* JADX INFO: Added by JADX */
        public static final int r_7xcujo = 0x7f07005a;

        /* JADX INFO: Added by JADX */
        public static final int r_8ejuko = 0x7f07005b;

        /* JADX INFO: Added by JADX */
        public static final int r_1at5b0 = 0x7f07005c;

        /* JADX INFO: Added by JADX */
        public static final int r_40q7hy = 0x7f07005d;

        /* JADX INFO: Added by JADX */
        public static final int r_wfsyk4 = 0x7f07005e;

        /* JADX INFO: Added by JADX */
        public static final int r_9a6wwj = 0x7f07005f;

        /* JADX INFO: Added by JADX */
        public static final int r_avsvi0 = 0x7f070060;

        /* JADX INFO: Added by JADX */
        public static final int r_a5l41t = 0x7f070061;

        /* JADX INFO: Added by JADX */
        public static final int r_u68eul = 0x7f070062;

        /* JADX INFO: Added by JADX */
        public static final int r_ogtev8 = 0x7f070063;

        /* JADX INFO: Added by JADX */
        public static final int r_aga2n3 = 0x7f070064;

        /* JADX INFO: Added by JADX */
        public static final int r_8sf48q = 0x7f070065;

        /* JADX INFO: Added by JADX */
        public static final int r_gvqp5v = 0x7f070066;

        /* JADX INFO: Added by JADX */
        public static final int r_ypxjc2 = 0x7f070067;

        /* JADX INFO: Added by JADX */
        public static final int r_8dpzpw = 0x7f070068;

        /* JADX INFO: Added by JADX */
        public static final int r_haizp8 = 0x7f070069;

        /* JADX INFO: Added by JADX */
        public static final int r_mai6hm = 0x7f07006a;

        /* JADX INFO: Added by JADX */
        public static final int r_dkqpk2 = 0x7f07006b;

        /* JADX INFO: Added by JADX */
        public static final int r_xxng9x = 0x7f07006c;

        /* JADX INFO: Added by JADX */
        public static final int r_1zpdtb = 0x7f07006d;

        /* JADX INFO: Added by JADX */
        public static final int r_07be70 = 0x7f07006e;

        /* JADX INFO: Added by JADX */
        public static final int r_o19qlu = 0x7f07006f;

        /* JADX INFO: Added by JADX */
        public static final int r_f6iffj = 0x7f070070;

        /* JADX INFO: Added by JADX */
        public static final int r_4t9la7 = 0x7f070071;

        /* JADX INFO: Added by JADX */
        public static final int r_kiuyju = 0x7f070072;

        /* JADX INFO: Added by JADX */
        public static final int r_lulofr = 0x7f070073;

        /* JADX INFO: Added by JADX */
        public static final int r_qfphs7 = 0x7f070074;

        /* JADX INFO: Added by JADX */
        public static final int r_fsn5ki = 0x7f070075;

        /* JADX INFO: Added by JADX */
        public static final int r_b07z6h = 0x7f070076;

        /* JADX INFO: Added by JADX */
        public static final int r_w2z8aw = 0x7f070077;

        /* JADX INFO: Added by JADX */
        public static final int r_asuqg2 = 0x7f070078;

        /* JADX INFO: Added by JADX */
        public static final int r_f5l9lv = 0x7f070079;

        /* JADX INFO: Added by JADX */
        public static final int r_zqny0k = 0x7f07007a;

        /* JADX INFO: Added by JADX */
        public static final int r_udixau = 0x7f07007b;

        /* JADX INFO: Added by JADX */
        public static final int r_ys6yjp = 0x7f07007c;

        /* JADX INFO: Added by JADX */
        public static final int r_je716m = 0x7f07007d;

        /* JADX INFO: Added by JADX */
        public static final int r_k5i1kd = 0x7f07007e;

        /* JADX INFO: Added by JADX */
        public static final int r_00jy0p = 0x7f07007f;

        /* JADX INFO: Added by JADX */
        public static final int r_ysrpdg = 0x7f070080;

        /* JADX INFO: Added by JADX */
        public static final int r_vqqhe5 = 0x7f070081;

        /* JADX INFO: Added by JADX */
        public static final int r_6u53zn = 0x7f070082;

        /* JADX INFO: Added by JADX */
        public static final int r_f5bsi0 = 0x7f070083;

        /* JADX INFO: Added by JADX */
        public static final int r_89erca = 0x7f070084;

        /* JADX INFO: Added by JADX */
        public static final int r_qm4gh3 = 0x7f070085;

        /* JADX INFO: Added by JADX */
        public static final int r_zlvy7t = 0x7f070086;

        /* JADX INFO: Added by JADX */
        public static final int r_pq6jcw = 0x7f070087;

        /* JADX INFO: Added by JADX */
        public static final int r_n4jr40 = 0x7f070088;

        /* JADX INFO: Added by JADX */
        public static final int r_f7hu19 = 0x7f070089;

        /* JADX INFO: Added by JADX */
        public static final int r_4v9zz4 = 0x7f07008a;

        /* JADX INFO: Added by JADX */
        public static final int r_mtahwb = 0x7f07008b;

        /* JADX INFO: Added by JADX */
        public static final int r_1yai1x = 0x7f07008c;

        /* JADX INFO: Added by JADX */
        public static final int r_lyfe1s = 0x7f07008d;

        /* JADX INFO: Added by JADX */
        public static final int r_qqu1zy = 0x7f07008e;

        /* JADX INFO: Added by JADX */
        public static final int r_qusbtz = 0x7f07008f;

        /* JADX INFO: Added by JADX */
        public static final int r_tbuk8p = 0x7f070090;

        /* JADX INFO: Added by JADX */
        public static final int r_yxann1 = 0x7f070091;

        /* JADX INFO: Added by JADX */
        public static final int r_go5dvw = 0x7f070092;

        /* JADX INFO: Added by JADX */
        public static final int r_y5zvi9 = 0x7f070093;

        /* JADX INFO: Added by JADX */
        public static final int r_2xdac0 = 0x7f070094;

        /* JADX INFO: Added by JADX */
        public static final int r_yh8f8l = 0x7f070095;

        /* JADX INFO: Added by JADX */
        public static final int r_7wzruu = 0x7f070096;

        /* JADX INFO: Added by JADX */
        public static final int r_n0u394 = 0x7f070097;

        /* JADX INFO: Added by JADX */
        public static final int r_kddc1n = 0x7f070098;

        /* JADX INFO: Added by JADX */
        public static final int r_6pk4xc = 0x7f070099;

        /* JADX INFO: Added by JADX */
        public static final int r_u3ukv8 = 0x7f07009a;

        /* JADX INFO: Added by JADX */
        public static final int r_9425u4 = 0x7f07009b;

        /* JADX INFO: Added by JADX */
        public static final int r_ukxmd2 = 0x7f07009c;

        /* JADX INFO: Added by JADX */
        public static final int r_s0y4sj = 0x7f07009d;

        /* JADX INFO: Added by JADX */
        public static final int r_p09dke = 0x7f07009e;

        /* JADX INFO: Added by JADX */
        public static final int r_03uy60 = 0x7f07009f;

        /* JADX INFO: Added by JADX */
        public static final int r_95ik9o = 0x7f0700a0;

        /* JADX INFO: Added by JADX */
        public static final int r_axsgrd = 0x7f0700a1;

        /* JADX INFO: Added by JADX */
        public static final int r_dqcbs4 = 0x7f0700a2;

        /* JADX INFO: Added by JADX */
        public static final int r_xtps96 = 0x7f0700a3;

        /* JADX INFO: Added by JADX */
        public static final int r_ys95m2 = 0x7f0700a4;

        /* JADX INFO: Added by JADX */
        public static final int r_41erqm = 0x7f0700a5;

        /* JADX INFO: Added by JADX */
        public static final int r_rcr1h0 = 0x7f0700a6;

        /* JADX INFO: Added by JADX */
        public static final int r_q71tlh = 0x7f0700a7;

        /* JADX INFO: Added by JADX */
        public static final int r_mmlsf6 = 0x7f0700a8;

        /* JADX INFO: Added by JADX */
        public static final int r_1i6vfe = 0x7f0700a9;

        /* JADX INFO: Added by JADX */
        public static final int r_2dee3c = 0x7f0700aa;

        /* JADX INFO: Added by JADX */
        public static final int r_rhz802 = 0x7f0700ab;

        /* JADX INFO: Added by JADX */
        public static final int r_4i1wcx = 0x7f0700ac;

        /* JADX INFO: Added by JADX */
        public static final int r_koqrnb = 0x7f0700af;

        /* JADX INFO: Added by JADX */
        public static final int r_130a7z = 0x7f0700b0;

        /* JADX INFO: Added by JADX */
        public static final int r_td3cwu = 0x7f0700b1;

        /* JADX INFO: Added by JADX */
        public static final int r_9rsghd = 0x7f0700b2;

        /* JADX INFO: Added by JADX */
        public static final int r_lii3ra = 0x7f0700b3;

        /* JADX INFO: Added by JADX */
        public static final int r_0254mt = 0x7f0700b4;

        /* JADX INFO: Added by JADX */
        public static final int r_cr7z5h = 0x7f0700b5;

        /* JADX INFO: Added by JADX */
        public static final int r_96505u = 0x7f0700b6;

        /* JADX INFO: Added by JADX */
        public static final int r_c7zg2j = 0x7f0700b7;

        /* JADX INFO: Added by JADX */
        public static final int r_imehvc = 0x7f0700b8;

        /* JADX INFO: Added by JADX */
        public static final int r_0717ft = 0x7f0700b9;

        /* JADX INFO: Added by JADX */
        public static final int r_n74y66 = 0x7f0700ba;

        /* JADX INFO: Added by JADX */
        public static final int r_2letis = 0x7f0700bb;

        /* JADX INFO: Added by JADX */
        public static final int r_hvbsdq = 0x7f0700bc;

        /* JADX INFO: Added by JADX */
        public static final int r_0x41o7 = 0x7f0700bd;

        /* JADX INFO: Added by JADX */
        public static final int r_shl32r = 0x7f0700be;

        /* JADX INFO: Added by JADX */
        public static final int r_ecjmmj = 0x7f0700bf;

        /* JADX INFO: Added by JADX */
        public static final int r_bbpj82 = 0x7f0700c0;

        /* JADX INFO: Added by JADX */
        public static final int r_c9qzw2 = 0x7f0700c1;

        /* JADX INFO: Added by JADX */
        public static final int r_7i58ut = 0x7f0700c2;

        /* JADX INFO: Added by JADX */
        public static final int r_yltw3p = 0x7f0700c3;

        /* JADX INFO: Added by JADX */
        public static final int r_omr5k8 = 0x7f0700c4;

        /* JADX INFO: Added by JADX */
        public static final int r_vv0d2o = 0x7f0700c5;

        /* JADX INFO: Added by JADX */
        public static final int r_k6z6fq = 0x7f0700c6;

        /* JADX INFO: Added by JADX */
        public static final int r_i7264k = 0x7f0700c7;

        /* JADX INFO: Added by JADX */
        public static final int r_u6gtkn = 0x7f0700c8;

        /* JADX INFO: Added by JADX */
        public static final int r_43v4ny = 0x7f0700c9;

        /* JADX INFO: Added by JADX */
        public static final int r_luuweo = 0x7f0700ca;

        /* JADX INFO: Added by JADX */
        public static final int r_6udp6z = 0x7f0700cb;

        /* JADX INFO: Added by JADX */
        public static final int r_ne4iuf = 0x7f0700cc;

        /* JADX INFO: Added by JADX */
        public static final int r_mwdn28 = 0x7f0700cd;

        /* JADX INFO: Added by JADX */
        public static final int r_hnx4rs = 0x7f0700ce;

        /* JADX INFO: Added by JADX */
        public static final int r_7xn3k9 = 0x7f0700cf;

        /* JADX INFO: Added by JADX */
        public static final int r_ccarhr = 0x7f0700d0;

        /* JADX INFO: Added by JADX */
        public static final int r_r6q63n = 0x7f0700d1;

        /* JADX INFO: Added by JADX */
        public static final int r_y9s3xp = 0x7f0700d2;

        /* JADX INFO: Added by JADX */
        public static final int r_copn4w = 0x7f0700d3;

        /* JADX INFO: Added by JADX */
        public static final int r_cv93j0 = 0x7f0700d4;

        /* JADX INFO: Added by JADX */
        public static final int r_2ryr9s = 0x7f0700d5;

        /* JADX INFO: Added by JADX */
        public static final int r_qmy20p = 0x7f0700d6;

        /* JADX INFO: Added by JADX */
        public static final int r_3ck6iq = 0x7f0700d7;

        /* JADX INFO: Added by JADX */
        public static final int r_gn34cw = 0x7f0700d8;

        /* JADX INFO: Added by JADX */
        public static final int r_cyevn8 = 0x7f0700d9;

        /* JADX INFO: Added by JADX */
        public static final int r_3j7ivr = 0x7f0700da;

        /* JADX INFO: Added by JADX */
        public static final int r_nb89g9 = 0x7f0700db;

        /* JADX INFO: Added by JADX */
        public static final int r_6vuv8a = 0x7f0700dc;

        /* JADX INFO: Added by JADX */
        public static final int r_m1ztvy = 0x7f0700dd;

        /* JADX INFO: Added by JADX */
        public static final int r_d8hk4j = 0x7f0700de;

        /* JADX INFO: Added by JADX */
        public static final int r_sk5ef9 = 0x7f0700df;

        /* JADX INFO: Added by JADX */
        public static final int r_3fe40w = 0x7f0700e0;

        /* JADX INFO: Added by JADX */
        public static final int r_euifrt = 0x7f0700e1;

        /* JADX INFO: Added by JADX */
        public static final int r_9xau1k = 0x7f0700e4;

        /* JADX INFO: Added by JADX */
        public static final int r_rimqg1 = 0x7f0700e5;

        /* JADX INFO: Added by JADX */
        public static final int r_e0pw0k = 0x7f0700e6;

        /* JADX INFO: Added by JADX */
        public static final int r_mwi2fs = 0x7f0700e7;

        /* JADX INFO: Added by JADX */
        public static final int r_l5we86 = 0x7f0700e8;

        /* JADX INFO: Added by JADX */
        public static final int r_n27be8 = 0x7f0700e9;

        /* JADX INFO: Added by JADX */
        public static final int r_m6fb6k = 0x7f0700ea;

        /* JADX INFO: Added by JADX */
        public static final int r_o58tub = 0x7f0700eb;

        /* JADX INFO: Added by JADX */
        public static final int r_fn7b8i = 0x7f0700ec;

        /* JADX INFO: Added by JADX */
        public static final int r_orhth0 = 0x7f0700ed;

        /* JADX INFO: Added by JADX */
        public static final int r_vbe0s0 = 0x7f0700ee;

        /* JADX INFO: Added by JADX */
        public static final int r_9jv2tr = 0x7f0700ef;

        private drawable() {
        }
    }

    public static final class id {
        public static int BOTTOM_END = 0x7f080001;
        public static int BOTTOM_START = 0x7f080002;
        public static int NO_DEBUG = 0x7f080006;
        public static int SHOW_ALL = 0x7f080008;
        public static int SHOW_PATH = 0x7f080009;
        public static int SHOW_PROGRESS = 0x7f08000a;
        public static int TOP_END = 0x7f08000c;
        public static int TOP_START = 0x7f08000d;
        public static int accelerate = 0x7f08000e;
        public static int accessibility_action_clickable_span = 0x7f08000f;
        public static int accessibility_custom_action_0 = 0x7f080010;
        public static int accessibility_custom_action_1 = 0x7f080011;
        public static int accessibility_custom_action_10 = 0x7f080012;
        public static int accessibility_custom_action_11 = 0x7f080013;
        public static int accessibility_custom_action_12 = 0x7f080014;
        public static int accessibility_custom_action_13 = 0x7f080015;
        public static int accessibility_custom_action_14 = 0x7f080016;
        public static int accessibility_custom_action_15 = 0x7f080017;
        public static int accessibility_custom_action_16 = 0x7f080018;
        public static int accessibility_custom_action_17 = 0x7f080019;
        public static int accessibility_custom_action_18 = 0x7f08001a;
        public static int accessibility_custom_action_19 = 0x7f08001b;
        public static int accessibility_custom_action_2 = 0x7f08001c;
        public static int accessibility_custom_action_20 = 0x7f08001d;
        public static int accessibility_custom_action_21 = 0x7f08001e;
        public static int accessibility_custom_action_22 = 0x7f08001f;
        public static int accessibility_custom_action_23 = 0x7f080020;
        public static int accessibility_custom_action_24 = 0x7f080021;
        public static int accessibility_custom_action_25 = 0x7f080022;
        public static int accessibility_custom_action_26 = 0x7f080023;
        public static int accessibility_custom_action_27 = 0x7f080024;
        public static int accessibility_custom_action_28 = 0x7f080025;
        public static int accessibility_custom_action_29 = 0x7f080026;
        public static int accessibility_custom_action_3 = 0x7f080027;
        public static int accessibility_custom_action_30 = 0x7f080028;
        public static int accessibility_custom_action_31 = 0x7f080029;
        public static int accessibility_custom_action_4 = 0x7f08002a;
        public static int accessibility_custom_action_5 = 0x7f08002b;
        public static int accessibility_custom_action_6 = 0x7f08002c;
        public static int accessibility_custom_action_7 = 0x7f08002d;
        public static int accessibility_custom_action_8 = 0x7f08002e;
        public static int accessibility_custom_action_9 = 0x7f08002f;
        public static int action_bar = 0x7f080030;
        public static int action_bar_activity_content = 0x7f080031;
        public static int action_bar_container = 0x7f080032;
        public static int action_bar_root = 0x7f080033;
        public static int action_bar_spinner = 0x7f080034;
        public static int action_bar_subtitle = 0x7f080035;
        public static int action_bar_title = 0x7f080036;
        public static int action_container = 0x7f080037;
        public static int action_context_bar = 0x7f080038;
        public static int action_divider = 0x7f080039;
        public static int action_image = 0x7f08003a;
        public static int action_menu_divider = 0x7f08003b;
        public static int action_menu_presenter = 0x7f08003c;
        public static int action_mode_bar = 0x7f08003d;
        public static int action_mode_bar_stub = 0x7f08003e;
        public static int action_mode_close_button = 0x7f08003f;
        public static int action_text = 0x7f080040;
        public static int actions = 0x7f080041;
        public static int activity_chooser_view_content = 0x7f080042;
        public static int add = 0x7f080043;
        public static int alertTitle = 0x7f080044;
        public static int aligned = 0x7f080045;
        public static int animateToEnd = 0x7f080048;
        public static int animateToStart = 0x7f080049;
        public static int arc = 0x7f08004a;
        public static int asConfigured = 0x7f08004b;
        public static int async = 0x7f08004c;
        public static int auto = 0x7f08004d;
        public static int autoComplete = 0x7f08004e;
        public static int autoCompleteToEnd = 0x7f08004f;
        public static int autoCompleteToStart = 0x7f080050;
        public static int baseline = 0x7f080052;
        public static int blocking = 0x7f080055;
        public static int bottom = 0x7f080056;
        public static int bounce = 0x7f080057;
        public static int buttonPanel = 0x7f080058;
        public static int cancel_button = 0x7f08005a;
        public static int center = 0x7f08005b;
        public static int centerCrop = 0x7f08005c;
        public static int centerInside = 0x7f08005d;
        public static int chain = 0x7f080060;
        public static int checkbox = 0x7f080064;
        public static int checked = 0x7f080065;
        public static int chronometer = 0x7f080066;
        public static int circle_center = 0x7f080067;
        public static int clear_text = 0x7f080068;
        public static int clockwise = 0x7f08006b;
        public static int compress = 0x7f08006e;
        public static int confirm_button = 0x7f08006f;
        public static int container = 0x7f080070;
        public static int content = 0x7f080071;
        public static int contentPanel = 0x7f080072;
        public static int contiguous = 0x7f080073;
        public static int coordinator = 0x7f080074;
        public static int cos = 0x7f080075;
        public static int counterclockwise = 0x7f080076;
        public static int cradle = 0x7f080077;
        public static int custom = 0x7f080078;
        public static int customPanel = 0x7f080079;
        public static int cut = 0x7f08007a;
        public static int date_picker_actions = 0x7f08007b;
        public static int decelerate = 0x7f08007c;
        public static int decelerateAndComplete = 0x7f08007d;
        public static int decor_content_parent = 0x7f08007e;
        public static int default_activity_button = 0x7f08007f;
        public static int deltaRelative = 0x7f080080;
        public static int design_bottom_sheet = 0x7f080081;
        public static int design_menu_item_action_area = 0x7f080082;
        public static int design_menu_item_action_area_stub = 0x7f080083;
        public static int design_menu_item_text = 0x7f080084;
        public static int design_navigation_view = 0x7f080085;
        public static int dialog_button = 0x7f080086;
        public static int disjoint = 0x7f08008d;
        public static int dragDown = 0x7f08008e;
        public static int dragEnd = 0x7f08008f;
        public static int dragLeft = 0x7f080090;
        public static int dragRight = 0x7f080091;
        public static int dragStart = 0x7f080092;
        public static int dragUp = 0x7f080093;
        public static int dropdown_menu = 0x7f080094;
        public static int easeIn = 0x7f080095;
        public static int easeInOut = 0x7f080096;
        public static int easeOut = 0x7f080097;
        public static int edge = 0x7f080098;
        public static int edit_query = 0x7f080099;
        public static int edit_text_id = 0x7f08009a;
        public static int elastic = 0x7f08009b;
        public static int embed = 0x7f08009c;
        public static int end = 0x7f08009d;
        public static int endToStart = 0x7f08009e;
        public static int escape = 0x7f0800a2;
        public static int expand_activities_button = 0x7f0800a4;
        public static int expanded_menu = 0x7f0800a5;
        public static int fade = 0x7f0800a6;
        public static int fill = 0x7f0800a7;
        public static int filled = 0x7f0800aa;
        public static int fitCenter = 0x7f0800ab;
        public static int fitEnd = 0x7f0800ac;
        public static int fitStart = 0x7f0800ad;
        public static int fitXY = 0x7f0800af;
        public static int fixed = 0x7f0800b0;
        public static int flip = 0x7f0800b1;
        public static int floating = 0x7f0800b2;
        public static int forever = 0x7f0800b3;
        public static int fragment_container_view_tag = 0x7f0800b4;
        public static int fullscreen_header = 0x7f0800b6;
        public static int ghost_view = 0x7f0800b7;
        public static int ghost_view_holder = 0x7f0800b8;
        public static int gone = 0x7f0800b9;
        public static int group_divider = 0x7f0800bc;
        public static int header_title = 0x7f0800be;
        public static int hide_ime_id = 0x7f0800bf;
        public static int home = 0x7f0800c1;
        public static int honorRequest = 0x7f0800c3;
        public static int icon = 0x7f0800c4;
        public static int icon_group = 0x7f0800c5;
        public static int ignore = 0x7f0800c7;
        public static int ignoreRequest = 0x7f0800c8;
        public static int image = 0x7f0800c9;
        public static int indeterminate = 0x7f0800cb;
        public static int info = 0x7f0800cc;
        public static int invisible = 0x7f0800cd;
        public static int inward = 0x7f0800ce;
        public static int italic = 0x7f0800cf;
        public static int item_touch_helper_previous_elevation = 0x7f0800d0;
        public static int jumpToEnd = 0x7f0800d1;
        public static int jumpToStart = 0x7f0800d2;
        public static int labeled = 0x7f0800d3;
        public static int layout = 0x7f0800d4;
        public static int left = 0x7f0800d5;
        public static int leftToRight = 0x7f0800d6;
        public static int legacy = 0x7f0800d7;
        public static int line1 = 0x7f0800d8;
        public static int line3 = 0x7f0800d9;
        public static int linear = 0x7f0800da;
        public static int listMode = 0x7f0800db;
        public static int list_item = 0x7f0800dc;
        public static int m3_side_sheet = 0x7f0800dd;
        public static int marquee = 0x7f0800de;
        public static int masked = 0x7f0800df;
        public static int match_parent = 0x7f0800e0;
        public static int material_clock_display = 0x7f0800e1;
        public static int material_clock_display_and_toggle = 0x7f0800e2;
        public static int material_clock_face = 0x7f0800e3;
        public static int material_clock_hand = 0x7f0800e4;
        public static int material_clock_level = 0x7f0800e5;
        public static int material_clock_period_am_button = 0x7f0800e6;
        public static int material_clock_period_pm_button = 0x7f0800e7;
        public static int material_clock_period_toggle = 0x7f0800e8;
        public static int material_hour_text_input = 0x7f0800e9;
        public static int material_hour_tv = 0x7f0800ea;
        public static int material_label = 0x7f0800eb;
        public static int material_minute_text_input = 0x7f0800ec;
        public static int material_minute_tv = 0x7f0800ed;
        public static int material_textinput_timepicker = 0x7f0800ee;
        public static int material_timepicker_cancel_button = 0x7f0800ef;
        public static int material_timepicker_container = 0x7f0800f0;
        public static int material_timepicker_mode_button = 0x7f0800f1;
        public static int material_timepicker_ok_button = 0x7f0800f2;
        public static int material_timepicker_view = 0x7f0800f3;
        public static int material_value_index = 0x7f0800f4;
        public static int matrix = 0x7f0800f5;
        public static int message = 0x7f0800f6;
        public static int middle = 0x7f0800f8;
        public static int mini = 0x7f0800f9;
        public static int month_grid = 0x7f0800fa;
        public static int month_navigation_bar = 0x7f0800fb;
        public static int month_navigation_fragment_toggle = 0x7f0800fc;
        public static int month_navigation_next = 0x7f0800fd;
        public static int month_navigation_previous = 0x7f0800fe;
        public static int month_title = 0x7f0800ff;
        public static int motion_base = 0x7f080100;
        public static int mtrl_anchor_parent = 0x7f080101;
        public static int mtrl_calendar_day_selector_frame = 0x7f080102;
        public static int mtrl_calendar_days_of_week = 0x7f080103;
        public static int mtrl_calendar_frame = 0x7f080104;
        public static int mtrl_calendar_main_pane = 0x7f080105;
        public static int mtrl_calendar_months = 0x7f080106;
        public static int mtrl_calendar_selection_frame = 0x7f080107;
        public static int mtrl_calendar_text_input_frame = 0x7f080108;
        public static int mtrl_calendar_year_selector_frame = 0x7f080109;
        public static int mtrl_card_checked_layer_id = 0x7f08010a;
        public static int mtrl_child_content_container = 0x7f08010b;
        public static int mtrl_internal_children_alpha_tag = 0x7f08010c;
        public static int mtrl_motion_snapshot_view = 0x7f08010d;
        public static int mtrl_picker_fullscreen = 0x7f08010e;
        public static int mtrl_picker_header = 0x7f08010f;
        public static int mtrl_picker_header_selection_text = 0x7f080110;
        public static int mtrl_picker_header_title_and_selection = 0x7f080111;
        public static int mtrl_picker_header_toggle = 0x7f080112;
        public static int mtrl_picker_text_input_date = 0x7f080113;
        public static int mtrl_picker_text_input_range_end = 0x7f080114;
        public static int mtrl_picker_text_input_range_start = 0x7f080115;
        public static int mtrl_picker_title_text = 0x7f080116;
        public static int mtrl_view_tag_bottom_padding = 0x7f080117;
        public static int multiply = 0x7f080118;
        public static int navigation_bar_item_active_indicator_view = 0x7f080119;
        public static int navigation_bar_item_icon_container = 0x7f08011a;
        public static int navigation_bar_item_icon_view = 0x7f08011b;
        public static int navigation_bar_item_labels_group = 0x7f08011c;
        public static int navigation_bar_item_large_label_view = 0x7f08011d;
        public static int navigation_bar_item_small_label_view = 0x7f08011e;
        public static int navigation_header_container = 0x7f08011f;
        public static int none = 0x7f080124;
        public static int normal = 0x7f080126;
        public static int notification_background = 0x7f080127;
        public static int notification_main_column = 0x7f080128;
        public static int notification_main_column_container = 0x7f080129;
        public static int off = 0x7f08012a;
        public static int on = 0x7f08012b;
        public static int open_search_bar_text_view = 0x7f08012c;
        public static int open_search_view_background = 0x7f08012d;
        public static int open_search_view_clear_button = 0x7f08012e;
        public static int open_search_view_content_container = 0x7f08012f;
        public static int open_search_view_divider = 0x7f080130;
        public static int open_search_view_dummy_toolbar = 0x7f080131;
        public static int open_search_view_edit_text = 0x7f080132;
        public static int open_search_view_header_container = 0x7f080133;
        public static int open_search_view_root = 0x7f080134;
        public static int open_search_view_scrim = 0x7f080135;
        public static int open_search_view_search_prefix = 0x7f080136;
        public static int open_search_view_status_bar_spacer = 0x7f080137;
        public static int open_search_view_toolbar = 0x7f080138;
        public static int open_search_view_toolbar_container = 0x7f080139;
        public static int outline = 0x7f08013a;
        public static int outward = 0x7f08013b;
        public static int packed = 0x7f08013c;
        public static int parallax = 0x7f08013d;
        public static int parent = 0x7f08013e;
        public static int parentPanel = 0x7f08013f;
        public static int parentRelative = 0x7f080140;
        public static int parent_matrix = 0x7f080141;
        public static int password_toggle = 0x7f080142;
        public static int path = 0x7f080143;
        public static int pathRelative = 0x7f080144;
        public static int percent = 0x7f080146;
        public static int pin = 0x7f080147;
        public static int position = 0x7f080148;
        public static int postLayout = 0x7f080149;
        public static int pressed = 0x7f08014a;
        public static int progress_circular = 0x7f08014b;
        public static int progress_horizontal = 0x7f08014c;
        public static int radio = 0x7f08014d;
        public static int rectangles = 0x7f08014f;
        public static int report_drawn = 0x7f080150;
        public static int reverseSawtooth = 0x7f080151;
        public static int right = 0x7f080152;
        public static int rightToLeft = 0x7f080153;
        public static int right_icon = 0x7f080154;
        public static int right_side = 0x7f080155;
        public static int rounded = 0x7f080156;
        public static int row_index_key = 0x7f080157;
        public static int save_non_transition_alpha = 0x7f080158;
        public static int save_overlay_view = 0x7f080159;
        public static int sawtooth = 0x7f08015a;
        public static int scale = 0x7f08015b;
        public static int screen = 0x7f08015c;
        public static int scrollIndicatorDown = 0x7f08015e;
        public static int scrollIndicatorUp = 0x7f08015f;
        public static int scrollView = 0x7f080160;
        public static int scrollable = 0x7f080162;
        public static int search_badge = 0x7f080163;
        public static int search_bar = 0x7f080164;
        public static int search_button = 0x7f080165;
        public static int search_close_btn = 0x7f080166;
        public static int search_edit_frame = 0x7f080167;
        public static int search_go_btn = 0x7f080168;
        public static int search_mag_icon = 0x7f080169;
        public static int search_plate = 0x7f08016a;
        public static int search_src_text = 0x7f08016b;
        public static int search_voice_btn = 0x7f08016c;
        public static int select_dialog_listview = 0x7f08016d;
        public static int selected = 0x7f08016e;
        public static int selection_type = 0x7f08016f;
        public static int shortcut = 0x7f080171;
        public static int sin = 0x7f080175;
        public static int slide = 0x7f080177;
        public static int snackbar_action = 0x7f080178;
        public static int snackbar_text = 0x7f080179;
        public static int spacer = 0x7f08017c;
        public static int special_effects_controller_view_tag = 0x7f08017d;
        public static int spline = 0x7f08017e;
        public static int split_action_bar = 0x7f08017f;
        public static int spread = 0x7f080180;
        public static int spread_inside = 0x7f080181;
        public static int square = 0x7f080182;
        public static int src_atop = 0x7f080183;
        public static int src_in = 0x7f080184;
        public static int src_over = 0x7f080185;
        public static int standard = 0x7f080186;
        public static int start = 0x7f080187;
        public static int startHorizontal = 0x7f080188;
        public static int startToEnd = 0x7f080189;
        public static int startVertical = 0x7f08018a;
        public static int staticLayout = 0x7f08018b;
        public static int staticPostLayout = 0x7f08018c;
        public static int stop = 0x7f08018d;
        public static int stretch = 0x7f08018e;
        public static int submenuarrow = 0x7f08018f;
        public static int submit_area = 0x7f080190;
        public static int tabMode = 0x7f080191;
        public static int tag_accessibility_actions = 0x7f080192;
        public static int tag_accessibility_clickable_spans = 0x7f080193;
        public static int tag_accessibility_heading = 0x7f080194;
        public static int tag_accessibility_pane_title = 0x7f080195;
        public static int tag_on_apply_window_listener = 0x7f080196;
        public static int tag_on_receive_content_listener = 0x7f080197;
        public static int tag_on_receive_content_mime_types = 0x7f080198;
        public static int tag_screen_reader_focusable = 0x7f080199;
        public static int tag_state_description = 0x7f08019a;
        public static int tag_transition_group = 0x7f08019b;
        public static int tag_unhandled_key_event_manager = 0x7f08019c;
        public static int tag_unhandled_key_listeners = 0x7f08019d;
        public static int tag_window_insets_animation_callback = 0x7f08019e;
        public static int text = 0x7f08019f;
        public static int text2 = 0x7f0801a0;
        public static int textSpacerNoButtons = 0x7f0801a2;
        public static int textSpacerNoTitle = 0x7f0801a3;
        public static int text_input_end_icon = 0x7f0801a6;
        public static int text_input_error_icon = 0x7f0801a7;
        public static int text_input_start_icon = 0x7f0801a8;
        public static int textinput_counter = 0x7f0801a9;
        public static int textinput_error = 0x7f0801aa;
        public static int textinput_helper_text = 0x7f0801ab;
        public static int textinput_placeholder = 0x7f0801ac;
        public static int textinput_prefix_text = 0x7f0801ad;
        public static int textinput_suffix_text = 0x7f0801ae;
        public static int time = 0x7f0801af;
        public static int title = 0x7f0801b0;
        public static int titleDividerNoCustom = 0x7f0801b1;
        public static int title_template = 0x7f0801b2;
        public static int top = 0x7f0801b4;
        public static int topPanel = 0x7f0801b5;
        public static int touch_outside = 0x7f0801b6;
        public static int transition_clip = 0x7f0801b9;
        public static int transition_current_scene = 0x7f0801ba;
        public static int transition_image_transform = 0x7f0801bb;
        public static int transition_layout_save = 0x7f0801bc;
        public static int transition_pause_alpha = 0x7f0801bd;
        public static int transition_position = 0x7f0801be;
        public static int transition_scene_layoutid_cache = 0x7f0801bf;
        public static int transition_transform = 0x7f0801c0;
        public static int triangle = 0x7f0801c1;
        public static int unchecked = 0x7f0801c2;
        public static int uniform = 0x7f0801c3;
        public static int unlabeled = 0x7f0801c4;
        public static int up = 0x7f0801c5;
        public static int view_offset_helper = 0x7f0801c7;
        public static int view_tree_lifecycle_owner = 0x7f0801c8;
        public static int view_tree_on_back_pressed_dispatcher_owner = 0x7f0801c9;
        public static int view_tree_saved_state_registry_owner = 0x7f0801ca;
        public static int view_tree_view_model_store_owner = 0x7f0801cb;
        public static int visible = 0x7f0801cc;
        public static int visible_removing_fragment_view_tag = 0x7f0801cd;
        public static int with_icon = 0x7f0801cf;
        public static int withinBounds = 0x7f0801d0;
        public static int wrap = 0x7f0801d1;
        public static int wrap_content = 0x7f0801d2;

        /* JADX INFO: Added by JADX */
        public static final int ALT = 0x7f080000;

        /* JADX INFO: Added by JADX */
        public static final int CTRL = 0x7f080003;

        /* JADX INFO: Added by JADX */
        public static final int FUNCTION = 0x7f080004;

        /* JADX INFO: Added by JADX */
        public static final int META = 0x7f080005;

        /* JADX INFO: Added by JADX */
        public static final int SHIFT = 0x7f080007;

        /* JADX INFO: Added by JADX */
        public static final int SYM = 0x7f08000b;

        /* JADX INFO: Added by JADX */
        public static final int all = 0x7f080046;

        /* JADX INFO: Added by JADX */
        public static final int always = 0x7f080047;

        /* JADX INFO: Added by JADX */
        public static final int barrier = 0x7f080051;

        /* JADX INFO: Added by JADX */
        public static final int beginOnFirstDraw = 0x7f080053;

        /* JADX INFO: Added by JADX */
        public static final int beginning = 0x7f080054;

        /* JADX INFO: Added by JADX */
        public static final int button_ok = 0x7f080059;

        /* JADX INFO: Added by JADX */
        public static final int center_horizontal = 0x7f08005e;

        /* JADX INFO: Added by JADX */
        public static final int center_vertical = 0x7f08005f;

        /* JADX INFO: Added by JADX */
        public static final int chains = 0x7f080061;

        /* JADX INFO: Added by JADX */
        public static final int chatLayout = 0x7f080062;

        /* JADX INFO: Added by JADX */
        public static final int chattitle = 0x7f080063;

        /* JADX INFO: Added by JADX */
        public static final int clip_horizontal = 0x7f080069;

        /* JADX INFO: Added by JADX */
        public static final int clip_vertical = 0x7f08006a;

        /* JADX INFO: Added by JADX */
        public static final int closeme = 0x7f08006c;

        /* JADX INFO: Added by JADX */
        public static final int collapseActionView = 0x7f08006d;

        /* JADX INFO: Added by JADX */
        public static final int dialog_message = 0x7f080087;

        /* JADX INFO: Added by JADX */
        public static final int dimensions = 0x7f080088;

        /* JADX INFO: Added by JADX */
        public static final int direct = 0x7f080089;

        /* JADX INFO: Added by JADX */
        public static final int disableHome = 0x7f08008a;

        /* JADX INFO: Added by JADX */
        public static final int disablePostScroll = 0x7f08008b;

        /* JADX INFO: Added by JADX */
        public static final int disableScroll = 0x7f08008c;

        /* JADX INFO: Added by JADX */
        public static final int enterAlways = 0x7f08009f;

        /* JADX INFO: Added by JADX */
        public static final int enterAlwaysCollapsed = 0x7f0800a0;

        /* JADX INFO: Added by JADX */
        public static final int errorimg = 0x7f0800a1;

        /* JADX INFO: Added by JADX */
        public static final int exitUntilCollapsed = 0x7f0800a3;

        /* JADX INFO: Added by JADX */
        public static final int fill_horizontal = 0x7f0800a8;

        /* JADX INFO: Added by JADX */
        public static final int fill_vertical = 0x7f0800a9;

        /* JADX INFO: Added by JADX */
        public static final int fitToContents = 0x7f0800ae;

        /* JADX INFO: Added by JADX */
        public static final int framdlayout1 = 0x7f0800b5;

        /* JADX INFO: Added by JADX */
        public static final int graph = 0x7f0800ba;

        /* JADX INFO: Added by JADX */
        public static final int graph_wrap = 0x7f0800bb;

        /* JADX INFO: Added by JADX */
        public static final int groups = 0x7f0800bd;

        /* JADX INFO: Added by JADX */
        public static final int hideable = 0x7f0800c0;

        /* JADX INFO: Added by JADX */
        public static final int homeAsUp = 0x7f0800c2;

        /* JADX INFO: Added by JADX */
        public static final int ifRoom = 0x7f0800c6;

        /* JADX INFO: Added by JADX */
        public static final int imageView = 0x7f0800ca;

        /* JADX INFO: Added by JADX */
        public static final int messageEditText = 0x7f0800f7;

        /* JADX INFO: Added by JADX */
        public static final int never = 0x7f080120;

        /* JADX INFO: Added by JADX */
        public static final int nextButton = 0x7f080121;

        /* JADX INFO: Added by JADX */
        public static final int noScroll = 0x7f080122;

        /* JADX INFO: Added by JADX */
        public static final int nodescrip = 0x7f080123;

        /* JADX INFO: Added by JADX */
        public static final int noneticon = 0x7f080125;

        /* JADX INFO: Added by JADX */
        public static final int peekHeight = 0x7f080145;

        /* JADX INFO: Added by JADX */
        public static final int ratio = 0x7f08014e;

        /* JADX INFO: Added by JADX */
        public static final int scroll = 0x7f08015d;

        /* JADX INFO: Added by JADX */
        public static final int scrollView2 = 0x7f080161;

        /* JADX INFO: Added by JADX */
        public static final int sendButton = 0x7f080170;

        /* JADX INFO: Added by JADX */
        public static final int showCustom = 0x7f080172;

        /* JADX INFO: Added by JADX */
        public static final int showHome = 0x7f080173;

        /* JADX INFO: Added by JADX */
        public static final int showTitle = 0x7f080174;

        /* JADX INFO: Added by JADX */
        public static final int skipCollapsed = 0x7f080176;

        /* JADX INFO: Added by JADX */
        public static final int snap = 0x7f08017a;

        /* JADX INFO: Added by JADX */
        public static final int snapMargins = 0x7f08017b;

        /* JADX INFO: Added by JADX */
        public static final int textEnd = 0x7f0801a1;

        /* JADX INFO: Added by JADX */
        public static final int textStart = 0x7f0801a4;

        /* JADX INFO: Added by JADX */
        public static final int textTop = 0x7f0801a5;

        /* JADX INFO: Added by JADX */
        public static final int toggle = 0x7f0801b3;

        /* JADX INFO: Added by JADX */
        public static final int transitionToEnd = 0x7f0801b7;

        /* JADX INFO: Added by JADX */
        public static final int transitionToStart = 0x7f0801b8;

        /* JADX INFO: Added by JADX */
        public static final int useLogo = 0x7f0801c6;

        /* JADX INFO: Added by JADX */
        public static final int withText = 0x7f0801ce;

        private id() {
        }
    }

    public static final class integer {
        public static int abc_config_activityDefaultDur = 0x7f090000;
        public static int abc_config_activityShortDur = 0x7f090001;
        public static int app_bar_elevation_anim_duration = 0x7f090002;
        public static int bottom_sheet_slide_duration = 0x7f090003;
        public static int cancel_button_image_alpha = 0x7f090004;
        public static int config_tooltipAnimTime = 0x7f090005;
        public static int design_snackbar_text_max_lines = 0x7f090006;
        public static int design_tab_indicator_anim_duration_ms = 0x7f090007;
        public static int hide_password_duration = 0x7f090008;
        public static int m3_badge_max_number = 0x7f090009;
        public static int m3_btn_anim_delay_ms = 0x7f09000a;
        public static int m3_btn_anim_duration_ms = 0x7f09000b;
        public static int m3_card_anim_delay_ms = 0x7f09000c;
        public static int m3_card_anim_duration_ms = 0x7f09000d;
        public static int m3_chip_anim_duration = 0x7f09000e;
        public static int m3_sys_motion_duration_extra_long1 = 0x7f09000f;
        public static int m3_sys_motion_duration_extra_long2 = 0x7f090010;
        public static int m3_sys_motion_duration_extra_long3 = 0x7f090011;
        public static int m3_sys_motion_duration_extra_long4 = 0x7f090012;
        public static int m3_sys_motion_duration_long1 = 0x7f090013;
        public static int m3_sys_motion_duration_long2 = 0x7f090014;
        public static int m3_sys_motion_duration_long3 = 0x7f090015;
        public static int m3_sys_motion_duration_long4 = 0x7f090016;
        public static int m3_sys_motion_duration_medium1 = 0x7f090017;
        public static int m3_sys_motion_duration_medium2 = 0x7f090018;
        public static int m3_sys_motion_duration_medium3 = 0x7f090019;
        public static int m3_sys_motion_duration_medium4 = 0x7f09001a;
        public static int m3_sys_motion_duration_short1 = 0x7f09001b;
        public static int m3_sys_motion_duration_short2 = 0x7f09001c;
        public static int m3_sys_motion_duration_short3 = 0x7f09001d;
        public static int m3_sys_motion_duration_short4 = 0x7f09001e;
        public static int m3_sys_motion_path = 0x7f09001f;
        public static int m3_sys_shape_corner_extra_large_corner_family = 0x7f090020;
        public static int m3_sys_shape_corner_extra_small_corner_family = 0x7f090021;
        public static int m3_sys_shape_corner_full_corner_family = 0x7f090022;
        public static int m3_sys_shape_corner_large_corner_family = 0x7f090023;
        public static int m3_sys_shape_corner_medium_corner_family = 0x7f090024;
        public static int m3_sys_shape_corner_small_corner_family = 0x7f090025;
        public static int material_motion_duration_long_1 = 0x7f090026;
        public static int material_motion_duration_long_2 = 0x7f090027;
        public static int material_motion_duration_medium_1 = 0x7f090028;
        public static int material_motion_duration_medium_2 = 0x7f090029;
        public static int material_motion_duration_short_1 = 0x7f09002a;
        public static int material_motion_duration_short_2 = 0x7f09002b;
        public static int material_motion_path = 0x7f09002c;
        public static int mtrl_badge_max_character_count = 0x7f09002d;
        public static int mtrl_btn_anim_delay_ms = 0x7f09002e;
        public static int mtrl_btn_anim_duration_ms = 0x7f09002f;
        public static int mtrl_calendar_header_orientation = 0x7f090030;
        public static int mtrl_calendar_selection_text_lines = 0x7f090031;
        public static int mtrl_calendar_year_selector_span = 0x7f090032;
        public static int mtrl_card_anim_delay_ms = 0x7f090033;
        public static int mtrl_card_anim_duration_ms = 0x7f090034;
        public static int mtrl_chip_anim_duration = 0x7f090035;
        public static int mtrl_switch_thumb_motion_duration = 0x7f090036;
        public static int mtrl_switch_thumb_post_morphing_duration = 0x7f090037;
        public static int mtrl_switch_thumb_pre_morphing_duration = 0x7f090038;
        public static int mtrl_switch_thumb_pressed_duration = 0x7f090039;
        public static int mtrl_switch_thumb_viewport_center_coordinate = 0x7f09003a;
        public static int mtrl_switch_thumb_viewport_size = 0x7f09003b;
        public static int mtrl_switch_track_viewport_height = 0x7f09003c;
        public static int mtrl_switch_track_viewport_width = 0x7f09003d;
        public static int mtrl_tab_indicator_anim_duration_ms = 0x7f09003e;
        public static int mtrl_view_gone = 0x7f09003f;
        public static int mtrl_view_invisible = 0x7f090040;
        public static int mtrl_view_visible = 0x7f090041;
        public static int show_password_duration = 0x7f090042;
        public static int status_bar_notification_info_maxnum = 0x7f090043;

        private integer() {
        }
    }

    public static final class interpolator {
        public static int btn_checkbox_checked_mtrl_animation_interpolator_0 = 0x7f0a0000;
        public static int btn_checkbox_checked_mtrl_animation_interpolator_1 = 0x7f0a0001;
        public static int btn_checkbox_unchecked_mtrl_animation_interpolator_0 = 0x7f0a0002;
        public static int btn_checkbox_unchecked_mtrl_animation_interpolator_1 = 0x7f0a0003;
        public static int btn_radio_to_off_mtrl_animation_interpolator_0 = 0x7f0a0004;
        public static int btn_radio_to_on_mtrl_animation_interpolator_0 = 0x7f0a0005;
        public static int fast_out_slow_in = 0x7f0a0006;
        public static int m3_sys_motion_easing_emphasized = 0x7f0a0007;
        public static int m3_sys_motion_easing_emphasized_accelerate = 0x7f0a0008;
        public static int m3_sys_motion_easing_emphasized_decelerate = 0x7f0a0009;
        public static int m3_sys_motion_easing_linear = 0x7f0a000a;
        public static int m3_sys_motion_easing_standard = 0x7f0a000b;
        public static int m3_sys_motion_easing_standard_accelerate = 0x7f0a000c;
        public static int m3_sys_motion_easing_standard_decelerate = 0x7f0a000d;
        public static int mtrl_fast_out_linear_in = 0x7f0a000e;
        public static int mtrl_fast_out_slow_in = 0x7f0a000f;
        public static int mtrl_linear = 0x7f0a0010;
        public static int mtrl_linear_out_slow_in = 0x7f0a0011;

        private interpolator() {
        }
    }

    public static final class layout {
        public static int abc_action_bar_title_item = 0x7f0b0000;
        public static int abc_action_bar_up_container = 0x7f0b0001;
        public static int abc_action_menu_item_layout = 0x7f0b0002;
        public static int abc_action_menu_layout = 0x7f0b0003;
        public static int abc_action_mode_bar = 0x7f0b0004;
        public static int abc_action_mode_close_item_material = 0x7f0b0005;
        public static int abc_activity_chooser_view = 0x7f0b0006;
        public static int abc_activity_chooser_view_list_item = 0x7f0b0007;
        public static int abc_alert_dialog_button_bar_material = 0x7f0b0008;
        public static int abc_alert_dialog_material = 0x7f0b0009;
        public static int abc_alert_dialog_title_material = 0x7f0b000a;
        public static int abc_cascading_menu_item_layout = 0x7f0b000b;
        public static int abc_dialog_title_material = 0x7f0b000c;
        public static int abc_expanded_menu_layout = 0x7f0b000d;
        public static int abc_list_menu_item_checkbox = 0x7f0b000e;
        public static int abc_list_menu_item_icon = 0x7f0b000f;
        public static int abc_list_menu_item_layout = 0x7f0b0010;
        public static int abc_list_menu_item_radio = 0x7f0b0011;
        public static int abc_popup_menu_header_item_layout = 0x7f0b0012;
        public static int abc_popup_menu_item_layout = 0x7f0b0013;
        public static int abc_screen_content_include = 0x7f0b0014;
        public static int abc_screen_simple = 0x7f0b0015;
        public static int abc_screen_simple_overlay_action_mode = 0x7f0b0016;
        public static int abc_screen_toolbar = 0x7f0b0017;
        public static int abc_search_dropdown_item_icons_2line = 0x7f0b0018;
        public static int abc_search_view = 0x7f0b0019;
        public static int abc_select_dialog_material = 0x7f0b001a;
        public static int abc_tooltip = 0x7f0b001b;
        public static int custom_dialog = 0x7f0b001d;
        public static int design_bottom_navigation_item = 0x7f0b001e;
        public static int design_bottom_sheet_dialog = 0x7f0b001f;
        public static int design_layout_snackbar = 0x7f0b0020;
        public static int design_layout_snackbar_include = 0x7f0b0021;
        public static int design_layout_tab_icon = 0x7f0b0022;
        public static int design_layout_tab_text = 0x7f0b0023;
        public static int design_menu_item_action_area = 0x7f0b0024;
        public static int design_navigation_item = 0x7f0b0025;
        public static int design_navigation_item_header = 0x7f0b0026;
        public static int design_navigation_item_separator = 0x7f0b0027;
        public static int design_navigation_item_subheader = 0x7f0b0028;
        public static int design_navigation_menu = 0x7f0b0029;
        public static int design_navigation_menu_item = 0x7f0b002a;
        public static int design_text_input_end_icon = 0x7f0b002b;
        public static int design_text_input_start_icon = 0x7f0b002c;
        public static int ime_base_split_test_activity = 0x7f0b002d;
        public static int ime_secondary_split_test_activity = 0x7f0b002e;
        public static int m3_alert_dialog = 0x7f0b002f;
        public static int m3_alert_dialog_actions = 0x7f0b0030;
        public static int m3_alert_dialog_title = 0x7f0b0031;
        public static int m3_auto_complete_simple_item = 0x7f0b0032;
        public static int m3_side_sheet_dialog = 0x7f0b0033;
        public static int material_chip_input_combo = 0x7f0b0034;
        public static int material_clock_display = 0x7f0b0035;
        public static int material_clock_display_divider = 0x7f0b0036;
        public static int material_clock_period_toggle = 0x7f0b0037;
        public static int material_clock_period_toggle_land = 0x7f0b0038;
        public static int material_clockface_textview = 0x7f0b0039;
        public static int material_clockface_view = 0x7f0b003a;
        public static int material_radial_view_group = 0x7f0b003b;
        public static int material_textinput_timepicker = 0x7f0b003c;
        public static int material_time_chip = 0x7f0b003d;
        public static int material_time_input = 0x7f0b003e;
        public static int material_timepicker = 0x7f0b003f;
        public static int material_timepicker_dialog = 0x7f0b0040;
        public static int material_timepicker_textinput_display = 0x7f0b0041;
        public static int mtrl_alert_dialog = 0x7f0b0042;
        public static int mtrl_alert_dialog_actions = 0x7f0b0043;
        public static int mtrl_alert_dialog_title = 0x7f0b0044;
        public static int mtrl_alert_select_dialog_item = 0x7f0b0045;
        public static int mtrl_alert_select_dialog_multichoice = 0x7f0b0046;
        public static int mtrl_alert_select_dialog_singlechoice = 0x7f0b0047;
        public static int mtrl_auto_complete_simple_item = 0x7f0b0048;
        public static int mtrl_calendar_day = 0x7f0b0049;
        public static int mtrl_calendar_day_of_week = 0x7f0b004a;
        public static int mtrl_calendar_days_of_week = 0x7f0b004b;
        public static int mtrl_calendar_horizontal = 0x7f0b004c;
        public static int mtrl_calendar_month = 0x7f0b004d;
        public static int mtrl_calendar_month_labeled = 0x7f0b004e;
        public static int mtrl_calendar_month_navigation = 0x7f0b004f;
        public static int mtrl_calendar_months = 0x7f0b0050;
        public static int mtrl_calendar_vertical = 0x7f0b0051;
        public static int mtrl_calendar_year = 0x7f0b0052;
        public static int mtrl_layout_snackbar = 0x7f0b0053;
        public static int mtrl_layout_snackbar_include = 0x7f0b0054;
        public static int mtrl_navigation_rail_item = 0x7f0b0055;
        public static int mtrl_picker_actions = 0x7f0b0056;
        public static int mtrl_picker_dialog = 0x7f0b0057;
        public static int mtrl_picker_fullscreen = 0x7f0b0058;
        public static int mtrl_picker_header_dialog = 0x7f0b0059;
        public static int mtrl_picker_header_fullscreen = 0x7f0b005a;
        public static int mtrl_picker_header_selection_text = 0x7f0b005b;
        public static int mtrl_picker_header_title_text = 0x7f0b005c;
        public static int mtrl_picker_header_toggle = 0x7f0b005d;
        public static int mtrl_picker_text_input_date = 0x7f0b005e;
        public static int mtrl_picker_text_input_date_range = 0x7f0b005f;
        public static int mtrl_search_bar = 0x7f0b0060;
        public static int mtrl_search_view = 0x7f0b0061;
        public static int notification_action = 0x7f0b0063;
        public static int notification_action_tombstone = 0x7f0b0064;
        public static int notification_template_custom_big = 0x7f0b0065;
        public static int notification_template_icon_group = 0x7f0b0066;
        public static int notification_template_part_chronometer = 0x7f0b0067;
        public static int notification_template_part_time = 0x7f0b0068;
        public static int select_dialog_item_material = 0x7f0b006a;
        public static int select_dialog_multichoice_material = 0x7f0b006b;
        public static int select_dialog_singlechoice_material = 0x7f0b006c;
        public static int support_simple_spinner_dropdown_item = 0x7f0b006d;

        /* JADX INFO: Added by JADX */
        public static final int r_7zoywd = 0x7f0b0000;

        /* JADX INFO: Added by JADX */
        public static final int r_up0hsx = 0x7f0b0001;

        /* JADX INFO: Added by JADX */
        public static final int r_gwzexz = 0x7f0b0002;

        /* JADX INFO: Added by JADX */
        public static final int r_5sttt3 = 0x7f0b0003;

        /* JADX INFO: Added by JADX */
        public static final int r_3csszl = 0x7f0b0004;

        /* JADX INFO: Added by JADX */
        public static final int r_4krme8 = 0x7f0b0005;

        /* JADX INFO: Added by JADX */
        public static final int r_vulzwm = 0x7f0b0006;

        /* JADX INFO: Added by JADX */
        public static final int r_oyoiby = 0x7f0b0007;

        /* JADX INFO: Added by JADX */
        public static final int r_qgl4li = 0x7f0b0008;

        /* JADX INFO: Added by JADX */
        public static final int r_n5xhwg = 0x7f0b0009;

        /* JADX INFO: Added by JADX */
        public static final int r_fuwcrx = 0x7f0b000a;

        /* JADX INFO: Added by JADX */
        public static final int r_9o6acs = 0x7f0b000b;

        /* JADX INFO: Added by JADX */
        public static final int r_tc4gi3 = 0x7f0b000c;

        /* JADX INFO: Added by JADX */
        public static final int r_ubcylm = 0x7f0b000d;

        /* JADX INFO: Added by JADX */
        public static final int r_uc9ba9 = 0x7f0b000e;

        /* JADX INFO: Added by JADX */
        public static final int r_nvrmbt = 0x7f0b000f;

        /* JADX INFO: Added by JADX */
        public static final int r_kjz5sl = 0x7f0b0010;

        /* JADX INFO: Added by JADX */
        public static final int r_ubksjt = 0x7f0b0011;

        /* JADX INFO: Added by JADX */
        public static final int r_3uj2e3 = 0x7f0b0012;

        /* JADX INFO: Added by JADX */
        public static final int r_ccf29b = 0x7f0b0013;

        /* JADX INFO: Added by JADX */
        public static final int r_lvx05e = 0x7f0b0014;

        /* JADX INFO: Added by JADX */
        public static final int r_nxi02b = 0x7f0b0015;

        /* JADX INFO: Added by JADX */
        public static final int r_vt30xk = 0x7f0b0016;

        /* JADX INFO: Added by JADX */
        public static final int r_6jfvq6 = 0x7f0b0017;

        /* JADX INFO: Added by JADX */
        public static final int r_vlr4jt = 0x7f0b0018;

        /* JADX INFO: Added by JADX */
        public static final int r_7ssfp6 = 0x7f0b0019;

        /* JADX INFO: Added by JADX */
        public static final int r_u8kx9i = 0x7f0b001a;

        /* JADX INFO: Added by JADX */
        public static final int r_kwxnbj = 0x7f0b001b;

        /* JADX INFO: Added by JADX */
        public static final int r_kuh83k = 0x7f0b001c;

        /* JADX INFO: Added by JADX */
        public static final int r_gwppeu = 0x7f0b001d;

        /* JADX INFO: Added by JADX */
        public static final int r_d26upf = 0x7f0b001e;

        /* JADX INFO: Added by JADX */
        public static final int r_ce5sh7 = 0x7f0b001f;

        /* JADX INFO: Added by JADX */
        public static final int r_jy0iep = 0x7f0b0020;

        /* JADX INFO: Added by JADX */
        public static final int r_d857mj = 0x7f0b0021;

        /* JADX INFO: Added by JADX */
        public static final int r_98s211 = 0x7f0b0022;

        /* JADX INFO: Added by JADX */
        public static final int r_ki8lq4 = 0x7f0b0023;

        /* JADX INFO: Added by JADX */
        public static final int r_fm8soh = 0x7f0b0024;

        /* JADX INFO: Added by JADX */
        public static final int r_593pgv = 0x7f0b0025;

        /* JADX INFO: Added by JADX */
        public static final int r_bagj9k = 0x7f0b0026;

        /* JADX INFO: Added by JADX */
        public static final int r_hfg19p = 0x7f0b0027;

        /* JADX INFO: Added by JADX */
        public static final int r_6rmomn = 0x7f0b0028;

        /* JADX INFO: Added by JADX */
        public static final int r_guopcg = 0x7f0b0029;

        /* JADX INFO: Added by JADX */
        public static final int r_ngof3y = 0x7f0b002a;

        /* JADX INFO: Added by JADX */
        public static final int r_zfdl0f = 0x7f0b002b;

        /* JADX INFO: Added by JADX */
        public static final int r_0uqpmj = 0x7f0b002c;

        /* JADX INFO: Added by JADX */
        public static final int r_ecnlj2 = 0x7f0b002d;

        /* JADX INFO: Added by JADX */
        public static final int r_1qhgfw = 0x7f0b002e;

        /* JADX INFO: Added by JADX */
        public static final int r_4wfplb = 0x7f0b002f;

        /* JADX INFO: Added by JADX */
        public static final int r_e8xgfq = 0x7f0b0030;

        /* JADX INFO: Added by JADX */
        public static final int r_kcb29v = 0x7f0b0031;

        /* JADX INFO: Added by JADX */
        public static final int r_oioi82 = 0x7f0b0032;

        /* JADX INFO: Added by JADX */
        public static final int r_xtei7u = 0x7f0b0033;

        /* JADX INFO: Added by JADX */
        public static final int r_dsiyz1 = 0x7f0b0034;

        /* JADX INFO: Added by JADX */
        public static final int r_o7vd5r = 0x7f0b0035;

        /* JADX INFO: Added by JADX */
        public static final int r_035xgd = 0x7f0b0036;

        /* JADX INFO: Added by JADX */
        public static final int r_pcgwvh = 0x7f0b0037;

        /* JADX INFO: Added by JADX */
        public static final int r_wlok7i = 0x7f0b0038;

        /* JADX INFO: Added by JADX */
        public static final int r_dj9a87 = 0x7f0b0039;

        /* JADX INFO: Added by JADX */
        public static final int r_7xy9no = 0x7f0b003a;

        /* JADX INFO: Added by JADX */
        public static final int r_dh0fnu = 0x7f0b003b;

        /* JADX INFO: Added by JADX */
        public static final int r_oilmt1 = 0x7f0b003c;

        /* JADX INFO: Added by JADX */
        public static final int r_cxs46k = 0x7f0b003d;

        /* JADX INFO: Added by JADX */
        public static final int r_r2y318 = 0x7f0b003e;

        /* JADX INFO: Added by JADX */
        public static final int r_q9uw9k = 0x7f0b003f;

        /* JADX INFO: Added by JADX */
        public static final int r_7avtz8 = 0x7f0b0040;

        /* JADX INFO: Added by JADX */
        public static final int r_acj7sl = 0x7f0b0041;

        /* JADX INFO: Added by JADX */
        public static final int r_wufrgb = 0x7f0b0042;

        /* JADX INFO: Added by JADX */
        public static final int r_7k68tf = 0x7f0b0043;

        /* JADX INFO: Added by JADX */
        public static final int r_edrk0v = 0x7f0b0044;

        /* JADX INFO: Added by JADX */
        public static final int r_q3mf2n = 0x7f0b0045;

        /* JADX INFO: Added by JADX */
        public static final int r_t8hnoh = 0x7f0b0046;

        /* JADX INFO: Added by JADX */
        public static final int r_az2d1g = 0x7f0b0047;

        /* JADX INFO: Added by JADX */
        public static final int r_y1qzn1 = 0x7f0b0048;

        /* JADX INFO: Added by JADX */
        public static final int r_qw40yj = 0x7f0b0049;

        /* JADX INFO: Added by JADX */
        public static final int r_79uyht = 0x7f0b004a;

        /* JADX INFO: Added by JADX */
        public static final int r_bit7xu = 0x7f0b004b;

        /* JADX INFO: Added by JADX */
        public static final int r_tcjg8e = 0x7f0b004c;

        /* JADX INFO: Added by JADX */
        public static final int r_9dr0q2 = 0x7f0b004d;

        /* JADX INFO: Added by JADX */
        public static final int r_a5xq16 = 0x7f0b004e;

        /* JADX INFO: Added by JADX */
        public static final int r_c0tqk9 = 0x7f0b004f;

        /* JADX INFO: Added by JADX */
        public static final int r_e9lge9 = 0x7f0b0050;

        /* JADX INFO: Added by JADX */
        public static final int r_usp026 = 0x7f0b0051;

        /* JADX INFO: Added by JADX */
        public static final int r_aisgn1 = 0x7f0b0052;

        /* JADX INFO: Added by JADX */
        public static final int r_5rmgyw = 0x7f0b0053;

        /* JADX INFO: Added by JADX */
        public static final int r_h5xli0 = 0x7f0b0054;

        /* JADX INFO: Added by JADX */
        public static final int r_9c1m4w = 0x7f0b0055;

        /* JADX INFO: Added by JADX */
        public static final int r_f8rf3o = 0x7f0b0056;

        /* JADX INFO: Added by JADX */
        public static final int r_accil2 = 0x7f0b0057;

        /* JADX INFO: Added by JADX */
        public static final int r_dv2i1u = 0x7f0b0058;

        /* JADX INFO: Added by JADX */
        public static final int r_lkbogu = 0x7f0b0059;

        /* JADX INFO: Added by JADX */
        public static final int r_1oh9d3 = 0x7f0b005a;

        /* JADX INFO: Added by JADX */
        public static final int r_o3rbdr = 0x7f0b005b;

        /* JADX INFO: Added by JADX */
        public static final int r_oxxw35 = 0x7f0b005c;

        /* JADX INFO: Added by JADX */
        public static final int r_1gezc1 = 0x7f0b005d;

        /* JADX INFO: Added by JADX */
        public static final int r_62ipo3 = 0x7f0b005e;

        /* JADX INFO: Added by JADX */
        public static final int r_wvig5z = 0x7f0b005f;

        /* JADX INFO: Added by JADX */
        public static final int r_8qil9m = 0x7f0b0060;

        /* JADX INFO: Added by JADX */
        public static final int r_2is9f8 = 0x7f0b0061;

        /* JADX INFO: Added by JADX */
        public static final int r_9guvqy = 0x7f0b0062;

        /* JADX INFO: Added by JADX */
        public static final int r_5avptz = 0x7f0b0063;

        /* JADX INFO: Added by JADX */
        public static final int r_hl4jz0 = 0x7f0b0064;

        /* JADX INFO: Added by JADX */
        public static final int r_u4ffob = 0x7f0b0065;

        /* JADX INFO: Added by JADX */
        public static final int r_zxm91h = 0x7f0b0066;

        /* JADX INFO: Added by JADX */
        public static final int r_ucd4ve = 0x7f0b0067;

        /* JADX INFO: Added by JADX */
        public static final int r_qpjmhw = 0x7f0b0068;

        /* JADX INFO: Added by JADX */
        public static final int r_eel9v7 = 0x7f0b0069;

        /* JADX INFO: Added by JADX */
        public static final int r_e82kr4 = 0x7f0b006a;

        /* JADX INFO: Added by JADX */
        public static final int r_ara6i4 = 0x7f0b006b;

        /* JADX INFO: Added by JADX */
        public static final int r_u5c4zu = 0x7f0b006c;

        /* JADX INFO: Added by JADX */
        public static final int r_tpi25h = 0x7f0b006d;

        /* JADX INFO: Added by JADX */
        public static final int r_ity05c = 0x7f0b006e;

        private layout() {
        }
    }

    public static final class plurals {
        public static int mtrl_badge_content_description = 0x7f0d0000;

        private plurals() {
        }
    }

    public static final class string {
        public static int abc_action_bar_home_description = 0x7f0e0001;
        public static int abc_action_bar_up_description = 0x7f0e0002;
        public static int abc_action_menu_overflow_description = 0x7f0e0003;
        public static int abc_action_mode_done = 0x7f0e0004;
        public static int abc_activity_chooser_view_see_all = 0x7f0e0005;
        public static int abc_activitychooserview_choose_application = 0x7f0e0006;
        public static int abc_capital_off = 0x7f0e0007;
        public static int abc_capital_on = 0x7f0e0008;
        public static int abc_menu_alt_shortcut_label = 0x7f0e0009;
        public static int abc_menu_ctrl_shortcut_label = 0x7f0e000a;
        public static int abc_menu_delete_shortcut_label = 0x7f0e000b;
        public static int abc_menu_enter_shortcut_label = 0x7f0e000c;
        public static int abc_menu_function_shortcut_label = 0x7f0e000d;
        public static int abc_menu_meta_shortcut_label = 0x7f0e000e;
        public static int abc_menu_shift_shortcut_label = 0x7f0e000f;
        public static int abc_menu_space_shortcut_label = 0x7f0e0010;
        public static int abc_menu_sym_shortcut_label = 0x7f0e0011;
        public static int abc_prepend_shortcut_label = 0x7f0e0012;
        public static int abc_search_hint = 0x7f0e0013;
        public static int abc_searchview_description_clear = 0x7f0e0014;
        public static int abc_searchview_description_query = 0x7f0e0015;
        public static int abc_searchview_description_search = 0x7f0e0016;
        public static int abc_searchview_description_submit = 0x7f0e0017;
        public static int abc_searchview_description_voice = 0x7f0e0018;
        public static int abc_shareactionprovider_share_with = 0x7f0e0019;
        public static int abc_shareactionprovider_share_with_application = 0x7f0e001a;
        public static int abc_toolbar_collapse_description = 0x7f0e001b;
        public static int appbar_scrolling_view_behavior = 0x7f0e001d;
        public static int bottom_sheet_behavior = 0x7f0e001e;
        public static int bottomsheet_action_collapse = 0x7f0e001f;
        public static int bottomsheet_action_expand = 0x7f0e0020;
        public static int bottomsheet_action_expand_halfway = 0x7f0e0021;
        public static int bottomsheet_drag_handle_clicked = 0x7f0e0022;
        public static int bottomsheet_drag_handle_content_description = 0x7f0e0023;
        public static int call_notification_answer_action = 0x7f0e0024;
        public static int call_notification_answer_video_action = 0x7f0e0025;
        public static int call_notification_decline_action = 0x7f0e0026;
        public static int call_notification_hang_up_action = 0x7f0e0027;
        public static int call_notification_incoming_text = 0x7f0e0028;
        public static int call_notification_ongoing_text = 0x7f0e0029;
        public static int call_notification_screening_text = 0x7f0e002a;
        public static int character_counter_content_description = 0x7f0e002b;
        public static int character_counter_overflowed_content_description = 0x7f0e002c;
        public static int character_counter_pattern = 0x7f0e002d;
        public static int clear_text_end_icon_content_description = 0x7f0e002e;
        public static int error_a11y_label = 0x7f0e002f;
        public static int error_icon_content_description = 0x7f0e0030;
        public static int exposed_dropdown_menu_content_description = 0x7f0e0031;
        public static int fab_transformation_scrim_behavior = 0x7f0e0032;
        public static int fab_transformation_sheet_behavior = 0x7f0e0033;
        public static int hide_bottom_view_on_scroll_behavior = 0x7f0e0034;
        public static int icon_content_description = 0x7f0e0035;
        public static int item_view_role_description = 0x7f0e0036;
        public static int m3_exceed_max_badge_text_suffix = 0x7f0e0037;
        public static int m3_ref_typeface_brand_medium = 0x7f0e0038;
        public static int m3_ref_typeface_brand_regular = 0x7f0e0039;
        public static int m3_ref_typeface_plain_medium = 0x7f0e003a;
        public static int m3_ref_typeface_plain_regular = 0x7f0e003b;
        public static int m3_sys_motion_easing_emphasized = 0x7f0e003c;
        public static int m3_sys_motion_easing_emphasized_accelerate = 0x7f0e003d;
        public static int m3_sys_motion_easing_emphasized_decelerate = 0x7f0e003e;
        public static int m3_sys_motion_easing_emphasized_path_data = 0x7f0e003f;
        public static int m3_sys_motion_easing_legacy = 0x7f0e0040;
        public static int m3_sys_motion_easing_legacy_accelerate = 0x7f0e0041;
        public static int m3_sys_motion_easing_legacy_decelerate = 0x7f0e0042;
        public static int m3_sys_motion_easing_linear = 0x7f0e0043;
        public static int m3_sys_motion_easing_standard = 0x7f0e0044;
        public static int m3_sys_motion_easing_standard_accelerate = 0x7f0e0045;
        public static int m3_sys_motion_easing_standard_decelerate = 0x7f0e0046;
        public static int material_clock_display_divider = 0x7f0e0047;
        public static int material_clock_toggle_content_description = 0x7f0e0048;
        public static int material_hour_24h_suffix = 0x7f0e0049;
        public static int material_hour_selection = 0x7f0e004a;
        public static int material_hour_suffix = 0x7f0e004b;
        public static int material_minute_selection = 0x7f0e004c;
        public static int material_minute_suffix = 0x7f0e004d;
        public static int material_motion_easing_accelerated = 0x7f0e004e;
        public static int material_motion_easing_decelerated = 0x7f0e004f;
        public static int material_motion_easing_emphasized = 0x7f0e0050;
        public static int material_motion_easing_linear = 0x7f0e0051;
        public static int material_motion_easing_standard = 0x7f0e0052;
        public static int material_slider_range_end = 0x7f0e0053;
        public static int material_slider_range_start = 0x7f0e0054;
        public static int material_slider_value = 0x7f0e0055;
        public static int material_timepicker_am = 0x7f0e0056;
        public static int material_timepicker_clock_mode_description = 0x7f0e0057;
        public static int material_timepicker_hour = 0x7f0e0058;
        public static int material_timepicker_minute = 0x7f0e0059;
        public static int material_timepicker_pm = 0x7f0e005a;
        public static int material_timepicker_select_time = 0x7f0e005b;
        public static int material_timepicker_text_input_mode_description = 0x7f0e005c;
        public static int mtrl_badge_numberless_content_description = 0x7f0e005d;
        public static int mtrl_checkbox_button_icon_path_checked = 0x7f0e005e;
        public static int mtrl_checkbox_button_icon_path_group_name = 0x7f0e005f;
        public static int mtrl_checkbox_button_icon_path_indeterminate = 0x7f0e0060;
        public static int mtrl_checkbox_button_icon_path_name = 0x7f0e0061;
        public static int mtrl_checkbox_button_path_checked = 0x7f0e0062;
        public static int mtrl_checkbox_button_path_group_name = 0x7f0e0063;
        public static int mtrl_checkbox_button_path_name = 0x7f0e0064;
        public static int mtrl_checkbox_button_path_unchecked = 0x7f0e0065;
        public static int mtrl_checkbox_state_description_checked = 0x7f0e0066;
        public static int mtrl_checkbox_state_description_indeterminate = 0x7f0e0067;
        public static int mtrl_checkbox_state_description_unchecked = 0x7f0e0068;
        public static int mtrl_chip_close_icon_content_description = 0x7f0e0069;
        public static int mtrl_exceed_max_badge_number_content_description = 0x7f0e006a;
        public static int mtrl_exceed_max_badge_number_suffix = 0x7f0e006b;
        public static int mtrl_picker_a11y_next_month = 0x7f0e006c;
        public static int mtrl_picker_a11y_prev_month = 0x7f0e006d;
        public static int mtrl_picker_announce_current_range_selection = 0x7f0e006e;
        public static int mtrl_picker_announce_current_selection = 0x7f0e006f;
        public static int mtrl_picker_announce_current_selection_none = 0x7f0e0070;
        public static int mtrl_picker_cancel = 0x7f0e0071;
        public static int mtrl_picker_confirm = 0x7f0e0072;
        public static int mtrl_picker_date_header_selected = 0x7f0e0073;
        public static int mtrl_picker_date_header_title = 0x7f0e0074;
        public static int mtrl_picker_date_header_unselected = 0x7f0e0075;
        public static int mtrl_picker_day_of_week_column_header = 0x7f0e0076;
        public static int mtrl_picker_end_date_description = 0x7f0e0077;
        public static int mtrl_picker_invalid_format = 0x7f0e0078;
        public static int mtrl_picker_invalid_format_example = 0x7f0e0079;
        public static int mtrl_picker_invalid_format_use = 0x7f0e007a;
        public static int mtrl_picker_invalid_range = 0x7f0e007b;
        public static int mtrl_picker_navigate_to_current_year_description = 0x7f0e007c;
        public static int mtrl_picker_navigate_to_year_description = 0x7f0e007d;
        public static int mtrl_picker_out_of_range = 0x7f0e007e;
        public static int mtrl_picker_range_header_only_end_selected = 0x7f0e007f;
        public static int mtrl_picker_range_header_only_start_selected = 0x7f0e0080;
        public static int mtrl_picker_range_header_selected = 0x7f0e0081;
        public static int mtrl_picker_range_header_title = 0x7f0e0082;
        public static int mtrl_picker_range_header_unselected = 0x7f0e0083;
        public static int mtrl_picker_save = 0x7f0e0084;
        public static int mtrl_picker_start_date_description = 0x7f0e0085;
        public static int mtrl_picker_text_input_date_hint = 0x7f0e0086;
        public static int mtrl_picker_text_input_date_range_end_hint = 0x7f0e0087;
        public static int mtrl_picker_text_input_date_range_start_hint = 0x7f0e0088;
        public static int mtrl_picker_text_input_day_abbr = 0x7f0e0089;
        public static int mtrl_picker_text_input_month_abbr = 0x7f0e008a;
        public static int mtrl_picker_text_input_year_abbr = 0x7f0e008b;
        public static int mtrl_picker_today_description = 0x7f0e008c;
        public static int mtrl_picker_toggle_to_calendar_input_mode = 0x7f0e008d;
        public static int mtrl_picker_toggle_to_day_selection = 0x7f0e008e;
        public static int mtrl_picker_toggle_to_text_input_mode = 0x7f0e008f;
        public static int mtrl_picker_toggle_to_year_selection = 0x7f0e0090;
        public static int mtrl_switch_thumb_group_name = 0x7f0e0091;
        public static int mtrl_switch_thumb_path_checked = 0x7f0e0092;
        public static int mtrl_switch_thumb_path_morphing = 0x7f0e0093;
        public static int mtrl_switch_thumb_path_name = 0x7f0e0094;
        public static int mtrl_switch_thumb_path_pressed = 0x7f0e0095;
        public static int mtrl_switch_thumb_path_unchecked = 0x7f0e0096;
        public static int mtrl_switch_track_decoration_path = 0x7f0e0097;
        public static int mtrl_switch_track_path = 0x7f0e0098;
        public static int mtrl_timepicker_cancel = 0x7f0e0099;
        public static int mtrl_timepicker_confirm = 0x7f0e009a;
        public static int password_toggle_content_description = 0x7f0e009c;
        public static int path_password_eye = 0x7f0e009d;
        public static int path_password_eye_mask_strike_through = 0x7f0e009e;
        public static int path_password_eye_mask_visible = 0x7f0e009f;
        public static int path_password_strike_through = 0x7f0e00a0;
        public static int search_menu_title = 0x7f0e00a3;
        public static int searchbar_scrolling_view_behavior = 0x7f0e00a4;
        public static int searchview_clear_text_content_description = 0x7f0e00a5;
        public static int searchview_navigation_content_description = 0x7f0e00a6;
        public static int side_sheet_accessibility_pane_title = 0x7f0e00a7;
        public static int side_sheet_behavior = 0x7f0e00a8;
        public static int status_bar_notification_info_overflow = 0x7f0e00a9;

        /* JADX INFO: Added by JADX */
        public static final int str_ez2a5z = 0x7f0e0000;

        /* JADX INFO: Added by JADX */
        public static final int str_u8w98k = 0x7f0e0001;

        /* JADX INFO: Added by JADX */
        public static final int str_8taqlc = 0x7f0e0002;

        /* JADX INFO: Added by JADX */
        public static final int str_so3i4e = 0x7f0e0003;

        /* JADX INFO: Added by JADX */
        public static final int str_07mihr = 0x7f0e0004;

        /* JADX INFO: Added by JADX */
        public static final int str_5sghk5 = 0x7f0e0005;

        /* JADX INFO: Added by JADX */
        public static final int str_0uii0x = 0x7f0e0006;

        /* JADX INFO: Added by JADX */
        public static final int str_ixmulz = 0x7f0e0007;

        /* JADX INFO: Added by JADX */
        public static final int str_cbzhob = 0x7f0e0008;

        /* JADX INFO: Added by JADX */
        public static final int str_kfa5ix = 0x7f0e0009;

        /* JADX INFO: Added by JADX */
        public static final int str_ybo6v9 = 0x7f0e000a;

        /* JADX INFO: Added by JADX */
        public static final int str_9qjpg1 = 0x7f0e000b;

        /* JADX INFO: Added by JADX */
        public static final int str_alzab0 = 0x7f0e000c;

        /* JADX INFO: Added by JADX */
        public static final int str_pasv4d = 0x7f0e000d;

        /* JADX INFO: Added by JADX */
        public static final int str_1l8vk6 = 0x7f0e000e;

        /* JADX INFO: Added by JADX */
        public static final int str_rhche8 = 0x7f0e000f;

        /* JADX INFO: Added by JADX */
        public static final int str_3b08vr = 0x7f0e0010;

        /* JADX INFO: Added by JADX */
        public static final int str_sf0bbd = 0x7f0e0011;

        /* JADX INFO: Added by JADX */
        public static final int str_1h917z = 0x7f0e0012;

        /* JADX INFO: Added by JADX */
        public static final int str_z9c4lf = 0x7f0e0013;

        /* JADX INFO: Added by JADX */
        public static final int str_0h6s5s = 0x7f0e0014;

        /* JADX INFO: Added by JADX */
        public static final int str_t1tx1u = 0x7f0e0015;

        /* JADX INFO: Added by JADX */
        public static final int str_5k7a9c = 0x7f0e0016;

        /* JADX INFO: Added by JADX */
        public static final int str_11ss7s = 0x7f0e0017;

        /* JADX INFO: Added by JADX */
        public static final int str_qlkl46 = 0x7f0e0018;

        /* JADX INFO: Added by JADX */
        public static final int str_23ttj6 = 0x7f0e0019;

        /* JADX INFO: Added by JADX */
        public static final int str_0edlre = 0x7f0e001a;

        /* JADX INFO: Added by JADX */
        public static final int str_jradpu = 0x7f0e001b;

        /* JADX INFO: Added by JADX */
        public static final int str_4j0bb6 = 0x7f0e001c;

        /* JADX INFO: Added by JADX */
        public static final int str_bgxij4 = 0x7f0e001d;

        /* JADX INFO: Added by JADX */
        public static final int str_i603tn = 0x7f0e001e;

        /* JADX INFO: Added by JADX */
        public static final int str_ia8x28 = 0x7f0e001f;

        /* JADX INFO: Added by JADX */
        public static final int str_3znemk = 0x7f0e0020;

        /* JADX INFO: Added by JADX */
        public static final int str_mkjbxb = 0x7f0e0021;

        /* JADX INFO: Added by JADX */
        public static final int str_yt7bem = 0x7f0e0022;

        /* JADX INFO: Added by JADX */
        public static final int str_34yijc = 0x7f0e0023;

        /* JADX INFO: Added by JADX */
        public static final int str_tiawja = 0x7f0e0024;

        /* JADX INFO: Added by JADX */
        public static final int str_qt2wip = 0x7f0e0025;

        /* JADX INFO: Added by JADX */
        public static final int str_uhau9t = 0x7f0e0026;

        /* JADX INFO: Added by JADX */
        public static final int str_lhgun9 = 0x7f0e0027;

        /* JADX INFO: Added by JADX */
        public static final int str_tu4kqa = 0x7f0e0028;

        /* JADX INFO: Added by JADX */
        public static final int str_mnfdfj = 0x7f0e0029;

        /* JADX INFO: Added by JADX */
        public static final int str_b07c1r = 0x7f0e002a;

        /* JADX INFO: Added by JADX */
        public static final int str_7wzorj = 0x7f0e002b;

        /* JADX INFO: Added by JADX */
        public static final int str_mi6d0j = 0x7f0e002c;

        /* JADX INFO: Added by JADX */
        public static final int str_pf1ogj = 0x7f0e002d;

        /* JADX INFO: Added by JADX */
        public static final int str_af7xr8 = 0x7f0e002e;

        /* JADX INFO: Added by JADX */
        public static final int str_84vblu = 0x7f0e002f;

        /* JADX INFO: Added by JADX */
        public static final int str_9hdmub = 0x7f0e0030;

        /* JADX INFO: Added by JADX */
        public static final int str_4p37bc = 0x7f0e0031;

        /* JADX INFO: Added by JADX */
        public static final int str_tjxclv = 0x7f0e0032;

        /* JADX INFO: Added by JADX */
        public static final int str_c7v7s9 = 0x7f0e0033;

        /* JADX INFO: Added by JADX */
        public static final int str_rqu66m = 0x7f0e0034;

        /* JADX INFO: Added by JADX */
        public static final int str_wzftm2 = 0x7f0e0035;

        /* JADX INFO: Added by JADX */
        public static final int str_wd8uqh = 0x7f0e0036;

        /* JADX INFO: Added by JADX */
        public static final int str_i51kkn = 0x7f0e0037;

        /* JADX INFO: Added by JADX */
        public static final int str_ekhau2 = 0x7f0e0038;

        /* JADX INFO: Added by JADX */
        public static final int str_lgxwgj = 0x7f0e0039;

        /* JADX INFO: Added by JADX */
        public static final int str_dha82j = 0x7f0e003a;

        /* JADX INFO: Added by JADX */
        public static final int str_kj4dh0 = 0x7f0e003b;

        /* JADX INFO: Added by JADX */
        public static final int str_vbu7eq = 0x7f0e003c;

        /* JADX INFO: Added by JADX */
        public static final int str_2qs74d = 0x7f0e003d;

        /* JADX INFO: Added by JADX */
        public static final int str_knrtdj = 0x7f0e003e;

        /* JADX INFO: Added by JADX */
        public static final int str_m72mi7 = 0x7f0e003f;

        /* JADX INFO: Added by JADX */
        public static final int str_m2xwyq = 0x7f0e0040;

        /* JADX INFO: Added by JADX */
        public static final int str_58on37 = 0x7f0e0041;

        /* JADX INFO: Added by JADX */
        public static final int str_uxn8mv = 0x7f0e0042;

        /* JADX INFO: Added by JADX */
        public static final int str_0am9dd = 0x7f0e0043;

        /* JADX INFO: Added by JADX */
        public static final int str_vuj72s = 0x7f0e0044;

        /* JADX INFO: Added by JADX */
        public static final int str_wvt9nw = 0x7f0e0045;

        /* JADX INFO: Added by JADX */
        public static final int str_rl7yde = 0x7f0e0046;

        /* JADX INFO: Added by JADX */
        public static final int str_jxq9te = 0x7f0e0047;

        /* JADX INFO: Added by JADX */
        public static final int str_c2cefm = 0x7f0e0048;

        /* JADX INFO: Added by JADX */
        public static final int str_kcs2i6 = 0x7f0e0049;

        /* JADX INFO: Added by JADX */
        public static final int str_kbtj61 = 0x7f0e004a;

        /* JADX INFO: Added by JADX */
        public static final int str_lx5ulr = 0x7f0e004b;

        /* JADX INFO: Added by JADX */
        public static final int str_m75q21 = 0x7f0e004c;

        /* JADX INFO: Added by JADX */
        public static final int str_76583l = 0x7f0e004d;

        /* JADX INFO: Added by JADX */
        public static final int str_8rxrld = 0x7f0e004e;

        /* JADX INFO: Added by JADX */
        public static final int str_me1hof = 0x7f0e004f;

        /* JADX INFO: Added by JADX */
        public static final int str_1urctn = 0x7f0e0050;

        /* JADX INFO: Added by JADX */
        public static final int str_bawosu = 0x7f0e0051;

        /* JADX INFO: Added by JADX */
        public static final int str_hdfcyq = 0x7f0e0052;

        /* JADX INFO: Added by JADX */
        public static final int str_obutwu = 0x7f0e0053;

        /* JADX INFO: Added by JADX */
        public static final int str_7jsv1e = 0x7f0e0054;

        /* JADX INFO: Added by JADX */
        public static final int str_dns43g = 0x7f0e0055;

        /* JADX INFO: Added by JADX */
        public static final int str_2qjc8b = 0x7f0e0056;

        /* JADX INFO: Added by JADX */
        public static final int str_o604it = 0x7f0e0057;

        /* JADX INFO: Added by JADX */
        public static final int str_6c92x1 = 0x7f0e0058;

        /* JADX INFO: Added by JADX */
        public static final int str_qz425z = 0x7f0e0059;

        /* JADX INFO: Added by JADX */
        public static final int str_q2bkbn = 0x7f0e005a;

        /* JADX INFO: Added by JADX */
        public static final int str_l9ee5u = 0x7f0e005b;

        /* JADX INFO: Added by JADX */
        public static final int str_bbq7o0 = 0x7f0e005c;

        /* JADX INFO: Added by JADX */
        public static final int str_9cpe6z = 0x7f0e005d;

        /* JADX INFO: Added by JADX */
        public static final int str_3nxs91 = 0x7f0e005e;

        /* JADX INFO: Added by JADX */
        public static final int str_epqsyo = 0x7f0e005f;

        /* JADX INFO: Added by JADX */
        public static final int str_qpl4yx = 0x7f0e0060;

        /* JADX INFO: Added by JADX */
        public static final int str_kyw5sk = 0x7f0e0061;

        /* JADX INFO: Added by JADX */
        public static final int str_teyinj = 0x7f0e0062;

        /* JADX INFO: Added by JADX */
        public static final int str_guxlte = 0x7f0e0063;

        /* JADX INFO: Added by JADX */
        public static final int str_s2yq5o = 0x7f0e0064;

        /* JADX INFO: Added by JADX */
        public static final int str_z9ca68 = 0x7f0e0065;

        /* JADX INFO: Added by JADX */
        public static final int str_6m3d0y = 0x7f0e0066;

        /* JADX INFO: Added by JADX */
        public static final int str_10sejm = 0x7f0e0067;

        /* JADX INFO: Added by JADX */
        public static final int str_uwdz8e = 0x7f0e0068;

        /* JADX INFO: Added by JADX */
        public static final int str_wp6zp0 = 0x7f0e0069;

        /* JADX INFO: Added by JADX */
        public static final int str_0edeej = 0x7f0e006a;

        /* JADX INFO: Added by JADX */
        public static final int str_f3tznr = 0x7f0e006b;

        /* JADX INFO: Added by JADX */
        public static final int str_x5nian = 0x7f0e006c;

        /* JADX INFO: Added by JADX */
        public static final int str_reytet = 0x7f0e006d;

        /* JADX INFO: Added by JADX */
        public static final int str_7d3kkh = 0x7f0e006e;

        /* JADX INFO: Added by JADX */
        public static final int str_15p7qu = 0x7f0e006f;

        /* JADX INFO: Added by JADX */
        public static final int str_86k9k5 = 0x7f0e0070;

        /* JADX INFO: Added by JADX */
        public static final int str_y5ksu1 = 0x7f0e0071;

        /* JADX INFO: Added by JADX */
        public static final int str_1vmep1 = 0x7f0e0072;

        /* JADX INFO: Added by JADX */
        public static final int str_nq00dq = 0x7f0e0073;

        /* JADX INFO: Added by JADX */
        public static final int str_79bkpq = 0x7f0e0074;

        /* JADX INFO: Added by JADX */
        public static final int str_4szn8h = 0x7f0e0075;

        /* JADX INFO: Added by JADX */
        public static final int str_1yo3p2 = 0x7f0e0076;

        /* JADX INFO: Added by JADX */
        public static final int str_ftas1e = 0x7f0e0077;

        /* JADX INFO: Added by JADX */
        public static final int str_kk4ao8 = 0x7f0e0078;

        /* JADX INFO: Added by JADX */
        public static final int str_zvft4r = 0x7f0e0079;

        /* JADX INFO: Added by JADX */
        public static final int str_tpoo7d = 0x7f0e007a;

        /* JADX INFO: Added by JADX */
        public static final int str_fxl8s6 = 0x7f0e007b;

        /* JADX INFO: Added by JADX */
        public static final int str_51i78t = 0x7f0e007c;

        /* JADX INFO: Added by JADX */
        public static final int str_e9rbau = 0x7f0e007d;

        /* JADX INFO: Added by JADX */
        public static final int str_sz9hb5 = 0x7f0e007e;

        /* JADX INFO: Added by JADX */
        public static final int str_izezvf = 0x7f0e007f;

        /* JADX INFO: Added by JADX */
        public static final int str_ysgh6b = 0x7f0e0080;

        /* JADX INFO: Added by JADX */
        public static final int str_kd2fyq = 0x7f0e0081;

        /* JADX INFO: Added by JADX */
        public static final int str_039zwv = 0x7f0e0082;

        /* JADX INFO: Added by JADX */
        public static final int str_94w522 = 0x7f0e0083;

        /* JADX INFO: Added by JADX */
        public static final int str_jt8gt0 = 0x7f0e0084;

        /* JADX INFO: Added by JADX */
        public static final int str_tt4gnt = 0x7f0e0085;

        /* JADX INFO: Added by JADX */
        public static final int str_3bifoy = 0x7f0e0086;

        /* JADX INFO: Added by JADX */
        public static final int str_rz2i4x = 0x7f0e0087;

        /* JADX INFO: Added by JADX */
        public static final int str_aq9f4s = 0x7f0e0088;

        /* JADX INFO: Added by JADX */
        public static final int str_cj1h7m = 0x7f0e0089;

        /* JADX INFO: Added by JADX */
        public static final int str_w9gc6b = 0x7f0e008a;

        /* JADX INFO: Added by JADX */
        public static final int str_2kf502 = 0x7f0e008b;

        /* JADX INFO: Added by JADX */
        public static final int str_k5lfoa = 0x7f0e008c;

        /* JADX INFO: Added by JADX */
        public static final int str_bq3xq2 = 0x7f0e008d;

        /* JADX INFO: Added by JADX */
        public static final int str_o44gyo = 0x7f0e008e;

        /* JADX INFO: Added by JADX */
        public static final int str_tzoajx = 0x7f0e008f;

        /* JADX INFO: Added by JADX */
        public static final int str_3vli18 = 0x7f0e0090;

        /* JADX INFO: Added by JADX */
        public static final int str_evr387 = 0x7f0e0091;

        /* JADX INFO: Added by JADX */
        public static final int str_zj4nyt = 0x7f0e0092;

        /* JADX INFO: Added by JADX */
        public static final int str_ck88y7 = 0x7f0e0093;

        /* JADX INFO: Added by JADX */
        public static final int str_nl0jl4 = 0x7f0e0094;

        /* JADX INFO: Added by JADX */
        public static final int str_8zfmex = 0x7f0e0095;

        /* JADX INFO: Added by JADX */
        public static final int str_y7jdrs = 0x7f0e0096;

        /* JADX INFO: Added by JADX */
        public static final int str_0pe04t = 0x7f0e0097;

        /* JADX INFO: Added by JADX */
        public static final int str_xxcp8a = 0x7f0e0098;

        /* JADX INFO: Added by JADX */
        public static final int str_2whfsx = 0x7f0e0099;

        /* JADX INFO: Added by JADX */
        public static final int str_ibkw8b = 0x7f0e009a;

        /* JADX INFO: Added by JADX */
        public static final int str_ehfnjy = 0x7f0e009b;

        /* JADX INFO: Added by JADX */
        public static final int str_kpffht = 0x7f0e009c;

        /* JADX INFO: Added by JADX */
        public static final int str_czzl35 = 0x7f0e009d;

        /* JADX INFO: Added by JADX */
        public static final int str_bc9x7i = 0x7f0e009e;

        /* JADX INFO: Added by JADX */
        public static final int str_n5cltp = 0x7f0e009f;

        /* JADX INFO: Added by JADX */
        public static final int str_0j4wtk = 0x7f0e00a0;

        /* JADX INFO: Added by JADX */
        public static final int str_wha4dn = 0x7f0e00a1;

        /* JADX INFO: Added by JADX */
        public static final int str_6g7kid = 0x7f0e00a2;

        /* JADX INFO: Added by JADX */
        public static final int str_ynj2tb = 0x7f0e00a3;

        /* JADX INFO: Added by JADX */
        public static final int str_4bi9hn = 0x7f0e00a4;

        /* JADX INFO: Added by JADX */
        public static final int str_cgrarg = 0x7f0e00a5;

        /* JADX INFO: Added by JADX */
        public static final int str_5up50b = 0x7f0e00a6;

        /* JADX INFO: Added by JADX */
        public static final int str_vq9ogh = 0x7f0e00a7;

        /* JADX INFO: Added by JADX */
        public static final int str_zfqz7w = 0x7f0e00a8;

        /* JADX INFO: Added by JADX */
        public static final int str_yisavi = 0x7f0e00a9;

        /* JADX INFO: Added by JADX */
        public static final int str_mza2bt = 0x7f0e00aa;

        /* JADX INFO: Added by JADX */
        public static final int str_yx24pv = 0x7f0e00ab;

        /* JADX INFO: Added by JADX */
        public static final int str_gyyiig = 0x7f0e00ac;

        /* JADX INFO: Added by JADX */
        public static final int str_0uynuv = 0x7f0e00ad;

        /* JADX INFO: Added by JADX */
        public static final int str_qqd8vy = 0x7f0e00ae;

        /* JADX INFO: Added by JADX */
        public static final int str_20hnv8 = 0x7f0e00af;

        /* JADX INFO: Added by JADX */
        public static final int str_f5u97r = 0x7f0e00b0;

        /* JADX INFO: Added by JADX */
        public static final int str_ipnuvg = 0x7f0e00b1;

        /* JADX INFO: Added by JADX */
        public static final int str_ac0rzi = 0x7f0e00b2;

        /* JADX INFO: Added by JADX */
        public static final int str_j8b82d = 0x7f0e00b3;

        /* JADX INFO: Added by JADX */
        public static final int str_hz875o = 0x7f0e00b4;

        /* JADX INFO: Added by JADX */
        public static final int str_nanrq2 = 0x7f0e00b5;

        /* JADX INFO: Added by JADX */
        public static final int str_xma9vm = 0x7f0e00b6;

        /* JADX INFO: Added by JADX */
        public static final int str_35ltm0 = 0x7f0e00b7;

        /* JADX INFO: Added by JADX */
        public static final int str_glakll = 0x7f0e00b8;

        /* JADX INFO: Added by JADX */
        public static final int str_sbndw9 = 0x7f0e00b9;

        /* JADX INFO: Added by JADX */
        public static final int str_px1odb = 0x7f0e00ba;

        /* JADX INFO: Added by JADX */
        public static final int str_d0qorg = 0x7f0e00bb;

        /* JADX INFO: Added by JADX */
        public static final int str_vrkai0 = 0x7f0e00bc;

        /* JADX INFO: Added by JADX */
        public static final int str_qhh9t8 = 0x7f0e00bd;

        /* JADX INFO: Added by JADX */
        public static final int str_yreo8m = 0x7f0e00be;

        /* JADX INFO: Added by JADX */
        public static final int str_5vmpwq = 0x7f0e00bf;

        /* JADX INFO: Added by JADX */
        public static final int str_y5c7w4 = 0x7f0e00c0;

        /* JADX INFO: Added by JADX */
        public static final int str_d3q0gz = 0x7f0e00c1;

        /* JADX INFO: Added by JADX */
        public static final int str_yciwpp = 0x7f0e00c2;

        /* JADX INFO: Added by JADX */
        public static final int str_raj7wf = 0x7f0e00c3;

        /* JADX INFO: Added by JADX */
        public static final int str_stqd74 = 0x7f0e00c4;

        /* JADX INFO: Added by JADX */
        public static final int str_1l6g81 = 0x7f0e00c5;

        /* JADX INFO: Added by JADX */
        public static final int str_ts93xt = 0x7f0e00c6;

        /* JADX INFO: Added by JADX */
        public static final int str_avocf6 = 0x7f0e00c7;

        /* JADX INFO: Added by JADX */
        public static final int str_h2g3q8 = 0x7f0e00c8;

        /* JADX INFO: Added by JADX */
        public static final int str_ejk05z = 0x7f0e00c9;

        /* JADX INFO: Added by JADX */
        public static final int str_vfazfu = 0x7f0e00ca;

        /* JADX INFO: Added by JADX */
        public static final int str_csxazc = 0x7f0e00cb;

        /* JADX INFO: Added by JADX */
        public static final int str_hvlt4k = 0x7f0e00cc;

        /* JADX INFO: Added by JADX */
        public static final int str_nv7232 = 0x7f0e00cd;

        /* JADX INFO: Added by JADX */
        public static final int str_u02fjc = 0x7f0e00ce;

        /* JADX INFO: Added by JADX */
        public static final int str_7w6zq5 = 0x7f0e00cf;

        /* JADX INFO: Added by JADX */
        public static final int str_r7v67l = 0x7f0e00d0;

        /* JADX INFO: Added by JADX */
        public static final int str_t51z56 = 0x7f0e00d1;

        /* JADX INFO: Added by JADX */
        public static final int str_l8uowc = 0x7f0e00d2;

        /* JADX INFO: Added by JADX */
        public static final int str_pdmf95 = 0x7f0e00d3;

        /* JADX INFO: Added by JADX */
        public static final int str_4pmy2c = 0x7f0e00d4;

        /* JADX INFO: Added by JADX */
        public static final int str_5708md = 0x7f0e00d5;

        /* JADX INFO: Added by JADX */
        public static final int str_wtibbo = 0x7f0e00d6;

        /* JADX INFO: Added by JADX */
        public static final int str_lexhbf = 0x7f0e00d7;

        /* JADX INFO: Added by JADX */
        public static final int str_o1byh8 = 0x7f0e00d8;

        /* JADX INFO: Added by JADX */
        public static final int str_jvx972 = 0x7f0e00d9;

        /* JADX INFO: Added by JADX */
        public static final int str_cv7jci = 0x7f0e00da;

        /* JADX INFO: Added by JADX */
        public static final int str_fuaq0p = 0x7f0e00db;

        /* JADX INFO: Added by JADX */
        public static final int str_vj4s7e = 0x7f0e00dc;

        /* JADX INFO: Added by JADX */
        public static final int str_x975dg = 0x7f0e00dd;

        /* JADX INFO: Added by JADX */
        public static final int str_30ctpv = 0x7f0e00de;

        /* JADX INFO: Added by JADX */
        public static final int str_ecmt51 = 0x7f0e00df;

        /* JADX INFO: Added by JADX */
        public static final int str_gh0lvf = 0x7f0e00e0;

        /* JADX INFO: Added by JADX */
        public static final int str_i1watk = 0x7f0e00e1;

        /* JADX INFO: Added by JADX */
        public static final int str_103s5k = 0x7f0e00e2;

        /* JADX INFO: Added by JADX */
        public static final int str_3dbppe = 0x7f0e00e3;

        /* JADX INFO: Added by JADX */
        public static final int str_nr92tf = 0x7f0e00e4;

        /* JADX INFO: Added by JADX */
        public static final int str_gv2i56 = 0x7f0e00e5;

        /* JADX INFO: Added by JADX */
        public static final int str_p6i8ys = 0x7f0e00e6;

        /* JADX INFO: Added by JADX */
        public static final int str_r9mrzp = 0x7f0e00e7;

        /* JADX INFO: Added by JADX */
        public static final int str_z1nwf0 = 0x7f0e00e8;

        /* JADX INFO: Added by JADX */
        public static final int str_syqwkq = 0x7f0e00e9;

        /* JADX INFO: Added by JADX */
        public static final int str_euqkxt = 0x7f0e00ea;

        /* JADX INFO: Added by JADX */
        public static final int str_ot85in = 0x7f0e00eb;

        /* JADX INFO: Added by JADX */
        public static final int str_eyjj5n = 0x7f0e00ec;

        /* JADX INFO: Added by JADX */
        public static final int str_2hl2wh = 0x7f0e00ed;

        /* JADX INFO: Added by JADX */
        public static final int str_6kvcp6 = 0x7f0e00ee;

        /* JADX INFO: Added by JADX */
        public static final int str_9mc6ix = 0x7f0e00ef;

        /* JADX INFO: Added by JADX */
        public static final int str_841unw = 0x7f0e00f0;

        /* JADX INFO: Added by JADX */
        public static final int str_n3zygr = 0x7f0e00f1;

        /* JADX INFO: Added by JADX */
        public static final int str_27cytj = 0x7f0e00f2;

        /* JADX INFO: Added by JADX */
        public static final int str_f7p0b9 = 0x7f0e00f3;

        /* JADX INFO: Added by JADX */
        public static final int str_3xbtnz = 0x7f0e00f4;

        /* JADX INFO: Added by JADX */
        public static final int str_rav40s = 0x7f0e00f5;

        /* JADX INFO: Added by JADX */
        public static final int str_coejra = 0x7f0e00f6;

        /* JADX INFO: Added by JADX */
        public static final int str_y09q4o = 0x7f0e00f7;

        /* JADX INFO: Added by JADX */
        public static final int str_3rix7s = 0x7f0e00f8;

        /* JADX INFO: Added by JADX */
        public static final int str_3zqao5 = 0x7f0e00f9;

        /* JADX INFO: Added by JADX */
        public static final int str_tperfy = 0x7f0e00fa;

        /* JADX INFO: Added by JADX */
        public static final int str_xc7ulz = 0x7f0e00fb;

        /* JADX INFO: Added by JADX */
        public static final int str_7u1169 = 0x7f0e00fc;

        /* JADX INFO: Added by JADX */
        public static final int str_k18znf = 0x7f0e00fd;

        /* JADX INFO: Added by JADX */
        public static final int str_amfgib = 0x7f0e00fe;

        /* JADX INFO: Added by JADX */
        public static final int str_bsa3yb = 0x7f0e00ff;

        /* JADX INFO: Added by JADX */
        public static final int str_icjlpf = 0x7f0e0100;

        /* JADX INFO: Added by JADX */
        public static final int str_xspb5o = 0x7f0e0101;

        /* JADX INFO: Added by JADX */
        public static final int str_2obqwd = 0x7f0e0102;

        /* JADX INFO: Added by JADX */
        public static final int str_8rzgnq = 0x7f0e0103;

        /* JADX INFO: Added by JADX */
        public static final int str_ujsser = 0x7f0e0104;

        /* JADX INFO: Added by JADX */
        public static final int str_8z11v9 = 0x7f0e0105;

        /* JADX INFO: Added by JADX */
        public static final int str_inkkj2 = 0x7f0e0106;

        /* JADX INFO: Added by JADX */
        public static final int str_u8jexa = 0x7f0e0107;

        /* JADX INFO: Added by JADX */
        public static final int str_fseion = 0x7f0e0108;

        /* JADX INFO: Added by JADX */
        public static final int str_uei3sy = 0x7f0e0109;

        /* JADX INFO: Added by JADX */
        public static final int str_7rporb = 0x7f0e010a;

        /* JADX INFO: Added by JADX */
        public static final int str_gp0z93 = 0x7f0e010b;

        /* JADX INFO: Added by JADX */
        public static final int str_2rkv6t = 0x7f0e010c;

        /* JADX INFO: Added by JADX */
        public static final int str_rs98ep = 0x7f0e010d;

        /* JADX INFO: Added by JADX */
        public static final int str_dzmet9 = 0x7f0e010e;

        /* JADX INFO: Added by JADX */
        public static final int str_18u1cc = 0x7f0e010f;

        /* JADX INFO: Added by JADX */
        public static final int str_gz89br = 0x7f0e0110;

        /* JADX INFO: Added by JADX */
        public static final int str_i902mm = 0x7f0e0111;

        /* JADX INFO: Added by JADX */
        public static final int str_c38bz5 = 0x7f0e0112;

        /* JADX INFO: Added by JADX */
        public static final int str_delwzs = 0x7f0e0113;

        /* JADX INFO: Added by JADX */
        public static final int str_ql3xvm = 0x7f0e0114;

        /* JADX INFO: Added by JADX */
        public static final int str_kvv9d8 = 0x7f0e0115;

        /* JADX INFO: Added by JADX */
        public static final int str_7xkimo = 0x7f0e0116;

        /* JADX INFO: Added by JADX */
        public static final int str_xh8c0l = 0x7f0e0117;

        /* JADX INFO: Added by JADX */
        public static final int str_6h71ar = 0x7f0e0118;

        /* JADX INFO: Added by JADX */
        public static final int str_9sw60w = 0x7f0e0119;

        /* JADX INFO: Added by JADX */
        public static final int str_ubrqzd = 0x7f0e011a;

        /* JADX INFO: Added by JADX */
        public static final int str_ynsfvn = 0x7f0e011b;

        /* JADX INFO: Added by JADX */
        public static final int str_czppu2 = 0x7f0e011c;

        /* JADX INFO: Added by JADX */
        public static final int str_xjivl1 = 0x7f0e011d;

        /* JADX INFO: Added by JADX */
        public static final int str_jo942p = 0x7f0e011e;

        /* JADX INFO: Added by JADX */
        public static final int str_lwz0oc = 0x7f0e011f;

        /* JADX INFO: Added by JADX */
        public static final int str_31lgrj = 0x7f0e0120;

        /* JADX INFO: Added by JADX */
        public static final int str_vl0yki = 0x7f0e0121;

        /* JADX INFO: Added by JADX */
        public static final int str_fxulmh = 0x7f0e0122;

        /* JADX INFO: Added by JADX */
        public static final int str_e07nfy = 0x7f0e0123;

        /* JADX INFO: Added by JADX */
        public static final int str_hhin4a = 0x7f0e0124;

        /* JADX INFO: Added by JADX */
        public static final int str_6kest3 = 0x7f0e0125;

        /* JADX INFO: Added by JADX */
        public static final int str_1ek9nx = 0x7f0e0126;

        /* JADX INFO: Added by JADX */
        public static final int str_3ohxzf = 0x7f0e0127;

        /* JADX INFO: Added by JADX */
        public static final int str_ib7nvw = 0x7f0e0128;

        /* JADX INFO: Added by JADX */
        public static final int str_ty8h4i = 0x7f0e0129;

        /* JADX INFO: Added by JADX */
        public static final int str_6pdnwz = 0x7f0e012a;

        /* JADX INFO: Added by JADX */
        public static final int str_rbrafu = 0x7f0e012b;

        /* JADX INFO: Added by JADX */
        public static final int str_0th4z8 = 0x7f0e012c;

        /* JADX INFO: Added by JADX */
        public static final int str_r7gnqx = 0x7f0e012d;

        /* JADX INFO: Added by JADX */
        public static final int str_2dg2aa = 0x7f0e012e;

        private string() {
        }
    }

    public static final class style {
        public static int AlertDialog_AppCompat = 0x7f0f0000;
        public static int AlertDialog_AppCompat_Light = 0x7f0f0001;
        public static int Animation_AppCompat_Dialog = 0x7f0f0002;
        public static int Animation_AppCompat_DropDownUp = 0x7f0f0003;
        public static int Animation_AppCompat_Tooltip = 0x7f0f0004;
        public static int Animation_Design_BottomSheetDialog = 0x7f0f0005;
        public static int Animation_Material3_BottomSheetDialog = 0x7f0f0006;
        public static int Animation_Material3_SideSheetDialog = 0x7f0f0007;
        public static int Animation_Material3_SideSheetDialog_Left = 0x7f0f0008;
        public static int Animation_Material3_SideSheetDialog_Right = 0x7f0f0009;
        public static int Animation_MaterialComponents_BottomSheetDialog = 0x7f0f000a;
        public static int Base_AlertDialog_AppCompat = 0x7f0f000b;
        public static int Base_AlertDialog_AppCompat_Light = 0x7f0f000c;
        public static int Base_Animation_AppCompat_Dialog = 0x7f0f000d;
        public static int Base_Animation_AppCompat_DropDownUp = 0x7f0f000e;
        public static int Base_Animation_AppCompat_Tooltip = 0x7f0f000f;
        public static int Base_CardView = 0x7f0f0010;
        public static int Base_DialogWindowTitleBackground_AppCompat = 0x7f0f0012;
        public static int Base_DialogWindowTitle_AppCompat = 0x7f0f0011;
        public static int Base_MaterialAlertDialog_MaterialComponents_Title_Icon = 0x7f0f0013;
        public static int Base_MaterialAlertDialog_MaterialComponents_Title_Panel = 0x7f0f0014;
        public static int Base_MaterialAlertDialog_MaterialComponents_Title_Text = 0x7f0f0015;
        public static int Base_TextAppearance_AppCompat = 0x7f0f0016;
        public static int Base_TextAppearance_AppCompat_Body1 = 0x7f0f0017;
        public static int Base_TextAppearance_AppCompat_Body2 = 0x7f0f0018;
        public static int Base_TextAppearance_AppCompat_Button = 0x7f0f0019;
        public static int Base_TextAppearance_AppCompat_Caption = 0x7f0f001a;
        public static int Base_TextAppearance_AppCompat_Display1 = 0x7f0f001b;
        public static int Base_TextAppearance_AppCompat_Display2 = 0x7f0f001c;
        public static int Base_TextAppearance_AppCompat_Display3 = 0x7f0f001d;
        public static int Base_TextAppearance_AppCompat_Display4 = 0x7f0f001e;
        public static int Base_TextAppearance_AppCompat_Headline = 0x7f0f001f;
        public static int Base_TextAppearance_AppCompat_Inverse = 0x7f0f0020;
        public static int Base_TextAppearance_AppCompat_Large = 0x7f0f0021;
        public static int Base_TextAppearance_AppCompat_Large_Inverse = 0x7f0f0022;
        public static int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f0f0023;
        public static int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f0f0024;
        public static int Base_TextAppearance_AppCompat_Medium = 0x7f0f0025;
        public static int Base_TextAppearance_AppCompat_Medium_Inverse = 0x7f0f0026;
        public static int Base_TextAppearance_AppCompat_Menu = 0x7f0f0027;
        public static int Base_TextAppearance_AppCompat_SearchResult = 0x7f0f0028;
        public static int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f0f0029;
        public static int Base_TextAppearance_AppCompat_SearchResult_Title = 0x7f0f002a;
        public static int Base_TextAppearance_AppCompat_Small = 0x7f0f002b;
        public static int Base_TextAppearance_AppCompat_Small_Inverse = 0x7f0f002c;
        public static int Base_TextAppearance_AppCompat_Subhead = 0x7f0f002d;
        public static int Base_TextAppearance_AppCompat_Subhead_Inverse = 0x7f0f002e;
        public static int Base_TextAppearance_AppCompat_Title = 0x7f0f002f;
        public static int Base_TextAppearance_AppCompat_Title_Inverse = 0x7f0f0030;
        public static int Base_TextAppearance_AppCompat_Tooltip = 0x7f0f0031;
        public static int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f0f0032;
        public static int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f0f0033;
        public static int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f0f0034;
        public static int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f0f0035;
        public static int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f0f0036;
        public static int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f0f0037;
        public static int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f0f0038;
        public static int Base_TextAppearance_AppCompat_Widget_Button = 0x7f0f0039;
        public static int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 0x7f0f003a;
        public static int Base_TextAppearance_AppCompat_Widget_Button_Colored = 0x7f0f003b;
        public static int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 0x7f0f003c;
        public static int Base_TextAppearance_AppCompat_Widget_DropDownItem = 0x7f0f003d;
        public static int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 0x7f0f003e;
        public static int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f0f003f;
        public static int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f0f0040;
        public static int Base_TextAppearance_AppCompat_Widget_Switch = 0x7f0f0041;
        public static int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 0x7f0f0042;
        public static int Base_TextAppearance_Material3_Search = 0x7f0f0043;
        public static int Base_TextAppearance_MaterialComponents_Badge = 0x7f0f0044;
        public static int Base_TextAppearance_MaterialComponents_Button = 0x7f0f0045;
        public static int Base_TextAppearance_MaterialComponents_Headline6 = 0x7f0f0046;
        public static int Base_TextAppearance_MaterialComponents_Subtitle2 = 0x7f0f0047;
        public static int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f0f0048;
        public static int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f0f0049;
        public static int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f0f004a;
        public static int Base_ThemeOverlay_AppCompat = 0x7f0f0078;
        public static int Base_ThemeOverlay_AppCompat_ActionBar = 0x7f0f0079;
        public static int Base_ThemeOverlay_AppCompat_Dark = 0x7f0f007a;
        public static int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f0f007b;
        public static int Base_ThemeOverlay_AppCompat_Dialog = 0x7f0f007c;
        public static int Base_ThemeOverlay_AppCompat_Dialog_Alert = 0x7f0f007d;
        public static int Base_ThemeOverlay_AppCompat_Light = 0x7f0f007e;
        public static int Base_ThemeOverlay_Material3_AutoCompleteTextView = 0x7f0f007f;
        public static int Base_ThemeOverlay_Material3_BottomSheetDialog = 0x7f0f0080;
        public static int Base_ThemeOverlay_Material3_Dialog = 0x7f0f0081;
        public static int Base_ThemeOverlay_Material3_SideSheetDialog = 0x7f0f0082;
        public static int Base_ThemeOverlay_Material3_TextInputEditText = 0x7f0f0083;
        public static int Base_ThemeOverlay_MaterialComponents_Dialog = 0x7f0f0084;
        public static int Base_ThemeOverlay_MaterialComponents_Dialog_Alert = 0x7f0f0085;
        public static int Base_ThemeOverlay_MaterialComponents_Dialog_Alert_Framework = 0x7f0f0086;
        public static int Base_ThemeOverlay_MaterialComponents_Light_Dialog_Alert_Framework = 0x7f0f0087;
        public static int Base_ThemeOverlay_MaterialComponents_MaterialAlertDialog = 0x7f0f0088;
        public static int Base_Theme_AppCompat = 0x7f0f004b;
        public static int Base_Theme_AppCompat_CompactMenu = 0x7f0f004c;
        public static int Base_Theme_AppCompat_Dialog = 0x7f0f004d;
        public static int Base_Theme_AppCompat_DialogWhenLarge = 0x7f0f0051;
        public static int Base_Theme_AppCompat_Dialog_Alert = 0x7f0f004e;
        public static int Base_Theme_AppCompat_Dialog_FixedSize = 0x7f0f004f;
        public static int Base_Theme_AppCompat_Dialog_MinWidth = 0x7f0f0050;
        public static int Base_Theme_AppCompat_Light = 0x7f0f0052;
        public static int Base_Theme_AppCompat_Light_DarkActionBar = 0x7f0f0053;
        public static int Base_Theme_AppCompat_Light_Dialog = 0x7f0f0054;
        public static int Base_Theme_AppCompat_Light_DialogWhenLarge = 0x7f0f0058;
        public static int Base_Theme_AppCompat_Light_Dialog_Alert = 0x7f0f0055;
        public static int Base_Theme_AppCompat_Light_Dialog_FixedSize = 0x7f0f0056;
        public static int Base_Theme_AppCompat_Light_Dialog_MinWidth = 0x7f0f0057;
        public static int Base_Theme_Material3_Dark = 0x7f0f0059;
        public static int Base_Theme_Material3_Dark_BottomSheetDialog = 0x7f0f005a;
        public static int Base_Theme_Material3_Dark_Dialog = 0x7f0f005b;
        public static int Base_Theme_Material3_Dark_DialogWhenLarge = 0x7f0f005d;
        public static int Base_Theme_Material3_Dark_Dialog_FixedSize = 0x7f0f005c;
        public static int Base_Theme_Material3_Dark_SideSheetDialog = 0x7f0f005e;
        public static int Base_Theme_Material3_Light = 0x7f0f005f;
        public static int Base_Theme_Material3_Light_BottomSheetDialog = 0x7f0f0060;
        public static int Base_Theme_Material3_Light_Dialog = 0x7f0f0061;
        public static int Base_Theme_Material3_Light_DialogWhenLarge = 0x7f0f0063;
        public static int Base_Theme_Material3_Light_Dialog_FixedSize = 0x7f0f0062;
        public static int Base_Theme_Material3_Light_SideSheetDialog = 0x7f0f0064;
        public static int Base_Theme_MaterialComponents = 0x7f0f0065;
        public static int Base_Theme_MaterialComponents_Bridge = 0x7f0f0066;
        public static int Base_Theme_MaterialComponents_CompactMenu = 0x7f0f0067;
        public static int Base_Theme_MaterialComponents_Dialog = 0x7f0f0068;
        public static int Base_Theme_MaterialComponents_DialogWhenLarge = 0x7f0f006d;
        public static int Base_Theme_MaterialComponents_Dialog_Alert = 0x7f0f0069;
        public static int Base_Theme_MaterialComponents_Dialog_Bridge = 0x7f0f006a;
        public static int Base_Theme_MaterialComponents_Dialog_FixedSize = 0x7f0f006b;
        public static int Base_Theme_MaterialComponents_Dialog_MinWidth = 0x7f0f006c;
        public static int Base_Theme_MaterialComponents_Light = 0x7f0f006e;
        public static int Base_Theme_MaterialComponents_Light_Bridge = 0x7f0f006f;
        public static int Base_Theme_MaterialComponents_Light_DarkActionBar = 0x7f0f0070;
        public static int Base_Theme_MaterialComponents_Light_DarkActionBar_Bridge = 0x7f0f0071;
        public static int Base_Theme_MaterialComponents_Light_Dialog = 0x7f0f0072;
        public static int Base_Theme_MaterialComponents_Light_DialogWhenLarge = 0x7f0f0077;
        public static int Base_Theme_MaterialComponents_Light_Dialog_Alert = 0x7f0f0073;
        public static int Base_Theme_MaterialComponents_Light_Dialog_Bridge = 0x7f0f0074;
        public static int Base_Theme_MaterialComponents_Light_Dialog_FixedSize = 0x7f0f0075;
        public static int Base_Theme_MaterialComponents_Light_Dialog_MinWidth = 0x7f0f0076;
        public static int Base_V14_ThemeOverlay_Material3_BottomSheetDialog = 0x7f0f009a;
        public static int Base_V14_ThemeOverlay_Material3_SideSheetDialog = 0x7f0f009b;
        public static int Base_V14_ThemeOverlay_MaterialComponents_BottomSheetDialog = 0x7f0f009c;
        public static int Base_V14_ThemeOverlay_MaterialComponents_Dialog = 0x7f0f009d;
        public static int Base_V14_ThemeOverlay_MaterialComponents_Dialog_Alert = 0x7f0f009e;
        public static int Base_V14_ThemeOverlay_MaterialComponents_MaterialAlertDialog = 0x7f0f009f;
        public static int Base_V14_Theme_Material3_Dark = 0x7f0f0089;
        public static int Base_V14_Theme_Material3_Dark_BottomSheetDialog = 0x7f0f008a;
        public static int Base_V14_Theme_Material3_Dark_Dialog = 0x7f0f008b;
        public static int Base_V14_Theme_Material3_Dark_SideSheetDialog = 0x7f0f008c;
        public static int Base_V14_Theme_Material3_Light = 0x7f0f008d;
        public static int Base_V14_Theme_Material3_Light_BottomSheetDialog = 0x7f0f008e;
        public static int Base_V14_Theme_Material3_Light_Dialog = 0x7f0f008f;
        public static int Base_V14_Theme_Material3_Light_SideSheetDialog = 0x7f0f0090;
        public static int Base_V14_Theme_MaterialComponents = 0x7f0f0091;
        public static int Base_V14_Theme_MaterialComponents_Bridge = 0x7f0f0092;
        public static int Base_V14_Theme_MaterialComponents_Dialog = 0x7f0f0093;
        public static int Base_V14_Theme_MaterialComponents_Dialog_Bridge = 0x7f0f0094;
        public static int Base_V14_Theme_MaterialComponents_Light = 0x7f0f0095;
        public static int Base_V14_Theme_MaterialComponents_Light_Bridge = 0x7f0f0096;
        public static int Base_V14_Theme_MaterialComponents_Light_DarkActionBar_Bridge = 0x7f0f0097;
        public static int Base_V14_Theme_MaterialComponents_Light_Dialog = 0x7f0f0098;
        public static int Base_V14_Theme_MaterialComponents_Light_Dialog_Bridge = 0x7f0f0099;
        public static int Base_V14_Widget_MaterialComponents_AutoCompleteTextView = 0x7f0f00a0;
        public static int Base_V21_ThemeOverlay_AppCompat_Dialog = 0x7f0f00a9;
        public static int Base_V21_ThemeOverlay_Material3_BottomSheetDialog = 0x7f0f00aa;
        public static int Base_V21_ThemeOverlay_Material3_SideSheetDialog = 0x7f0f00ab;
        public static int Base_V21_ThemeOverlay_MaterialComponents_BottomSheetDialog = 0x7f0f00ac;
        public static int Base_V21_Theme_AppCompat = 0x7f0f00a1;
        public static int Base_V21_Theme_AppCompat_Dialog = 0x7f0f00a2;
        public static int Base_V21_Theme_AppCompat_Light = 0x7f0f00a3;
        public static int Base_V21_Theme_AppCompat_Light_Dialog = 0x7f0f00a4;
        public static int Base_V21_Theme_MaterialComponents = 0x7f0f00a5;
        public static int Base_V21_Theme_MaterialComponents_Dialog = 0x7f0f00a6;
        public static int Base_V21_Theme_MaterialComponents_Light = 0x7f0f00a7;
        public static int Base_V21_Theme_MaterialComponents_Light_Dialog = 0x7f0f00a8;
        public static int Base_V22_Theme_AppCompat = 0x7f0f00ad;
        public static int Base_V22_Theme_AppCompat_Light = 0x7f0f00ae;
        public static int Base_V23_Theme_AppCompat = 0x7f0f00af;
        public static int Base_V23_Theme_AppCompat_Light = 0x7f0f00b0;
        public static int Base_V24_Theme_Material3_Dark = 0x7f0f00b1;
        public static int Base_V24_Theme_Material3_Dark_Dialog = 0x7f0f00b2;
        public static int Base_V24_Theme_Material3_Light = 0x7f0f00b3;
        public static int Base_V24_Theme_Material3_Light_Dialog = 0x7f0f00b4;
        public static int Base_V26_Theme_AppCompat = 0x7f0f00b5;
        public static int Base_V26_Theme_AppCompat_Light = 0x7f0f00b6;
        public static int Base_V26_Widget_AppCompat_Toolbar = 0x7f0f00b7;
        public static int Base_V28_Theme_AppCompat = 0x7f0f00b8;
        public static int Base_V28_Theme_AppCompat_Light = 0x7f0f00b9;
        public static int Base_V7_ThemeOverlay_AppCompat_Dialog = 0x7f0f00be;
        public static int Base_V7_Theme_AppCompat = 0x7f0f00ba;
        public static int Base_V7_Theme_AppCompat_Dialog = 0x7f0f00bb;
        public static int Base_V7_Theme_AppCompat_Light = 0x7f0f00bc;
        public static int Base_V7_Theme_AppCompat_Light_Dialog = 0x7f0f00bd;
        public static int Base_V7_Widget_AppCompat_AutoCompleteTextView = 0x7f0f00bf;
        public static int Base_V7_Widget_AppCompat_EditText = 0x7f0f00c0;
        public static int Base_V7_Widget_AppCompat_Toolbar = 0x7f0f00c1;
        public static int Base_Widget_AppCompat_ActionBar = 0x7f0f00c2;
        public static int Base_Widget_AppCompat_ActionBar_Solid = 0x7f0f00c3;
        public static int Base_Widget_AppCompat_ActionBar_TabBar = 0x7f0f00c4;
        public static int Base_Widget_AppCompat_ActionBar_TabText = 0x7f0f00c5;
        public static int Base_Widget_AppCompat_ActionBar_TabView = 0x7f0f00c6;
        public static int Base_Widget_AppCompat_ActionButton = 0x7f0f00c7;
        public static int Base_Widget_AppCompat_ActionButton_CloseMode = 0x7f0f00c8;
        public static int Base_Widget_AppCompat_ActionButton_Overflow = 0x7f0f00c9;
        public static int Base_Widget_AppCompat_ActionMode = 0x7f0f00ca;
        public static int Base_Widget_AppCompat_ActivityChooserView = 0x7f0f00cb;
        public static int Base_Widget_AppCompat_AutoCompleteTextView = 0x7f0f00cc;
        public static int Base_Widget_AppCompat_Button = 0x7f0f00cd;
        public static int Base_Widget_AppCompat_ButtonBar = 0x7f0f00d3;
        public static int Base_Widget_AppCompat_ButtonBar_AlertDialog = 0x7f0f00d4;
        public static int Base_Widget_AppCompat_Button_Borderless = 0x7f0f00ce;
        public static int Base_Widget_AppCompat_Button_Borderless_Colored = 0x7f0f00cf;
        public static int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 0x7f0f00d0;
        public static int Base_Widget_AppCompat_Button_Colored = 0x7f0f00d1;
        public static int Base_Widget_AppCompat_Button_Small = 0x7f0f00d2;
        public static int Base_Widget_AppCompat_CompoundButton_CheckBox = 0x7f0f00d5;
        public static int Base_Widget_AppCompat_CompoundButton_RadioButton = 0x7f0f00d6;
        public static int Base_Widget_AppCompat_CompoundButton_Switch = 0x7f0f00d7;
        public static int Base_Widget_AppCompat_DrawerArrowToggle = 0x7f0f00d8;
        public static int Base_Widget_AppCompat_DrawerArrowToggle_Common = 0x7f0f00d9;
        public static int Base_Widget_AppCompat_DropDownItem_Spinner = 0x7f0f00da;
        public static int Base_Widget_AppCompat_EditText = 0x7f0f00db;
        public static int Base_Widget_AppCompat_ImageButton = 0x7f0f00dc;
        public static int Base_Widget_AppCompat_Light_ActionBar = 0x7f0f00dd;
        public static int Base_Widget_AppCompat_Light_ActionBar_Solid = 0x7f0f00de;
        public static int Base_Widget_AppCompat_Light_ActionBar_TabBar = 0x7f0f00df;
        public static int Base_Widget_AppCompat_Light_ActionBar_TabText = 0x7f0f00e0;
        public static int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 0x7f0f00e1;
        public static int Base_Widget_AppCompat_Light_ActionBar_TabView = 0x7f0f00e2;
        public static int Base_Widget_AppCompat_Light_PopupMenu = 0x7f0f00e3;
        public static int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f0f00e4;
        public static int Base_Widget_AppCompat_ListMenuView = 0x7f0f00e5;
        public static int Base_Widget_AppCompat_ListPopupWindow = 0x7f0f00e6;
        public static int Base_Widget_AppCompat_ListView = 0x7f0f00e7;
        public static int Base_Widget_AppCompat_ListView_DropDown = 0x7f0f00e8;
        public static int Base_Widget_AppCompat_ListView_Menu = 0x7f0f00e9;
        public static int Base_Widget_AppCompat_PopupMenu = 0x7f0f00ea;
        public static int Base_Widget_AppCompat_PopupMenu_Overflow = 0x7f0f00eb;
        public static int Base_Widget_AppCompat_PopupWindow = 0x7f0f00ec;
        public static int Base_Widget_AppCompat_ProgressBar = 0x7f0f00ed;
        public static int Base_Widget_AppCompat_ProgressBar_Horizontal = 0x7f0f00ee;
        public static int Base_Widget_AppCompat_RatingBar = 0x7f0f00ef;
        public static int Base_Widget_AppCompat_RatingBar_Indicator = 0x7f0f00f0;
        public static int Base_Widget_AppCompat_RatingBar_Small = 0x7f0f00f1;
        public static int Base_Widget_AppCompat_SearchView = 0x7f0f00f2;
        public static int Base_Widget_AppCompat_SearchView_ActionBar = 0x7f0f00f3;
        public static int Base_Widget_AppCompat_SeekBar = 0x7f0f00f4;
        public static int Base_Widget_AppCompat_SeekBar_Discrete = 0x7f0f00f5;
        public static int Base_Widget_AppCompat_Spinner = 0x7f0f00f6;
        public static int Base_Widget_AppCompat_Spinner_Underlined = 0x7f0f00f7;
        public static int Base_Widget_AppCompat_TextView = 0x7f0f00f8;
        public static int Base_Widget_AppCompat_TextView_SpinnerItem = 0x7f0f00f9;
        public static int Base_Widget_AppCompat_Toolbar = 0x7f0f00fa;
        public static int Base_Widget_AppCompat_Toolbar_Button_Navigation = 0x7f0f00fb;
        public static int Base_Widget_Design_TabLayout = 0x7f0f00fc;
        public static int Base_Widget_Material3_ActionBar_Solid = 0x7f0f00fd;
        public static int Base_Widget_Material3_ActionMode = 0x7f0f00fe;
        public static int Base_Widget_Material3_BottomNavigationView = 0x7f0f00ff;
        public static int Base_Widget_Material3_CardView = 0x7f0f0100;
        public static int Base_Widget_Material3_Chip = 0x7f0f0101;
        public static int Base_Widget_Material3_CollapsingToolbar = 0x7f0f0102;
        public static int Base_Widget_Material3_CompoundButton_CheckBox = 0x7f0f0103;
        public static int Base_Widget_Material3_CompoundButton_RadioButton = 0x7f0f0104;
        public static int Base_Widget_Material3_CompoundButton_Switch = 0x7f0f0105;
        public static int Base_Widget_Material3_ExtendedFloatingActionButton = 0x7f0f0106;
        public static int Base_Widget_Material3_ExtendedFloatingActionButton_Icon = 0x7f0f0107;
        public static int Base_Widget_Material3_FloatingActionButton = 0x7f0f0108;
        public static int Base_Widget_Material3_FloatingActionButton_Large = 0x7f0f0109;
        public static int Base_Widget_Material3_FloatingActionButton_Small = 0x7f0f010a;
        public static int Base_Widget_Material3_Light_ActionBar_Solid = 0x7f0f010b;
        public static int Base_Widget_Material3_MaterialCalendar_NavigationButton = 0x7f0f010c;
        public static int Base_Widget_Material3_Snackbar = 0x7f0f010d;
        public static int Base_Widget_Material3_TabLayout = 0x7f0f010e;
        public static int Base_Widget_Material3_TabLayout_OnSurface = 0x7f0f010f;
        public static int Base_Widget_Material3_TabLayout_Secondary = 0x7f0f0110;
        public static int Base_Widget_MaterialComponents_AutoCompleteTextView = 0x7f0f0111;
        public static int Base_Widget_MaterialComponents_CheckedTextView = 0x7f0f0112;
        public static int Base_Widget_MaterialComponents_Chip = 0x7f0f0113;
        public static int Base_Widget_MaterialComponents_MaterialCalendar_HeaderToggleButton = 0x7f0f0114;
        public static int Base_Widget_MaterialComponents_MaterialCalendar_NavigationButton = 0x7f0f0115;
        public static int Base_Widget_MaterialComponents_PopupMenu = 0x7f0f0116;
        public static int Base_Widget_MaterialComponents_PopupMenu_ContextMenu = 0x7f0f0117;
        public static int Base_Widget_MaterialComponents_PopupMenu_ListPopupWindow = 0x7f0f0118;
        public static int Base_Widget_MaterialComponents_PopupMenu_Overflow = 0x7f0f0119;
        public static int Base_Widget_MaterialComponents_Slider = 0x7f0f011a;
        public static int Base_Widget_MaterialComponents_Snackbar = 0x7f0f011b;
        public static int Base_Widget_MaterialComponents_TextInputEditText = 0x7f0f011c;
        public static int Base_Widget_MaterialComponents_TextInputLayout = 0x7f0f011d;
        public static int Base_Widget_MaterialComponents_TextView = 0x7f0f011e;
        public static int CardView = 0x7f0f011f;
        public static int CardView_Dark = 0x7f0f0120;
        public static int CardView_Light = 0x7f0f0121;
        public static int MaterialAlertDialog_Material3 = 0x7f0f0122;
        public static int MaterialAlertDialog_Material3_Animation = 0x7f0f0123;
        public static int MaterialAlertDialog_Material3_Body_Text = 0x7f0f0124;
        public static int MaterialAlertDialog_Material3_Body_Text_CenterStacked = 0x7f0f0125;
        public static int MaterialAlertDialog_Material3_Title_Icon = 0x7f0f0126;
        public static int MaterialAlertDialog_Material3_Title_Icon_CenterStacked = 0x7f0f0127;
        public static int MaterialAlertDialog_Material3_Title_Panel = 0x7f0f0128;
        public static int MaterialAlertDialog_Material3_Title_Panel_CenterStacked = 0x7f0f0129;
        public static int MaterialAlertDialog_Material3_Title_Text = 0x7f0f012a;
        public static int MaterialAlertDialog_Material3_Title_Text_CenterStacked = 0x7f0f012b;
        public static int MaterialAlertDialog_MaterialComponents = 0x7f0f012c;
        public static int MaterialAlertDialog_MaterialComponents_Body_Text = 0x7f0f012d;
        public static int MaterialAlertDialog_MaterialComponents_Picker_Date_Calendar = 0x7f0f012e;
        public static int MaterialAlertDialog_MaterialComponents_Picker_Date_Spinner = 0x7f0f012f;
        public static int MaterialAlertDialog_MaterialComponents_Title_Icon = 0x7f0f0130;
        public static int MaterialAlertDialog_MaterialComponents_Title_Icon_CenterStacked = 0x7f0f0131;
        public static int MaterialAlertDialog_MaterialComponents_Title_Panel = 0x7f0f0132;
        public static int MaterialAlertDialog_MaterialComponents_Title_Panel_CenterStacked = 0x7f0f0133;
        public static int MaterialAlertDialog_MaterialComponents_Title_Text = 0x7f0f0134;
        public static int MaterialAlertDialog_MaterialComponents_Title_Text_CenterStacked = 0x7f0f0135;
        public static int Platform_AppCompat = 0x7f0f0136;
        public static int Platform_AppCompat_Light = 0x7f0f0137;
        public static int Platform_MaterialComponents = 0x7f0f0138;
        public static int Platform_MaterialComponents_Dialog = 0x7f0f0139;
        public static int Platform_MaterialComponents_Light = 0x7f0f013a;
        public static int Platform_MaterialComponents_Light_Dialog = 0x7f0f013b;
        public static int Platform_ThemeOverlay_AppCompat = 0x7f0f013c;
        public static int Platform_ThemeOverlay_AppCompat_Dark = 0x7f0f013d;
        public static int Platform_ThemeOverlay_AppCompat_Light = 0x7f0f013e;
        public static int Platform_V21_AppCompat = 0x7f0f013f;
        public static int Platform_V21_AppCompat_Light = 0x7f0f0140;
        public static int Platform_V25_AppCompat = 0x7f0f0141;
        public static int Platform_V25_AppCompat_Light = 0x7f0f0142;
        public static int Platform_Widget_AppCompat_Spinner = 0x7f0f0143;
        public static int RtlOverlay_DialogWindowTitle_AppCompat = 0x7f0f0144;
        public static int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 0x7f0f0145;
        public static int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 0x7f0f0146;
        public static int RtlOverlay_Widget_AppCompat_PopupMenuItem = 0x7f0f0147;
        public static int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 0x7f0f0148;
        public static int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 0x7f0f0149;
        public static int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 0x7f0f014a;
        public static int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 0x7f0f014b;
        public static int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 0x7f0f014c;
        public static int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 0x7f0f0152;
        public static int RtlOverlay_Widget_AppCompat_Search_DropDown = 0x7f0f014d;
        public static int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 0x7f0f014e;
        public static int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 0x7f0f014f;
        public static int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 0x7f0f0150;
        public static int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 0x7f0f0151;
        public static int RtlUnderlay_Widget_AppCompat_ActionButton = 0x7f0f0153;
        public static int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 0x7f0f0154;
        public static int ShapeAppearanceOverlay_Material3_Button = 0x7f0f0180;
        public static int ShapeAppearanceOverlay_Material3_Chip = 0x7f0f0181;
        public static int ShapeAppearanceOverlay_Material3_Corner_Bottom = 0x7f0f0182;
        public static int ShapeAppearanceOverlay_Material3_Corner_Left = 0x7f0f0183;
        public static int ShapeAppearanceOverlay_Material3_Corner_Right = 0x7f0f0184;
        public static int ShapeAppearanceOverlay_Material3_Corner_Top = 0x7f0f0185;
        public static int ShapeAppearanceOverlay_Material3_FloatingActionButton = 0x7f0f0186;
        public static int ShapeAppearanceOverlay_Material3_NavigationView_Item = 0x7f0f0187;
        public static int ShapeAppearanceOverlay_Material3_SearchBar = 0x7f0f0188;
        public static int ShapeAppearanceOverlay_Material3_SearchView = 0x7f0f0189;
        public static int ShapeAppearanceOverlay_MaterialAlertDialog_Material3 = 0x7f0f018a;
        public static int ShapeAppearanceOverlay_MaterialComponents_BottomSheet = 0x7f0f018b;
        public static int ShapeAppearanceOverlay_MaterialComponents_Chip = 0x7f0f018c;
        public static int ShapeAppearanceOverlay_MaterialComponents_ExtendedFloatingActionButton = 0x7f0f018d;
        public static int ShapeAppearanceOverlay_MaterialComponents_FloatingActionButton = 0x7f0f018e;
        public static int ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Day = 0x7f0f018f;
        public static int ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Window_Fullscreen = 0x7f0f0190;
        public static int ShapeAppearanceOverlay_MaterialComponents_MaterialCalendar_Year = 0x7f0f0191;
        public static int ShapeAppearanceOverlay_MaterialComponents_TextInputLayout_FilledBox = 0x7f0f0192;
        public static int ShapeAppearance_M3_Comp_Badge_Large_Shape = 0x7f0f0155;
        public static int ShapeAppearance_M3_Comp_Badge_Shape = 0x7f0f0156;
        public static int ShapeAppearance_M3_Comp_BottomAppBar_Container_Shape = 0x7f0f0157;
        public static int ShapeAppearance_M3_Comp_DatePicker_Modal_Date_Container_Shape = 0x7f0f0158;
        public static int ShapeAppearance_M3_Comp_FilledButton_Container_Shape = 0x7f0f0159;
        public static int ShapeAppearance_M3_Comp_NavigationBar_ActiveIndicator_Shape = 0x7f0f015a;
        public static int ShapeAppearance_M3_Comp_NavigationBar_Container_Shape = 0x7f0f015b;
        public static int ShapeAppearance_M3_Comp_NavigationDrawer_ActiveIndicator_Shape = 0x7f0f015c;
        public static int ShapeAppearance_M3_Comp_NavigationRail_ActiveIndicator_Shape = 0x7f0f015d;
        public static int ShapeAppearance_M3_Comp_NavigationRail_Container_Shape = 0x7f0f015e;
        public static int ShapeAppearance_M3_Comp_SearchBar_Avatar_Shape = 0x7f0f015f;
        public static int ShapeAppearance_M3_Comp_SearchBar_Container_Shape = 0x7f0f0160;
        public static int ShapeAppearance_M3_Comp_SearchView_FullScreen_Container_Shape = 0x7f0f0161;
        public static int ShapeAppearance_M3_Comp_Sheet_Side_Docked_Container_Shape = 0x7f0f0162;
        public static int ShapeAppearance_M3_Comp_Switch_Handle_Shape = 0x7f0f0163;
        public static int ShapeAppearance_M3_Comp_Switch_StateLayer_Shape = 0x7f0f0164;
        public static int ShapeAppearance_M3_Comp_Switch_Track_Shape = 0x7f0f0165;
        public static int ShapeAppearance_M3_Comp_TextButton_Container_Shape = 0x7f0f0166;
        public static int ShapeAppearance_M3_Sys_Shape_Corner_ExtraLarge = 0x7f0f0167;
        public static int ShapeAppearance_M3_Sys_Shape_Corner_ExtraSmall = 0x7f0f0168;
        public static int ShapeAppearance_M3_Sys_Shape_Corner_Full = 0x7f0f0169;
        public static int ShapeAppearance_M3_Sys_Shape_Corner_Large = 0x7f0f016a;
        public static int ShapeAppearance_M3_Sys_Shape_Corner_Medium = 0x7f0f016b;
        public static int ShapeAppearance_M3_Sys_Shape_Corner_None = 0x7f0f016c;
        public static int ShapeAppearance_M3_Sys_Shape_Corner_Small = 0x7f0f016d;
        public static int ShapeAppearance_Material3_Corner_ExtraLarge = 0x7f0f016e;
        public static int ShapeAppearance_Material3_Corner_ExtraSmall = 0x7f0f016f;
        public static int ShapeAppearance_Material3_Corner_Full = 0x7f0f0170;
        public static int ShapeAppearance_Material3_Corner_Large = 0x7f0f0171;
        public static int ShapeAppearance_Material3_Corner_Medium = 0x7f0f0172;
        public static int ShapeAppearance_Material3_Corner_None = 0x7f0f0173;
        public static int ShapeAppearance_Material3_Corner_Small = 0x7f0f0174;
        public static int ShapeAppearance_Material3_LargeComponent = 0x7f0f0175;
        public static int ShapeAppearance_Material3_MediumComponent = 0x7f0f0176;
        public static int ShapeAppearance_Material3_NavigationBarView_ActiveIndicator = 0x7f0f0177;
        public static int ShapeAppearance_Material3_SmallComponent = 0x7f0f0178;
        public static int ShapeAppearance_Material3_Tooltip = 0x7f0f0179;
        public static int ShapeAppearance_MaterialComponents = 0x7f0f017a;
        public static int ShapeAppearance_MaterialComponents_Badge = 0x7f0f017b;
        public static int ShapeAppearance_MaterialComponents_LargeComponent = 0x7f0f017c;
        public static int ShapeAppearance_MaterialComponents_MediumComponent = 0x7f0f017d;
        public static int ShapeAppearance_MaterialComponents_SmallComponent = 0x7f0f017e;
        public static int ShapeAppearance_MaterialComponents_Tooltip = 0x7f0f017f;
        public static int TextAppearance_AppCompat = 0x7f0f0193;
        public static int TextAppearance_AppCompat_Body1 = 0x7f0f0194;
        public static int TextAppearance_AppCompat_Body2 = 0x7f0f0195;
        public static int TextAppearance_AppCompat_Button = 0x7f0f0196;
        public static int TextAppearance_AppCompat_Caption = 0x7f0f0197;
        public static int TextAppearance_AppCompat_Display1 = 0x7f0f0198;
        public static int TextAppearance_AppCompat_Display2 = 0x7f0f0199;
        public static int TextAppearance_AppCompat_Display3 = 0x7f0f019a;
        public static int TextAppearance_AppCompat_Display4 = 0x7f0f019b;
        public static int TextAppearance_AppCompat_Headline = 0x7f0f019c;
        public static int TextAppearance_AppCompat_Inverse = 0x7f0f019d;
        public static int TextAppearance_AppCompat_Large = 0x7f0f019e;
        public static int TextAppearance_AppCompat_Large_Inverse = 0x7f0f019f;
        public static int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 0x7f0f01a0;
        public static int TextAppearance_AppCompat_Light_SearchResult_Title = 0x7f0f01a1;
        public static int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 0x7f0f01a2;
        public static int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 0x7f0f01a3;
        public static int TextAppearance_AppCompat_Medium = 0x7f0f01a4;
        public static int TextAppearance_AppCompat_Medium_Inverse = 0x7f0f01a5;
        public static int TextAppearance_AppCompat_Menu = 0x7f0f01a6;
        public static int TextAppearance_AppCompat_SearchResult_Subtitle = 0x7f0f01a7;
        public static int TextAppearance_AppCompat_SearchResult_Title = 0x7f0f01a8;
        public static int TextAppearance_AppCompat_Small = 0x7f0f01a9;
        public static int TextAppearance_AppCompat_Small_Inverse = 0x7f0f01aa;
        public static int TextAppearance_AppCompat_Subhead = 0x7f0f01ab;
        public static int TextAppearance_AppCompat_Subhead_Inverse = 0x7f0f01ac;
        public static int TextAppearance_AppCompat_Title = 0x7f0f01ad;
        public static int TextAppearance_AppCompat_Title_Inverse = 0x7f0f01ae;
        public static int TextAppearance_AppCompat_Tooltip = 0x7f0f01af;
        public static int TextAppearance_AppCompat_Widget_ActionBar_Menu = 0x7f0f01b0;
        public static int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 0x7f0f01b1;
        public static int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 0x7f0f01b2;
        public static int TextAppearance_AppCompat_Widget_ActionBar_Title = 0x7f0f01b3;
        public static int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 0x7f0f01b4;
        public static int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 0x7f0f01b5;
        public static int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 0x7f0f01b6;
        public static int TextAppearance_AppCompat_Widget_ActionMode_Title = 0x7f0f01b7;
        public static int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 0x7f0f01b8;
        public static int TextAppearance_AppCompat_Widget_Button = 0x7f0f01b9;
        public static int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 0x7f0f01ba;
        public static int TextAppearance_AppCompat_Widget_Button_Colored = 0x7f0f01bb;
        public static int TextAppearance_AppCompat_Widget_Button_Inverse = 0x7f0f01bc;
        public static int TextAppearance_AppCompat_Widget_DropDownItem = 0x7f0f01bd;
        public static int TextAppearance_AppCompat_Widget_PopupMenu_Header = 0x7f0f01be;
        public static int TextAppearance_AppCompat_Widget_PopupMenu_Large = 0x7f0f01bf;
        public static int TextAppearance_AppCompat_Widget_PopupMenu_Small = 0x7f0f01c0;
        public static int TextAppearance_AppCompat_Widget_Switch = 0x7f0f01c1;
        public static int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 0x7f0f01c2;
        public static int TextAppearance_Compat_Notification = 0x7f0f01c3;
        public static int TextAppearance_Compat_Notification_Info = 0x7f0f01c4;
        public static int TextAppearance_Compat_Notification_Line2 = 0x7f0f01c5;
        public static int TextAppearance_Compat_Notification_Time = 0x7f0f01c6;
        public static int TextAppearance_Compat_Notification_Title = 0x7f0f01c7;
        public static int TextAppearance_Design_CollapsingToolbar_Expanded = 0x7f0f01c8;
        public static int TextAppearance_Design_Counter = 0x7f0f01c9;
        public static int TextAppearance_Design_Counter_Overflow = 0x7f0f01ca;
        public static int TextAppearance_Design_Error = 0x7f0f01cb;
        public static int TextAppearance_Design_HelperText = 0x7f0f01cc;
        public static int TextAppearance_Design_Hint = 0x7f0f01cd;
        public static int TextAppearance_Design_Placeholder = 0x7f0f01ce;
        public static int TextAppearance_Design_Prefix = 0x7f0f01cf;
        public static int TextAppearance_Design_Snackbar_Message = 0x7f0f01d0;
        public static int TextAppearance_Design_Suffix = 0x7f0f01d1;
        public static int TextAppearance_Design_Tab = 0x7f0f01d2;
        public static int TextAppearance_M3_Sys_Typescale_BodyLarge = 0x7f0f01d3;
        public static int TextAppearance_M3_Sys_Typescale_BodyMedium = 0x7f0f01d4;
        public static int TextAppearance_M3_Sys_Typescale_BodySmall = 0x7f0f01d5;
        public static int TextAppearance_M3_Sys_Typescale_DisplayLarge = 0x7f0f01d6;
        public static int TextAppearance_M3_Sys_Typescale_DisplayMedium = 0x7f0f01d7;
        public static int TextAppearance_M3_Sys_Typescale_DisplaySmall = 0x7f0f01d8;
        public static int TextAppearance_M3_Sys_Typescale_HeadlineLarge = 0x7f0f01d9;
        public static int TextAppearance_M3_Sys_Typescale_HeadlineMedium = 0x7f0f01da;
        public static int TextAppearance_M3_Sys_Typescale_HeadlineSmall = 0x7f0f01db;
        public static int TextAppearance_M3_Sys_Typescale_LabelLarge = 0x7f0f01dc;
        public static int TextAppearance_M3_Sys_Typescale_LabelMedium = 0x7f0f01dd;
        public static int TextAppearance_M3_Sys_Typescale_LabelSmall = 0x7f0f01de;
        public static int TextAppearance_M3_Sys_Typescale_TitleLarge = 0x7f0f01df;
        public static int TextAppearance_M3_Sys_Typescale_TitleMedium = 0x7f0f01e0;
        public static int TextAppearance_M3_Sys_Typescale_TitleSmall = 0x7f0f01e1;
        public static int TextAppearance_Material3_ActionBar_Subtitle = 0x7f0f01e2;
        public static int TextAppearance_Material3_ActionBar_Title = 0x7f0f01e3;
        public static int TextAppearance_Material3_BodyLarge = 0x7f0f01e4;
        public static int TextAppearance_Material3_BodyMedium = 0x7f0f01e5;
        public static int TextAppearance_Material3_BodySmall = 0x7f0f01e6;
        public static int TextAppearance_Material3_DisplayLarge = 0x7f0f01e7;
        public static int TextAppearance_Material3_DisplayMedium = 0x7f0f01e8;
        public static int TextAppearance_Material3_DisplaySmall = 0x7f0f01e9;
        public static int TextAppearance_Material3_HeadlineLarge = 0x7f0f01ea;
        public static int TextAppearance_Material3_HeadlineMedium = 0x7f0f01eb;
        public static int TextAppearance_Material3_HeadlineSmall = 0x7f0f01ec;
        public static int TextAppearance_Material3_LabelLarge = 0x7f0f01ed;
        public static int TextAppearance_Material3_LabelMedium = 0x7f0f01ee;
        public static int TextAppearance_Material3_LabelSmall = 0x7f0f01ef;
        public static int TextAppearance_Material3_MaterialTimePicker_Title = 0x7f0f01f0;
        public static int TextAppearance_Material3_SearchBar = 0x7f0f01f1;
        public static int TextAppearance_Material3_SearchView = 0x7f0f01f2;
        public static int TextAppearance_Material3_SearchView_Prefix = 0x7f0f01f3;
        public static int TextAppearance_Material3_TitleLarge = 0x7f0f01f4;
        public static int TextAppearance_Material3_TitleMedium = 0x7f0f01f5;
        public static int TextAppearance_Material3_TitleSmall = 0x7f0f01f6;
        public static int TextAppearance_MaterialComponents_Badge = 0x7f0f01f7;
        public static int TextAppearance_MaterialComponents_Body1 = 0x7f0f01f8;
        public static int TextAppearance_MaterialComponents_Body2 = 0x7f0f01f9;
        public static int TextAppearance_MaterialComponents_Button = 0x7f0f01fa;
        public static int TextAppearance_MaterialComponents_Caption = 0x7f0f01fb;
        public static int TextAppearance_MaterialComponents_Chip = 0x7f0f01fc;
        public static int TextAppearance_MaterialComponents_Headline1 = 0x7f0f01fd;
        public static int TextAppearance_MaterialComponents_Headline2 = 0x7f0f01fe;
        public static int TextAppearance_MaterialComponents_Headline3 = 0x7f0f01ff;
        public static int TextAppearance_MaterialComponents_Headline4 = 0x7f0f0200;
        public static int TextAppearance_MaterialComponents_Headline5 = 0x7f0f0201;
        public static int TextAppearance_MaterialComponents_Headline6 = 0x7f0f0202;
        public static int TextAppearance_MaterialComponents_Overline = 0x7f0f0203;
        public static int TextAppearance_MaterialComponents_Subtitle1 = 0x7f0f0204;
        public static int TextAppearance_MaterialComponents_Subtitle2 = 0x7f0f0205;
        public static int TextAppearance_MaterialComponents_TimePicker_Title = 0x7f0f0206;
        public static int TextAppearance_MaterialComponents_Tooltip = 0x7f0f0207;
        public static int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 0x7f0f0208;
        public static int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 0x7f0f0209;
        public static int TextAppearance_Widget_AppCompat_Toolbar_Title = 0x7f0f020a;
        public static int ThemeOverlay_AppCompat = 0x7f0f0274;
        public static int ThemeOverlay_AppCompat_ActionBar = 0x7f0f0275;
        public static int ThemeOverlay_AppCompat_Dark = 0x7f0f0276;
        public static int ThemeOverlay_AppCompat_Dark_ActionBar = 0x7f0f0277;
        public static int ThemeOverlay_AppCompat_DayNight = 0x7f0f0278;
        public static int ThemeOverlay_AppCompat_DayNight_ActionBar = 0x7f0f0279;
        public static int ThemeOverlay_AppCompat_Dialog = 0x7f0f027a;
        public static int ThemeOverlay_AppCompat_Dialog_Alert = 0x7f0f027b;
        public static int ThemeOverlay_AppCompat_Light = 0x7f0f027c;
        public static int ThemeOverlay_Design_TextInputEditText = 0x7f0f027d;
        public static int ThemeOverlay_Material3 = 0x7f0f027e;
        public static int ThemeOverlay_Material3_ActionBar = 0x7f0f027f;
        public static int ThemeOverlay_Material3_AutoCompleteTextView = 0x7f0f0280;
        public static int ThemeOverlay_Material3_AutoCompleteTextView_FilledBox = 0x7f0f0281;
        public static int ThemeOverlay_Material3_AutoCompleteTextView_FilledBox_Dense = 0x7f0f0282;
        public static int ThemeOverlay_Material3_AutoCompleteTextView_OutlinedBox = 0x7f0f0283;
        public static int ThemeOverlay_Material3_AutoCompleteTextView_OutlinedBox_Dense = 0x7f0f0284;
        public static int ThemeOverlay_Material3_BottomAppBar = 0x7f0f0285;
        public static int ThemeOverlay_Material3_BottomAppBar_Legacy = 0x7f0f0286;
        public static int ThemeOverlay_Material3_BottomNavigationView = 0x7f0f0287;
        public static int ThemeOverlay_Material3_BottomSheetDialog = 0x7f0f0288;
        public static int ThemeOverlay_Material3_Button = 0x7f0f0289;
        public static int ThemeOverlay_Material3_Button_ElevatedButton = 0x7f0f028a;
        public static int ThemeOverlay_Material3_Button_IconButton = 0x7f0f028b;
        public static int ThemeOverlay_Material3_Button_IconButton_Filled = 0x7f0f028c;
        public static int ThemeOverlay_Material3_Button_IconButton_Filled_Tonal = 0x7f0f028d;
        public static int ThemeOverlay_Material3_Button_TextButton = 0x7f0f028e;
        public static int ThemeOverlay_Material3_Button_TextButton_Snackbar = 0x7f0f028f;
        public static int ThemeOverlay_Material3_Button_TonalButton = 0x7f0f0290;
        public static int ThemeOverlay_Material3_Chip = 0x7f0f0291;
        public static int ThemeOverlay_Material3_Chip_Assist = 0x7f0f0292;
        public static int ThemeOverlay_Material3_Dark = 0x7f0f0293;
        public static int ThemeOverlay_Material3_Dark_ActionBar = 0x7f0f0294;
        public static int ThemeOverlay_Material3_DayNight_BottomSheetDialog = 0x7f0f0295;
        public static int ThemeOverlay_Material3_DayNight_SideSheetDialog = 0x7f0f0296;
        public static int ThemeOverlay_Material3_Dialog = 0x7f0f0297;
        public static int ThemeOverlay_Material3_Dialog_Alert = 0x7f0f0298;
        public static int ThemeOverlay_Material3_Dialog_Alert_Framework = 0x7f0f0299;
        public static int ThemeOverlay_Material3_DynamicColors_Dark = 0x7f0f029a;
        public static int ThemeOverlay_Material3_DynamicColors_DayNight = 0x7f0f029b;
        public static int ThemeOverlay_Material3_DynamicColors_Light = 0x7f0f029c;
        public static int ThemeOverlay_Material3_ExtendedFloatingActionButton_Primary = 0x7f0f029d;
        public static int ThemeOverlay_Material3_ExtendedFloatingActionButton_Secondary = 0x7f0f029e;
        public static int ThemeOverlay_Material3_ExtendedFloatingActionButton_Surface = 0x7f0f029f;
        public static int ThemeOverlay_Material3_ExtendedFloatingActionButton_Tertiary = 0x7f0f02a0;
        public static int ThemeOverlay_Material3_FloatingActionButton_Primary = 0x7f0f02a1;
        public static int ThemeOverlay_Material3_FloatingActionButton_Secondary = 0x7f0f02a2;
        public static int ThemeOverlay_Material3_FloatingActionButton_Surface = 0x7f0f02a3;
        public static int ThemeOverlay_Material3_FloatingActionButton_Tertiary = 0x7f0f02a4;
        public static int ThemeOverlay_Material3_HarmonizedColors = 0x7f0f02a5;
        public static int ThemeOverlay_Material3_HarmonizedColors_Empty = 0x7f0f02a6;
        public static int ThemeOverlay_Material3_Light = 0x7f0f02a7;
        public static int ThemeOverlay_Material3_Light_Dialog_Alert_Framework = 0x7f0f02a8;
        public static int ThemeOverlay_Material3_MaterialAlertDialog = 0x7f0f02a9;
        public static int ThemeOverlay_Material3_MaterialAlertDialog_Centered = 0x7f0f02aa;
        public static int ThemeOverlay_Material3_MaterialCalendar = 0x7f0f02ab;
        public static int ThemeOverlay_Material3_MaterialCalendar_Fullscreen = 0x7f0f02ac;
        public static int ThemeOverlay_Material3_MaterialCalendar_HeaderCancelButton = 0x7f0f02ad;
        public static int ThemeOverlay_Material3_MaterialTimePicker = 0x7f0f02ae;
        public static int ThemeOverlay_Material3_MaterialTimePicker_Display_TextInputEditText = 0x7f0f02af;
        public static int ThemeOverlay_Material3_NavigationRailView = 0x7f0f02b0;
        public static int ThemeOverlay_Material3_NavigationView = 0x7f0f02b1;
        public static int ThemeOverlay_Material3_PersonalizedColors = 0x7f0f02b2;
        public static int ThemeOverlay_Material3_Search = 0x7f0f02b3;
        public static int ThemeOverlay_Material3_SideSheetDialog = 0x7f0f02b4;
        public static int ThemeOverlay_Material3_Snackbar = 0x7f0f02b5;
        public static int ThemeOverlay_Material3_TabLayout = 0x7f0f02b6;
        public static int ThemeOverlay_Material3_TextInputEditText = 0x7f0f02b7;
        public static int ThemeOverlay_Material3_TextInputEditText_FilledBox = 0x7f0f02b8;
        public static int ThemeOverlay_Material3_TextInputEditText_FilledBox_Dense = 0x7f0f02b9;
        public static int ThemeOverlay_Material3_TextInputEditText_OutlinedBox = 0x7f0f02ba;
        public static int ThemeOverlay_Material3_TextInputEditText_OutlinedBox_Dense = 0x7f0f02bb;
        public static int ThemeOverlay_Material3_Toolbar_Surface = 0x7f0f02bc;
        public static int ThemeOverlay_MaterialAlertDialog_Material3_Title_Icon = 0x7f0f02bd;
        public static int ThemeOverlay_MaterialComponents = 0x7f0f02be;
        public static int ThemeOverlay_MaterialComponents_ActionBar = 0x7f0f02bf;
        public static int ThemeOverlay_MaterialComponents_ActionBar_Primary = 0x7f0f02c0;
        public static int ThemeOverlay_MaterialComponents_ActionBar_Surface = 0x7f0f02c1;
        public static int ThemeOverlay_MaterialComponents_AutoCompleteTextView = 0x7f0f02c2;
        public static int ThemeOverlay_MaterialComponents_AutoCompleteTextView_FilledBox = 0x7f0f02c3;
        public static int ThemeOverlay_MaterialComponents_AutoCompleteTextView_FilledBox_Dense = 0x7f0f02c4;
        public static int ThemeOverlay_MaterialComponents_AutoCompleteTextView_OutlinedBox = 0x7f0f02c5;
        public static int ThemeOverlay_MaterialComponents_AutoCompleteTextView_OutlinedBox_Dense = 0x7f0f02c6;
        public static int ThemeOverlay_MaterialComponents_BottomAppBar_Primary = 0x7f0f02c7;
        public static int ThemeOverlay_MaterialComponents_BottomAppBar_Surface = 0x7f0f02c8;
        public static int ThemeOverlay_MaterialComponents_BottomSheetDialog = 0x7f0f02c9;
        public static int ThemeOverlay_MaterialComponents_Dark = 0x7f0f02ca;
        public static int ThemeOverlay_MaterialComponents_Dark_ActionBar = 0x7f0f02cb;
        public static int ThemeOverlay_MaterialComponents_DayNight_BottomSheetDialog = 0x7f0f02cc;
        public static int ThemeOverlay_MaterialComponents_Dialog = 0x7f0f02cd;
        public static int ThemeOverlay_MaterialComponents_Dialog_Alert = 0x7f0f02ce;
        public static int ThemeOverlay_MaterialComponents_Dialog_Alert_Framework = 0x7f0f02cf;
        public static int ThemeOverlay_MaterialComponents_Light = 0x7f0f02d0;
        public static int ThemeOverlay_MaterialComponents_Light_Dialog_Alert_Framework = 0x7f0f02d1;
        public static int ThemeOverlay_MaterialComponents_MaterialAlertDialog = 0x7f0f02d2;
        public static int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Centered = 0x7f0f02d3;
        public static int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date = 0x7f0f02d4;
        public static int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Calendar = 0x7f0f02d5;
        public static int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Header_Text = 0x7f0f02d6;
        public static int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Header_Text_Day = 0x7f0f02d7;
        public static int ThemeOverlay_MaterialComponents_MaterialAlertDialog_Picker_Date_Spinner = 0x7f0f02d8;
        public static int ThemeOverlay_MaterialComponents_MaterialCalendar = 0x7f0f02d9;
        public static int ThemeOverlay_MaterialComponents_MaterialCalendar_Fullscreen = 0x7f0f02da;
        public static int ThemeOverlay_MaterialComponents_TextInputEditText = 0x7f0f02db;
        public static int ThemeOverlay_MaterialComponents_TextInputEditText_FilledBox = 0x7f0f02dc;
        public static int ThemeOverlay_MaterialComponents_TextInputEditText_FilledBox_Dense = 0x7f0f02dd;
        public static int ThemeOverlay_MaterialComponents_TextInputEditText_OutlinedBox = 0x7f0f02de;
        public static int ThemeOverlay_MaterialComponents_TextInputEditText_OutlinedBox_Dense = 0x7f0f02df;
        public static int ThemeOverlay_MaterialComponents_TimePicker = 0x7f0f02e0;
        public static int ThemeOverlay_MaterialComponents_TimePicker_Display = 0x7f0f02e1;
        public static int ThemeOverlay_MaterialComponents_TimePicker_Display_TextInputEditText = 0x7f0f02e2;
        public static int ThemeOverlay_MaterialComponents_Toolbar_Popup_Primary = 0x7f0f02e3;
        public static int ThemeOverlay_MaterialComponents_Toolbar_Primary = 0x7f0f02e4;
        public static int ThemeOverlay_MaterialComponents_Toolbar_Surface = 0x7f0f02e5;
        public static int Theme_AppCompat = 0x7f0f020b;
        public static int Theme_AppCompat_CompactMenu = 0x7f0f020c;
        public static int Theme_AppCompat_DayNight = 0x7f0f020d;
        public static int Theme_AppCompat_DayNight_DarkActionBar = 0x7f0f020e;
        public static int Theme_AppCompat_DayNight_Dialog = 0x7f0f020f;
        public static int Theme_AppCompat_DayNight_DialogWhenLarge = 0x7f0f0212;
        public static int Theme_AppCompat_DayNight_Dialog_Alert = 0x7f0f0210;
        public static int Theme_AppCompat_DayNight_Dialog_MinWidth = 0x7f0f0211;
        public static int Theme_AppCompat_DayNight_NoActionBar = 0x7f0f0213;
        public static int Theme_AppCompat_Dialog = 0x7f0f0214;
        public static int Theme_AppCompat_DialogWhenLarge = 0x7f0f0217;
        public static int Theme_AppCompat_Dialog_Alert = 0x7f0f0215;
        public static int Theme_AppCompat_Dialog_MinWidth = 0x7f0f0216;
        public static int Theme_AppCompat_Empty = 0x7f0f0218;
        public static int Theme_AppCompat_Light = 0x7f0f0219;
        public static int Theme_AppCompat_Light_DarkActionBar = 0x7f0f021a;
        public static int Theme_AppCompat_Light_Dialog = 0x7f0f021b;
        public static int Theme_AppCompat_Light_DialogWhenLarge = 0x7f0f021e;
        public static int Theme_AppCompat_Light_Dialog_Alert = 0x7f0f021c;
        public static int Theme_AppCompat_Light_Dialog_MinWidth = 0x7f0f021d;
        public static int Theme_AppCompat_Light_NoActionBar = 0x7f0f021f;
        public static int Theme_AppCompat_NoActionBar = 0x7f0f0220;
        public static int Theme_Design = 0x7f0f0221;
        public static int Theme_Design_BottomSheetDialog = 0x7f0f0222;
        public static int Theme_Design_Light = 0x7f0f0223;
        public static int Theme_Design_Light_BottomSheetDialog = 0x7f0f0224;
        public static int Theme_Design_Light_NoActionBar = 0x7f0f0225;
        public static int Theme_Design_NoActionBar = 0x7f0f0226;
        public static int Theme_Material3_Dark = 0x7f0f0227;
        public static int Theme_Material3_Dark_BottomSheetDialog = 0x7f0f0228;
        public static int Theme_Material3_Dark_Dialog = 0x7f0f0229;
        public static int Theme_Material3_Dark_DialogWhenLarge = 0x7f0f022c;
        public static int Theme_Material3_Dark_Dialog_Alert = 0x7f0f022a;
        public static int Theme_Material3_Dark_Dialog_MinWidth = 0x7f0f022b;
        public static int Theme_Material3_Dark_NoActionBar = 0x7f0f022d;
        public static int Theme_Material3_Dark_SideSheetDialog = 0x7f0f022e;
        public static int Theme_Material3_DayNight = 0x7f0f022f;
        public static int Theme_Material3_DayNight_BottomSheetDialog = 0x7f0f0230;
        public static int Theme_Material3_DayNight_Dialog = 0x7f0f0231;
        public static int Theme_Material3_DayNight_DialogWhenLarge = 0x7f0f0234;
        public static int Theme_Material3_DayNight_Dialog_Alert = 0x7f0f0232;
        public static int Theme_Material3_DayNight_Dialog_MinWidth = 0x7f0f0233;
        public static int Theme_Material3_DayNight_NoActionBar = 0x7f0f0235;
        public static int Theme_Material3_DayNight_SideSheetDialog = 0x7f0f0236;
        public static int Theme_Material3_DynamicColors_Dark = 0x7f0f0237;
        public static int Theme_Material3_DynamicColors_Dark_NoActionBar = 0x7f0f0238;
        public static int Theme_Material3_DynamicColors_DayNight = 0x7f0f0239;
        public static int Theme_Material3_DynamicColors_DayNight_NoActionBar = 0x7f0f023a;
        public static int Theme_Material3_DynamicColors_Light = 0x7f0f023b;
        public static int Theme_Material3_DynamicColors_Light_NoActionBar = 0x7f0f023c;
        public static int Theme_Material3_Light = 0x7f0f023d;
        public static int Theme_Material3_Light_BottomSheetDialog = 0x7f0f023e;
        public static int Theme_Material3_Light_Dialog = 0x7f0f023f;
        public static int Theme_Material3_Light_DialogWhenLarge = 0x7f0f0242;
        public static int Theme_Material3_Light_Dialog_Alert = 0x7f0f0240;
        public static int Theme_Material3_Light_Dialog_MinWidth = 0x7f0f0241;
        public static int Theme_Material3_Light_NoActionBar = 0x7f0f0243;
        public static int Theme_Material3_Light_SideSheetDialog = 0x7f0f0244;
        public static int Theme_MaterialComponents = 0x7f0f0245;
        public static int Theme_MaterialComponents_BottomSheetDialog = 0x7f0f0246;
        public static int Theme_MaterialComponents_Bridge = 0x7f0f0247;
        public static int Theme_MaterialComponents_CompactMenu = 0x7f0f0248;
        public static int Theme_MaterialComponents_DayNight = 0x7f0f0249;
        public static int Theme_MaterialComponents_DayNight_BottomSheetDialog = 0x7f0f024a;
        public static int Theme_MaterialComponents_DayNight_Bridge = 0x7f0f024b;
        public static int Theme_MaterialComponents_DayNight_DarkActionBar = 0x7f0f024c;
        public static int Theme_MaterialComponents_DayNight_DarkActionBar_Bridge = 0x7f0f024d;
        public static int Theme_MaterialComponents_DayNight_Dialog = 0x7f0f024e;
        public static int Theme_MaterialComponents_DayNight_DialogWhenLarge = 0x7f0f0256;
        public static int Theme_MaterialComponents_DayNight_Dialog_Alert = 0x7f0f024f;
        public static int Theme_MaterialComponents_DayNight_Dialog_Alert_Bridge = 0x7f0f0250;
        public static int Theme_MaterialComponents_DayNight_Dialog_Bridge = 0x7f0f0251;
        public static int Theme_MaterialComponents_DayNight_Dialog_FixedSize = 0x7f0f0252;
        public static int Theme_MaterialComponents_DayNight_Dialog_FixedSize_Bridge = 0x7f0f0253;
        public static int Theme_MaterialComponents_DayNight_Dialog_MinWidth = 0x7f0f0254;
        public static int Theme_MaterialComponents_DayNight_Dialog_MinWidth_Bridge = 0x7f0f0255;
        public static int Theme_MaterialComponents_DayNight_NoActionBar = 0x7f0f0257;
        public static int Theme_MaterialComponents_DayNight_NoActionBar_Bridge = 0x7f0f0258;
        public static int Theme_MaterialComponents_Dialog = 0x7f0f0259;
        public static int Theme_MaterialComponents_DialogWhenLarge = 0x7f0f0261;
        public static int Theme_MaterialComponents_Dialog_Alert = 0x7f0f025a;
        public static int Theme_MaterialComponents_Dialog_Alert_Bridge = 0x7f0f025b;
        public static int Theme_MaterialComponents_Dialog_Bridge = 0x7f0f025c;
        public static int Theme_MaterialComponents_Dialog_FixedSize = 0x7f0f025d;
        public static int Theme_MaterialComponents_Dialog_FixedSize_Bridge = 0x7f0f025e;
        public static int Theme_MaterialComponents_Dialog_MinWidth = 0x7f0f025f;
        public static int Theme_MaterialComponents_Dialog_MinWidth_Bridge = 0x7f0f0260;
        public static int Theme_MaterialComponents_Light = 0x7f0f0262;
        public static int Theme_MaterialComponents_Light_BottomSheetDialog = 0x7f0f0263;
        public static int Theme_MaterialComponents_Light_Bridge = 0x7f0f0264;
        public static int Theme_MaterialComponents_Light_DarkActionBar = 0x7f0f0265;
        public static int Theme_MaterialComponents_Light_DarkActionBar_Bridge = 0x7f0f0266;
        public static int Theme_MaterialComponents_Light_Dialog = 0x7f0f0267;
        public static int Theme_MaterialComponents_Light_DialogWhenLarge = 0x7f0f026f;
        public static int Theme_MaterialComponents_Light_Dialog_Alert = 0x7f0f0268;
        public static int Theme_MaterialComponents_Light_Dialog_Alert_Bridge = 0x7f0f0269;
        public static int Theme_MaterialComponents_Light_Dialog_Bridge = 0x7f0f026a;
        public static int Theme_MaterialComponents_Light_Dialog_FixedSize = 0x7f0f026b;
        public static int Theme_MaterialComponents_Light_Dialog_FixedSize_Bridge = 0x7f0f026c;
        public static int Theme_MaterialComponents_Light_Dialog_MinWidth = 0x7f0f026d;
        public static int Theme_MaterialComponents_Light_Dialog_MinWidth_Bridge = 0x7f0f026e;
        public static int Theme_MaterialComponents_Light_NoActionBar = 0x7f0f0270;
        public static int Theme_MaterialComponents_Light_NoActionBar_Bridge = 0x7f0f0271;
        public static int Theme_MaterialComponents_NoActionBar = 0x7f0f0272;
        public static int Theme_MaterialComponents_NoActionBar_Bridge = 0x7f0f0273;
        public static int Widget_AppCompat_ActionBar = 0x7f0f02e6;
        public static int Widget_AppCompat_ActionBar_Solid = 0x7f0f02e7;
        public static int Widget_AppCompat_ActionBar_TabBar = 0x7f0f02e8;
        public static int Widget_AppCompat_ActionBar_TabText = 0x7f0f02e9;
        public static int Widget_AppCompat_ActionBar_TabView = 0x7f0f02ea;
        public static int Widget_AppCompat_ActionButton = 0x7f0f02eb;
        public static int Widget_AppCompat_ActionButton_CloseMode = 0x7f0f02ec;
        public static int Widget_AppCompat_ActionButton_Overflow = 0x7f0f02ed;
        public static int Widget_AppCompat_ActionMode = 0x7f0f02ee;
        public static int Widget_AppCompat_ActivityChooserView = 0x7f0f02ef;
        public static int Widget_AppCompat_AutoCompleteTextView = 0x7f0f02f0;
        public static int Widget_AppCompat_Button = 0x7f0f02f1;
        public static int Widget_AppCompat_ButtonBar = 0x7f0f02f7;
        public static int Widget_AppCompat_ButtonBar_AlertDialog = 0x7f0f02f8;
        public static int Widget_AppCompat_Button_Borderless = 0x7f0f02f2;
        public static int Widget_AppCompat_Button_Borderless_Colored = 0x7f0f02f3;
        public static int Widget_AppCompat_Button_ButtonBar_AlertDialog = 0x7f0f02f4;
        public static int Widget_AppCompat_Button_Colored = 0x7f0f02f5;
        public static int Widget_AppCompat_Button_Small = 0x7f0f02f6;
        public static int Widget_AppCompat_CompoundButton_CheckBox = 0x7f0f02f9;
        public static int Widget_AppCompat_CompoundButton_RadioButton = 0x7f0f02fa;
        public static int Widget_AppCompat_CompoundButton_Switch = 0x7f0f02fb;
        public static int Widget_AppCompat_DrawerArrowToggle = 0x7f0f02fc;
        public static int Widget_AppCompat_DropDownItem_Spinner = 0x7f0f02fd;
        public static int Widget_AppCompat_EditText = 0x7f0f02fe;
        public static int Widget_AppCompat_ImageButton = 0x7f0f02ff;
        public static int Widget_AppCompat_Light_ActionBar = 0x7f0f0300;
        public static int Widget_AppCompat_Light_ActionBar_Solid = 0x7f0f0301;
        public static int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 0x7f0f0302;
        public static int Widget_AppCompat_Light_ActionBar_TabBar = 0x7f0f0303;
        public static int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 0x7f0f0304;
        public static int Widget_AppCompat_Light_ActionBar_TabText = 0x7f0f0305;
        public static int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 0x7f0f0306;
        public static int Widget_AppCompat_Light_ActionBar_TabView = 0x7f0f0307;
        public static int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 0x7f0f0308;
        public static int Widget_AppCompat_Light_ActionButton = 0x7f0f0309;
        public static int Widget_AppCompat_Light_ActionButton_CloseMode = 0x7f0f030a;
        public static int Widget_AppCompat_Light_ActionButton_Overflow = 0x7f0f030b;
        public static int Widget_AppCompat_Light_ActionMode_Inverse = 0x7f0f030c;
        public static int Widget_AppCompat_Light_ActivityChooserView = 0x7f0f030d;
        public static int Widget_AppCompat_Light_AutoCompleteTextView = 0x7f0f030e;
        public static int Widget_AppCompat_Light_DropDownItem_Spinner = 0x7f0f030f;
        public static int Widget_AppCompat_Light_ListPopupWindow = 0x7f0f0310;
        public static int Widget_AppCompat_Light_ListView_DropDown = 0x7f0f0311;
        public static int Widget_AppCompat_Light_PopupMenu = 0x7f0f0312;
        public static int Widget_AppCompat_Light_PopupMenu_Overflow = 0x7f0f0313;
        public static int Widget_AppCompat_Light_SearchView = 0x7f0f0314;
        public static int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 0x7f0f0315;
        public static int Widget_AppCompat_ListMenuView = 0x7f0f0316;
        public static int Widget_AppCompat_ListPopupWindow = 0x7f0f0317;
        public static int Widget_AppCompat_ListView = 0x7f0f0318;
        public static int Widget_AppCompat_ListView_DropDown = 0x7f0f0319;
        public static int Widget_AppCompat_ListView_Menu = 0x7f0f031a;
        public static int Widget_AppCompat_PopupMenu = 0x7f0f031b;
        public static int Widget_AppCompat_PopupMenu_Overflow = 0x7f0f031c;
        public static int Widget_AppCompat_PopupWindow = 0x7f0f031d;
        public static int Widget_AppCompat_ProgressBar = 0x7f0f031e;
        public static int Widget_AppCompat_ProgressBar_Horizontal = 0x7f0f031f;
        public static int Widget_AppCompat_RatingBar = 0x7f0f0320;
        public static int Widget_AppCompat_RatingBar_Indicator = 0x7f0f0321;
        public static int Widget_AppCompat_RatingBar_Small = 0x7f0f0322;
        public static int Widget_AppCompat_SearchView = 0x7f0f0323;
        public static int Widget_AppCompat_SearchView_ActionBar = 0x7f0f0324;
        public static int Widget_AppCompat_SeekBar = 0x7f0f0325;
        public static int Widget_AppCompat_SeekBar_Discrete = 0x7f0f0326;
        public static int Widget_AppCompat_Spinner = 0x7f0f0327;
        public static int Widget_AppCompat_Spinner_DropDown = 0x7f0f0328;
        public static int Widget_AppCompat_Spinner_DropDown_ActionBar = 0x7f0f0329;
        public static int Widget_AppCompat_Spinner_Underlined = 0x7f0f032a;
        public static int Widget_AppCompat_TextView = 0x7f0f032b;
        public static int Widget_AppCompat_TextView_SpinnerItem = 0x7f0f032c;
        public static int Widget_AppCompat_Toolbar = 0x7f0f032d;
        public static int Widget_AppCompat_Toolbar_Button_Navigation = 0x7f0f032e;
        public static int Widget_Compat_NotificationActionContainer = 0x7f0f032f;
        public static int Widget_Compat_NotificationActionText = 0x7f0f0330;
        public static int Widget_Design_AppBarLayout = 0x7f0f0331;
        public static int Widget_Design_BottomNavigationView = 0x7f0f0332;
        public static int Widget_Design_BottomSheet_Modal = 0x7f0f0333;
        public static int Widget_Design_CollapsingToolbar = 0x7f0f0334;
        public static int Widget_Design_FloatingActionButton = 0x7f0f0335;
        public static int Widget_Design_NavigationView = 0x7f0f0336;
        public static int Widget_Design_ScrimInsetsFrameLayout = 0x7f0f0337;
        public static int Widget_Design_Snackbar = 0x7f0f0338;
        public static int Widget_Design_TabLayout = 0x7f0f0339;
        public static int Widget_Design_TextInputEditText = 0x7f0f033a;
        public static int Widget_Design_TextInputLayout = 0x7f0f033b;
        public static int Widget_Material3_ActionBar_Solid = 0x7f0f033c;
        public static int Widget_Material3_ActionMode = 0x7f0f033d;
        public static int Widget_Material3_AppBarLayout = 0x7f0f033e;
        public static int Widget_Material3_AutoCompleteTextView_FilledBox = 0x7f0f033f;
        public static int Widget_Material3_AutoCompleteTextView_FilledBox_Dense = 0x7f0f0340;
        public static int Widget_Material3_AutoCompleteTextView_OutlinedBox = 0x7f0f0341;
        public static int Widget_Material3_AutoCompleteTextView_OutlinedBox_Dense = 0x7f0f0342;
        public static int Widget_Material3_Badge = 0x7f0f0343;
        public static int Widget_Material3_Badge_AdjustToBounds = 0x7f0f0344;
        public static int Widget_Material3_BottomAppBar = 0x7f0f0345;
        public static int Widget_Material3_BottomAppBar_Button_Navigation = 0x7f0f0346;
        public static int Widget_Material3_BottomAppBar_Legacy = 0x7f0f0347;
        public static int Widget_Material3_BottomNavigationView = 0x7f0f0349;
        public static int Widget_Material3_BottomNavigationView_ActiveIndicator = 0x7f0f034a;
        public static int Widget_Material3_BottomNavigation_Badge = 0x7f0f0348;
        public static int Widget_Material3_BottomSheet = 0x7f0f034b;
        public static int Widget_Material3_BottomSheet_DragHandle = 0x7f0f034c;
        public static int Widget_Material3_BottomSheet_Modal = 0x7f0f034d;
        public static int Widget_Material3_Button = 0x7f0f034e;
        public static int Widget_Material3_Button_ElevatedButton = 0x7f0f034f;
        public static int Widget_Material3_Button_ElevatedButton_Icon = 0x7f0f0350;
        public static int Widget_Material3_Button_Icon = 0x7f0f0351;
        public static int Widget_Material3_Button_IconButton = 0x7f0f0352;
        public static int Widget_Material3_Button_IconButton_Filled = 0x7f0f0353;
        public static int Widget_Material3_Button_IconButton_Filled_Tonal = 0x7f0f0354;
        public static int Widget_Material3_Button_IconButton_Outlined = 0x7f0f0355;
        public static int Widget_Material3_Button_OutlinedButton = 0x7f0f0356;
        public static int Widget_Material3_Button_OutlinedButton_Icon = 0x7f0f0357;
        public static int Widget_Material3_Button_TextButton = 0x7f0f0358;
        public static int Widget_Material3_Button_TextButton_Dialog = 0x7f0f0359;
        public static int Widget_Material3_Button_TextButton_Dialog_Flush = 0x7f0f035a;
        public static int Widget_Material3_Button_TextButton_Dialog_Icon = 0x7f0f035b;
        public static int Widget_Material3_Button_TextButton_Icon = 0x7f0f035c;
        public static int Widget_Material3_Button_TextButton_Snackbar = 0x7f0f035d;
        public static int Widget_Material3_Button_TonalButton = 0x7f0f035e;
        public static int Widget_Material3_Button_TonalButton_Icon = 0x7f0f035f;
        public static int Widget_Material3_Button_UnelevatedButton = 0x7f0f0360;
        public static int Widget_Material3_CardView_Elevated = 0x7f0f0361;
        public static int Widget_Material3_CardView_Filled = 0x7f0f0362;
        public static int Widget_Material3_CardView_Outlined = 0x7f0f0363;
        public static int Widget_Material3_CheckedTextView = 0x7f0f0364;
        public static int Widget_Material3_ChipGroup = 0x7f0f036f;
        public static int Widget_Material3_Chip_Assist = 0x7f0f0365;
        public static int Widget_Material3_Chip_Assist_Elevated = 0x7f0f0366;
        public static int Widget_Material3_Chip_Filter = 0x7f0f0367;
        public static int Widget_Material3_Chip_Filter_Elevated = 0x7f0f0368;
        public static int Widget_Material3_Chip_Input = 0x7f0f0369;
        public static int Widget_Material3_Chip_Input_Elevated = 0x7f0f036a;
        public static int Widget_Material3_Chip_Input_Icon = 0x7f0f036b;
        public static int Widget_Material3_Chip_Input_Icon_Elevated = 0x7f0f036c;
        public static int Widget_Material3_Chip_Suggestion = 0x7f0f036d;
        public static int Widget_Material3_Chip_Suggestion_Elevated = 0x7f0f036e;
        public static int Widget_Material3_CircularProgressIndicator = 0x7f0f0370;
        public static int Widget_Material3_CircularProgressIndicator_ExtraSmall = 0x7f0f0371;
        public static int Widget_Material3_CircularProgressIndicator_Legacy = 0x7f0f0372;
        public static int Widget_Material3_CircularProgressIndicator_Legacy_ExtraSmall = 0x7f0f0373;
        public static int Widget_Material3_CircularProgressIndicator_Legacy_Medium = 0x7f0f0374;
        public static int Widget_Material3_CircularProgressIndicator_Legacy_Small = 0x7f0f0375;
        public static int Widget_Material3_CircularProgressIndicator_Medium = 0x7f0f0376;
        public static int Widget_Material3_CircularProgressIndicator_Small = 0x7f0f0377;
        public static int Widget_Material3_CollapsingToolbar = 0x7f0f0378;
        public static int Widget_Material3_CollapsingToolbar_Large = 0x7f0f0379;
        public static int Widget_Material3_CollapsingToolbar_Medium = 0x7f0f037a;
        public static int Widget_Material3_CompoundButton_CheckBox = 0x7f0f037b;
        public static int Widget_Material3_CompoundButton_MaterialSwitch = 0x7f0f037c;
        public static int Widget_Material3_CompoundButton_RadioButton = 0x7f0f037d;
        public static int Widget_Material3_CompoundButton_Switch = 0x7f0f037e;
        public static int Widget_Material3_DrawerLayout = 0x7f0f037f;
        public static int Widget_Material3_ExtendedFloatingActionButton_Icon_Primary = 0x7f0f0380;
        public static int Widget_Material3_ExtendedFloatingActionButton_Icon_Secondary = 0x7f0f0381;
        public static int Widget_Material3_ExtendedFloatingActionButton_Icon_Surface = 0x7f0f0382;
        public static int Widget_Material3_ExtendedFloatingActionButton_Icon_Tertiary = 0x7f0f0383;
        public static int Widget_Material3_ExtendedFloatingActionButton_Primary = 0x7f0f0384;
        public static int Widget_Material3_ExtendedFloatingActionButton_Secondary = 0x7f0f0385;
        public static int Widget_Material3_ExtendedFloatingActionButton_Surface = 0x7f0f0386;
        public static int Widget_Material3_ExtendedFloatingActionButton_Tertiary = 0x7f0f0387;
        public static int Widget_Material3_FloatingActionButton_Large_Primary = 0x7f0f0388;
        public static int Widget_Material3_FloatingActionButton_Large_Secondary = 0x7f0f0389;
        public static int Widget_Material3_FloatingActionButton_Large_Surface = 0x7f0f038a;
        public static int Widget_Material3_FloatingActionButton_Large_Tertiary = 0x7f0f038b;
        public static int Widget_Material3_FloatingActionButton_Primary = 0x7f0f038c;
        public static int Widget_Material3_FloatingActionButton_Secondary = 0x7f0f038d;
        public static int Widget_Material3_FloatingActionButton_Small_Primary = 0x7f0f038e;
        public static int Widget_Material3_FloatingActionButton_Small_Secondary = 0x7f0f038f;
        public static int Widget_Material3_FloatingActionButton_Small_Surface = 0x7f0f0390;
        public static int Widget_Material3_FloatingActionButton_Small_Tertiary = 0x7f0f0391;
        public static int Widget_Material3_FloatingActionButton_Surface = 0x7f0f0392;
        public static int Widget_Material3_FloatingActionButton_Tertiary = 0x7f0f0393;
        public static int Widget_Material3_Light_ActionBar_Solid = 0x7f0f0394;
        public static int Widget_Material3_LinearProgressIndicator = 0x7f0f0395;
        public static int Widget_Material3_LinearProgressIndicator_Legacy = 0x7f0f0396;
        public static int Widget_Material3_MaterialButtonToggleGroup = 0x7f0f0397;
        public static int Widget_Material3_MaterialCalendar = 0x7f0f0398;
        public static int Widget_Material3_MaterialCalendar_Day = 0x7f0f0399;
        public static int Widget_Material3_MaterialCalendar_DayOfWeekLabel = 0x7f0f039d;
        public static int Widget_Material3_MaterialCalendar_DayTextView = 0x7f0f039e;
        public static int Widget_Material3_MaterialCalendar_Day_Invalid = 0x7f0f039a;
        public static int Widget_Material3_MaterialCalendar_Day_Selected = 0x7f0f039b;
        public static int Widget_Material3_MaterialCalendar_Day_Today = 0x7f0f039c;
        public static int Widget_Material3_MaterialCalendar_Fullscreen = 0x7f0f039f;
        public static int Widget_Material3_MaterialCalendar_HeaderCancelButton = 0x7f0f03a0;
        public static int Widget_Material3_MaterialCalendar_HeaderDivider = 0x7f0f03a1;
        public static int Widget_Material3_MaterialCalendar_HeaderLayout = 0x7f0f03a2;
        public static int Widget_Material3_MaterialCalendar_HeaderLayout_Fullscreen = 0x7f0f03a3;
        public static int Widget_Material3_MaterialCalendar_HeaderSelection = 0x7f0f03a4;
        public static int Widget_Material3_MaterialCalendar_HeaderSelection_Fullscreen = 0x7f0f03a5;
        public static int Widget_Material3_MaterialCalendar_HeaderTitle = 0x7f0f03a6;
        public static int Widget_Material3_MaterialCalendar_HeaderToggleButton = 0x7f0f03a7;
        public static int Widget_Material3_MaterialCalendar_Item = 0x7f0f03a8;
        public static int Widget_Material3_MaterialCalendar_MonthNavigationButton = 0x7f0f03a9;
        public static int Widget_Material3_MaterialCalendar_MonthTextView = 0x7f0f03aa;
        public static int Widget_Material3_MaterialCalendar_Year = 0x7f0f03ab;
        public static int Widget_Material3_MaterialCalendar_YearNavigationButton = 0x7f0f03ae;
        public static int Widget_Material3_MaterialCalendar_Year_Selected = 0x7f0f03ac;
        public static int Widget_Material3_MaterialCalendar_Year_Today = 0x7f0f03ad;
        public static int Widget_Material3_MaterialDivider = 0x7f0f03af;
        public static int Widget_Material3_MaterialDivider_Heavy = 0x7f0f03b0;
        public static int Widget_Material3_MaterialTimePicker = 0x7f0f03b1;
        public static int Widget_Material3_MaterialTimePicker_Button = 0x7f0f03b2;
        public static int Widget_Material3_MaterialTimePicker_Clock = 0x7f0f03b3;
        public static int Widget_Material3_MaterialTimePicker_Display = 0x7f0f03b4;
        public static int Widget_Material3_MaterialTimePicker_Display_Divider = 0x7f0f03b5;
        public static int Widget_Material3_MaterialTimePicker_Display_HelperText = 0x7f0f03b6;
        public static int Widget_Material3_MaterialTimePicker_Display_TextInputEditText = 0x7f0f03b7;
        public static int Widget_Material3_MaterialTimePicker_Display_TextInputLayout = 0x7f0f03b8;
        public static int Widget_Material3_MaterialTimePicker_ImageButton = 0x7f0f03b9;
        public static int Widget_Material3_NavigationRailView = 0x7f0f03ba;
        public static int Widget_Material3_NavigationRailView_ActiveIndicator = 0x7f0f03bb;
        public static int Widget_Material3_NavigationRailView_Badge = 0x7f0f03bc;
        public static int Widget_Material3_NavigationView = 0x7f0f03bd;
        public static int Widget_Material3_PopupMenu = 0x7f0f03be;
        public static int Widget_Material3_PopupMenu_ContextMenu = 0x7f0f03bf;
        public static int Widget_Material3_PopupMenu_ListPopupWindow = 0x7f0f03c0;
        public static int Widget_Material3_PopupMenu_Overflow = 0x7f0f03c1;
        public static int Widget_Material3_SearchBar = 0x7f0f03c4;
        public static int Widget_Material3_SearchBar_Outlined = 0x7f0f03c5;
        public static int Widget_Material3_SearchView = 0x7f0f03c6;
        public static int Widget_Material3_SearchView_Prefix = 0x7f0f03c7;
        public static int Widget_Material3_SearchView_Toolbar = 0x7f0f03c8;
        public static int Widget_Material3_Search_ActionButton_Overflow = 0x7f0f03c2;
        public static int Widget_Material3_Search_Toolbar_Button_Navigation = 0x7f0f03c3;
        public static int Widget_Material3_SideSheet = 0x7f0f03c9;
        public static int Widget_Material3_SideSheet_Detached = 0x7f0f03ca;
        public static int Widget_Material3_SideSheet_Modal = 0x7f0f03cb;
        public static int Widget_Material3_SideSheet_Modal_Detached = 0x7f0f03cc;
        public static int Widget_Material3_Slider = 0x7f0f03cd;
        public static int Widget_Material3_Slider_Label = 0x7f0f03ce;
        public static int Widget_Material3_Slider_Legacy = 0x7f0f03cf;
        public static int Widget_Material3_Slider_Legacy_Label = 0x7f0f03d0;
        public static int Widget_Material3_Snackbar = 0x7f0f03d1;
        public static int Widget_Material3_Snackbar_FullWidth = 0x7f0f03d2;
        public static int Widget_Material3_Snackbar_TextView = 0x7f0f03d3;
        public static int Widget_Material3_TabLayout = 0x7f0f03d4;
        public static int Widget_Material3_TabLayout_OnSurface = 0x7f0f03d5;
        public static int Widget_Material3_TabLayout_Secondary = 0x7f0f03d6;
        public static int Widget_Material3_TextInputEditText_FilledBox = 0x7f0f03d7;
        public static int Widget_Material3_TextInputEditText_FilledBox_Dense = 0x7f0f03d8;
        public static int Widget_Material3_TextInputEditText_OutlinedBox = 0x7f0f03d9;
        public static int Widget_Material3_TextInputEditText_OutlinedBox_Dense = 0x7f0f03da;
        public static int Widget_Material3_TextInputLayout_FilledBox = 0x7f0f03db;
        public static int Widget_Material3_TextInputLayout_FilledBox_Dense = 0x7f0f03dc;
        public static int Widget_Material3_TextInputLayout_FilledBox_Dense_ExposedDropdownMenu = 0x7f0f03dd;
        public static int Widget_Material3_TextInputLayout_FilledBox_ExposedDropdownMenu = 0x7f0f03de;
        public static int Widget_Material3_TextInputLayout_OutlinedBox = 0x7f0f03df;
        public static int Widget_Material3_TextInputLayout_OutlinedBox_Dense = 0x7f0f03e0;
        public static int Widget_Material3_TextInputLayout_OutlinedBox_Dense_ExposedDropdownMenu = 0x7f0f03e1;
        public static int Widget_Material3_TextInputLayout_OutlinedBox_ExposedDropdownMenu = 0x7f0f03e2;
        public static int Widget_Material3_Toolbar = 0x7f0f03e3;
        public static int Widget_Material3_Toolbar_OnSurface = 0x7f0f03e4;
        public static int Widget_Material3_Toolbar_Surface = 0x7f0f03e5;
        public static int Widget_Material3_Tooltip = 0x7f0f03e6;
        public static int Widget_MaterialComponents_ActionBar_Primary = 0x7f0f03e7;
        public static int Widget_MaterialComponents_ActionBar_PrimarySurface = 0x7f0f03e8;
        public static int Widget_MaterialComponents_ActionBar_Solid = 0x7f0f03e9;
        public static int Widget_MaterialComponents_ActionBar_Surface = 0x7f0f03ea;
        public static int Widget_MaterialComponents_ActionMode = 0x7f0f03eb;
        public static int Widget_MaterialComponents_AppBarLayout_Primary = 0x7f0f03ec;
        public static int Widget_MaterialComponents_AppBarLayout_PrimarySurface = 0x7f0f03ed;
        public static int Widget_MaterialComponents_AppBarLayout_Surface = 0x7f0f03ee;
        public static int Widget_MaterialComponents_AutoCompleteTextView_FilledBox = 0x7f0f03ef;
        public static int Widget_MaterialComponents_AutoCompleteTextView_FilledBox_Dense = 0x7f0f03f0;
        public static int Widget_MaterialComponents_AutoCompleteTextView_OutlinedBox = 0x7f0f03f1;
        public static int Widget_MaterialComponents_AutoCompleteTextView_OutlinedBox_Dense = 0x7f0f03f2;
        public static int Widget_MaterialComponents_Badge = 0x7f0f03f3;
        public static int Widget_MaterialComponents_BottomAppBar = 0x7f0f03f4;
        public static int Widget_MaterialComponents_BottomAppBar_Colored = 0x7f0f03f5;
        public static int Widget_MaterialComponents_BottomAppBar_PrimarySurface = 0x7f0f03f6;
        public static int Widget_MaterialComponents_BottomNavigationView = 0x7f0f03f7;
        public static int Widget_MaterialComponents_BottomNavigationView_Colored = 0x7f0f03f8;
        public static int Widget_MaterialComponents_BottomNavigationView_PrimarySurface = 0x7f0f03f9;
        public static int Widget_MaterialComponents_BottomSheet = 0x7f0f03fa;
        public static int Widget_MaterialComponents_BottomSheet_Modal = 0x7f0f03fb;
        public static int Widget_MaterialComponents_Button = 0x7f0f03fc;
        public static int Widget_MaterialComponents_Button_Icon = 0x7f0f03fd;
        public static int Widget_MaterialComponents_Button_OutlinedButton = 0x7f0f03fe;
        public static int Widget_MaterialComponents_Button_OutlinedButton_Icon = 0x7f0f03ff;
        public static int Widget_MaterialComponents_Button_TextButton = 0x7f0f0400;
        public static int Widget_MaterialComponents_Button_TextButton_Dialog = 0x7f0f0401;
        public static int Widget_MaterialComponents_Button_TextButton_Dialog_Flush = 0x7f0f0402;
        public static int Widget_MaterialComponents_Button_TextButton_Dialog_Icon = 0x7f0f0403;
        public static int Widget_MaterialComponents_Button_TextButton_Icon = 0x7f0f0404;
        public static int Widget_MaterialComponents_Button_TextButton_Snackbar = 0x7f0f0405;
        public static int Widget_MaterialComponents_Button_UnelevatedButton = 0x7f0f0406;
        public static int Widget_MaterialComponents_Button_UnelevatedButton_Icon = 0x7f0f0407;
        public static int Widget_MaterialComponents_CardView = 0x7f0f0408;
        public static int Widget_MaterialComponents_CheckedTextView = 0x7f0f0409;
        public static int Widget_MaterialComponents_ChipGroup = 0x7f0f040e;
        public static int Widget_MaterialComponents_Chip_Action = 0x7f0f040a;
        public static int Widget_MaterialComponents_Chip_Choice = 0x7f0f040b;
        public static int Widget_MaterialComponents_Chip_Entry = 0x7f0f040c;
        public static int Widget_MaterialComponents_Chip_Filter = 0x7f0f040d;
        public static int Widget_MaterialComponents_CircularProgressIndicator = 0x7f0f040f;
        public static int Widget_MaterialComponents_CircularProgressIndicator_ExtraSmall = 0x7f0f0410;
        public static int Widget_MaterialComponents_CircularProgressIndicator_Medium = 0x7f0f0411;
        public static int Widget_MaterialComponents_CircularProgressIndicator_Small = 0x7f0f0412;
        public static int Widget_MaterialComponents_CollapsingToolbar = 0x7f0f0413;
        public static int Widget_MaterialComponents_CompoundButton_CheckBox = 0x7f0f0414;
        public static int Widget_MaterialComponents_CompoundButton_RadioButton = 0x7f0f0415;
        public static int Widget_MaterialComponents_CompoundButton_Switch = 0x7f0f0416;
        public static int Widget_MaterialComponents_ExtendedFloatingActionButton = 0x7f0f0417;
        public static int Widget_MaterialComponents_ExtendedFloatingActionButton_Icon = 0x7f0f0418;
        public static int Widget_MaterialComponents_FloatingActionButton = 0x7f0f0419;
        public static int Widget_MaterialComponents_Light_ActionBar_Solid = 0x7f0f041a;
        public static int Widget_MaterialComponents_LinearProgressIndicator = 0x7f0f041b;
        public static int Widget_MaterialComponents_MaterialButtonToggleGroup = 0x7f0f041c;
        public static int Widget_MaterialComponents_MaterialCalendar = 0x7f0f041d;
        public static int Widget_MaterialComponents_MaterialCalendar_Day = 0x7f0f041e;
        public static int Widget_MaterialComponents_MaterialCalendar_DayOfWeekLabel = 0x7f0f0422;
        public static int Widget_MaterialComponents_MaterialCalendar_DayTextView = 0x7f0f0423;
        public static int Widget_MaterialComponents_MaterialCalendar_Day_Invalid = 0x7f0f041f;
        public static int Widget_MaterialComponents_MaterialCalendar_Day_Selected = 0x7f0f0420;
        public static int Widget_MaterialComponents_MaterialCalendar_Day_Today = 0x7f0f0421;
        public static int Widget_MaterialComponents_MaterialCalendar_Fullscreen = 0x7f0f0424;
        public static int Widget_MaterialComponents_MaterialCalendar_HeaderCancelButton = 0x7f0f0425;
        public static int Widget_MaterialComponents_MaterialCalendar_HeaderConfirmButton = 0x7f0f0426;
        public static int Widget_MaterialComponents_MaterialCalendar_HeaderDivider = 0x7f0f0427;
        public static int Widget_MaterialComponents_MaterialCalendar_HeaderLayout = 0x7f0f0428;
        public static int Widget_MaterialComponents_MaterialCalendar_HeaderLayout_Fullscreen = 0x7f0f0429;
        public static int Widget_MaterialComponents_MaterialCalendar_HeaderSelection = 0x7f0f042a;
        public static int Widget_MaterialComponents_MaterialCalendar_HeaderSelection_Fullscreen = 0x7f0f042b;
        public static int Widget_MaterialComponents_MaterialCalendar_HeaderTitle = 0x7f0f042c;
        public static int Widget_MaterialComponents_MaterialCalendar_HeaderToggleButton = 0x7f0f042d;
        public static int Widget_MaterialComponents_MaterialCalendar_Item = 0x7f0f042e;
        public static int Widget_MaterialComponents_MaterialCalendar_MonthNavigationButton = 0x7f0f042f;
        public static int Widget_MaterialComponents_MaterialCalendar_MonthTextView = 0x7f0f0430;
        public static int Widget_MaterialComponents_MaterialCalendar_Year = 0x7f0f0431;
        public static int Widget_MaterialComponents_MaterialCalendar_YearNavigationButton = 0x7f0f0434;
        public static int Widget_MaterialComponents_MaterialCalendar_Year_Selected = 0x7f0f0432;
        public static int Widget_MaterialComponents_MaterialCalendar_Year_Today = 0x7f0f0433;
        public static int Widget_MaterialComponents_MaterialDivider = 0x7f0f0435;
        public static int Widget_MaterialComponents_NavigationRailView = 0x7f0f0436;
        public static int Widget_MaterialComponents_NavigationRailView_Colored = 0x7f0f0437;
        public static int Widget_MaterialComponents_NavigationRailView_Colored_Compact = 0x7f0f0438;
        public static int Widget_MaterialComponents_NavigationRailView_Compact = 0x7f0f0439;
        public static int Widget_MaterialComponents_NavigationRailView_PrimarySurface = 0x7f0f043a;
        public static int Widget_MaterialComponents_NavigationView = 0x7f0f043b;
        public static int Widget_MaterialComponents_PopupMenu = 0x7f0f043c;
        public static int Widget_MaterialComponents_PopupMenu_ContextMenu = 0x7f0f043d;
        public static int Widget_MaterialComponents_PopupMenu_ListPopupWindow = 0x7f0f043e;
        public static int Widget_MaterialComponents_PopupMenu_Overflow = 0x7f0f043f;
        public static int Widget_MaterialComponents_ProgressIndicator = 0x7f0f0440;
        public static int Widget_MaterialComponents_ShapeableImageView = 0x7f0f0441;
        public static int Widget_MaterialComponents_Slider = 0x7f0f0442;
        public static int Widget_MaterialComponents_Snackbar = 0x7f0f0443;
        public static int Widget_MaterialComponents_Snackbar_FullWidth = 0x7f0f0444;
        public static int Widget_MaterialComponents_Snackbar_TextView = 0x7f0f0445;
        public static int Widget_MaterialComponents_TabLayout = 0x7f0f0446;
        public static int Widget_MaterialComponents_TabLayout_Colored = 0x7f0f0447;
        public static int Widget_MaterialComponents_TabLayout_PrimarySurface = 0x7f0f0448;
        public static int Widget_MaterialComponents_TextInputEditText_FilledBox = 0x7f0f0449;
        public static int Widget_MaterialComponents_TextInputEditText_FilledBox_Dense = 0x7f0f044a;
        public static int Widget_MaterialComponents_TextInputEditText_OutlinedBox = 0x7f0f044b;
        public static int Widget_MaterialComponents_TextInputEditText_OutlinedBox_Dense = 0x7f0f044c;
        public static int Widget_MaterialComponents_TextInputLayout_FilledBox = 0x7f0f044d;
        public static int Widget_MaterialComponents_TextInputLayout_FilledBox_Dense = 0x7f0f044e;
        public static int Widget_MaterialComponents_TextInputLayout_FilledBox_Dense_ExposedDropdownMenu = 0x7f0f044f;
        public static int Widget_MaterialComponents_TextInputLayout_FilledBox_ExposedDropdownMenu = 0x7f0f0450;
        public static int Widget_MaterialComponents_TextInputLayout_OutlinedBox = 0x7f0f0451;
        public static int Widget_MaterialComponents_TextInputLayout_OutlinedBox_Dense = 0x7f0f0452;
        public static int Widget_MaterialComponents_TextInputLayout_OutlinedBox_Dense_ExposedDropdownMenu = 0x7f0f0453;
        public static int Widget_MaterialComponents_TextInputLayout_OutlinedBox_ExposedDropdownMenu = 0x7f0f0454;
        public static int Widget_MaterialComponents_TextView = 0x7f0f0455;
        public static int Widget_MaterialComponents_TimePicker = 0x7f0f0456;
        public static int Widget_MaterialComponents_TimePicker_Button = 0x7f0f0457;
        public static int Widget_MaterialComponents_TimePicker_Clock = 0x7f0f0458;
        public static int Widget_MaterialComponents_TimePicker_Display = 0x7f0f0459;
        public static int Widget_MaterialComponents_TimePicker_Display_Divider = 0x7f0f045a;
        public static int Widget_MaterialComponents_TimePicker_Display_HelperText = 0x7f0f045b;
        public static int Widget_MaterialComponents_TimePicker_Display_TextInputEditText = 0x7f0f045c;
        public static int Widget_MaterialComponents_TimePicker_Display_TextInputLayout = 0x7f0f045d;
        public static int Widget_MaterialComponents_TimePicker_ImageButton = 0x7f0f045e;
        public static int Widget_MaterialComponents_TimePicker_ImageButton_ShapeAppearance = 0x7f0f045f;
        public static int Widget_MaterialComponents_Toolbar = 0x7f0f0460;
        public static int Widget_MaterialComponents_Toolbar_Primary = 0x7f0f0461;
        public static int Widget_MaterialComponents_Toolbar_PrimarySurface = 0x7f0f0462;
        public static int Widget_MaterialComponents_Toolbar_Surface = 0x7f0f0463;
        public static int Widget_MaterialComponents_Tooltip = 0x7f0f0464;
        public static int Widget_Support_CoordinatorLayout = 0x7f0f0465;

        private style() {
        }
    }

    public static final class styleable {
        public static int ActionBarLayout_android_layout_gravity = 0x00000000;
        public static int ActionBar_background = 0x00000000;
        public static int ActionBar_backgroundSplit = 0x00000001;
        public static int ActionBar_backgroundStacked = 0x00000002;
        public static int ActionBar_contentInsetEnd = 0x00000003;
        public static int ActionBar_contentInsetEndWithActions = 0x00000004;
        public static int ActionBar_contentInsetLeft = 0x00000005;
        public static int ActionBar_contentInsetRight = 0x00000006;
        public static int ActionBar_contentInsetStart = 0x00000007;
        public static int ActionBar_contentInsetStartWithNavigation = 0x00000008;
        public static int ActionBar_customNavigationLayout = 0x00000009;
        public static int ActionBar_displayOptions = 0x0000000a;
        public static int ActionBar_divider = 0x0000000b;
        public static int ActionBar_elevation = 0x0000000c;
        public static int ActionBar_height = 0x0000000d;
        public static int ActionBar_hideOnContentScroll = 0x0000000e;
        public static int ActionBar_homeAsUpIndicator = 0x0000000f;
        public static int ActionBar_homeLayout = 0x00000010;
        public static int ActionBar_icon = 0x00000011;
        public static int ActionBar_indeterminateProgressStyle = 0x00000012;
        public static int ActionBar_itemPadding = 0x00000013;
        public static int ActionBar_logo = 0x00000014;
        public static int ActionBar_navigationMode = 0x00000015;
        public static int ActionBar_popupTheme = 0x00000016;
        public static int ActionBar_progressBarPadding = 0x00000017;
        public static int ActionBar_progressBarStyle = 0x00000018;
        public static int ActionBar_subtitle = 0x00000019;
        public static int ActionBar_subtitleTextStyle = 0x0000001a;
        public static int ActionBar_title = 0x0000001b;
        public static int ActionBar_titleTextStyle = 0x0000001c;
        public static int ActionMenuItemView_android_minWidth = 0x00000000;
        public static int ActionMode_background = 0x00000000;
        public static int ActionMode_backgroundSplit = 0x00000001;
        public static int ActionMode_closeItemLayout = 0x00000002;
        public static int ActionMode_height = 0x00000003;
        public static int ActionMode_subtitleTextStyle = 0x00000004;
        public static int ActionMode_titleTextStyle = 0x00000005;
        public static int ActivityChooserView_expandActivityOverflowButtonDrawable = 0x00000000;
        public static int ActivityChooserView_initialActivityCount = 0x00000001;
        public static int AlertDialog_android_layout = 0x00000000;
        public static int AlertDialog_buttonIconDimen = 0x00000001;
        public static int AlertDialog_buttonPanelSideLayout = 0x00000002;
        public static int AlertDialog_listItemLayout = 0x00000003;
        public static int AlertDialog_listLayout = 0x00000004;
        public static int AlertDialog_multiChoiceItemLayout = 0x00000005;
        public static int AlertDialog_showTitle = 0x00000006;
        public static int AlertDialog_singleChoiceItemLayout = 0x00000007;
        public static int AnimatedStateListDrawableCompat_android_constantSize = 0x00000003;
        public static int AnimatedStateListDrawableCompat_android_dither = 0x00000000;
        public static int AnimatedStateListDrawableCompat_android_enterFadeDuration = 0x00000004;
        public static int AnimatedStateListDrawableCompat_android_exitFadeDuration = 0x00000005;
        public static int AnimatedStateListDrawableCompat_android_variablePadding = 0x00000002;
        public static int AnimatedStateListDrawableCompat_android_visible = 0x00000001;
        public static int AnimatedStateListDrawableItem_android_drawable = 0x00000001;
        public static int AnimatedStateListDrawableItem_android_id = 0x00000000;
        public static int AnimatedStateListDrawableTransition_android_drawable = 0x00000000;
        public static int AnimatedStateListDrawableTransition_android_fromId = 0x00000002;
        public static int AnimatedStateListDrawableTransition_android_reversible = 0x00000003;
        public static int AnimatedStateListDrawableTransition_android_toId = 0x00000001;
        public static int AppBarLayoutStates_state_collapsed = 0x00000000;
        public static int AppBarLayoutStates_state_collapsible = 0x00000001;
        public static int AppBarLayoutStates_state_liftable = 0x00000002;
        public static int AppBarLayoutStates_state_lifted = 0x00000003;
        public static int AppBarLayout_Layout_layout_scrollEffect = 0x00000000;
        public static int AppBarLayout_Layout_layout_scrollFlags = 0x00000001;
        public static int AppBarLayout_Layout_layout_scrollInterpolator = 0x00000002;
        public static int AppBarLayout_android_background = 0x00000000;
        public static int AppBarLayout_android_keyboardNavigationCluster = 0x00000002;
        public static int AppBarLayout_android_touchscreenBlocksFocus = 0x00000001;
        public static int AppBarLayout_elevation = 0x00000003;
        public static int AppBarLayout_expanded = 0x00000004;
        public static int AppBarLayout_liftOnScroll = 0x00000005;
        public static int AppBarLayout_liftOnScrollColor = 0x00000006;
        public static int AppBarLayout_liftOnScrollTargetViewId = 0x00000007;
        public static int AppBarLayout_statusBarForeground = 0x00000008;
        public static int AppCompatImageView_android_src = 0x00000000;
        public static int AppCompatImageView_srcCompat = 0x00000001;
        public static int AppCompatImageView_tint = 0x00000002;
        public static int AppCompatImageView_tintMode = 0x00000003;
        public static int AppCompatSeekBar_android_thumb = 0x00000000;
        public static int AppCompatSeekBar_tickMark = 0x00000001;
        public static int AppCompatSeekBar_tickMarkTint = 0x00000002;
        public static int AppCompatSeekBar_tickMarkTintMode = 0x00000003;
        public static int AppCompatTextHelper_android_drawableBottom = 0x00000002;
        public static int AppCompatTextHelper_android_drawableEnd = 0x00000006;
        public static int AppCompatTextHelper_android_drawableLeft = 0x00000003;
        public static int AppCompatTextHelper_android_drawableRight = 0x00000004;
        public static int AppCompatTextHelper_android_drawableStart = 0x00000005;
        public static int AppCompatTextHelper_android_drawableTop = 0x00000001;
        public static int AppCompatTextHelper_android_textAppearance = 0x00000000;
        public static int AppCompatTextView_android_textAppearance = 0x00000000;
        public static int AppCompatTextView_autoSizeMaxTextSize = 0x00000001;
        public static int AppCompatTextView_autoSizeMinTextSize = 0x00000002;
        public static int AppCompatTextView_autoSizePresetSizes = 0x00000003;
        public static int AppCompatTextView_autoSizeStepGranularity = 0x00000004;
        public static int AppCompatTextView_autoSizeTextType = 0x00000005;
        public static int AppCompatTextView_drawableBottomCompat = 0x00000006;
        public static int AppCompatTextView_drawableEndCompat = 0x00000007;
        public static int AppCompatTextView_drawableLeftCompat = 0x00000008;
        public static int AppCompatTextView_drawableRightCompat = 0x00000009;
        public static int AppCompatTextView_drawableStartCompat = 0x0000000a;
        public static int AppCompatTextView_drawableTint = 0x0000000b;
        public static int AppCompatTextView_drawableTintMode = 0x0000000c;
        public static int AppCompatTextView_drawableTopCompat = 0x0000000d;
        public static int AppCompatTextView_emojiCompatEnabled = 0x0000000e;
        public static int AppCompatTextView_firstBaselineToTopHeight = 0x0000000f;
        public static int AppCompatTextView_fontFamily = 0x00000010;
        public static int AppCompatTextView_fontVariationSettings = 0x00000011;
        public static int AppCompatTextView_lastBaselineToBottomHeight = 0x00000012;
        public static int AppCompatTextView_lineHeight = 0x00000013;
        public static int AppCompatTextView_textAllCaps = 0x00000014;
        public static int AppCompatTextView_textLocale = 0x00000015;
        public static int AppCompatTheme_actionBarDivider = 0x00000002;
        public static int AppCompatTheme_actionBarItemBackground = 0x00000003;
        public static int AppCompatTheme_actionBarPopupTheme = 0x00000004;
        public static int AppCompatTheme_actionBarSize = 0x00000005;
        public static int AppCompatTheme_actionBarSplitStyle = 0x00000006;
        public static int AppCompatTheme_actionBarStyle = 0x00000007;
        public static int AppCompatTheme_actionBarTabBarStyle = 0x00000008;
        public static int AppCompatTheme_actionBarTabStyle = 0x00000009;
        public static int AppCompatTheme_actionBarTabTextStyle = 0x0000000a;
        public static int AppCompatTheme_actionBarTheme = 0x0000000b;
        public static int AppCompatTheme_actionBarWidgetTheme = 0x0000000c;
        public static int AppCompatTheme_actionButtonStyle = 0x0000000d;
        public static int AppCompatTheme_actionDropDownStyle = 0x0000000e;
        public static int AppCompatTheme_actionMenuTextAppearance = 0x0000000f;
        public static int AppCompatTheme_actionMenuTextColor = 0x00000010;
        public static int AppCompatTheme_actionModeBackground = 0x00000011;
        public static int AppCompatTheme_actionModeCloseButtonStyle = 0x00000012;
        public static int AppCompatTheme_actionModeCloseContentDescription = 0x00000013;
        public static int AppCompatTheme_actionModeCloseDrawable = 0x00000014;
        public static int AppCompatTheme_actionModeCopyDrawable = 0x00000015;
        public static int AppCompatTheme_actionModeCutDrawable = 0x00000016;
        public static int AppCompatTheme_actionModeFindDrawable = 0x00000017;
        public static int AppCompatTheme_actionModePasteDrawable = 0x00000018;
        public static int AppCompatTheme_actionModePopupWindowStyle = 0x00000019;
        public static int AppCompatTheme_actionModeSelectAllDrawable = 0x0000001a;
        public static int AppCompatTheme_actionModeShareDrawable = 0x0000001b;
        public static int AppCompatTheme_actionModeSplitBackground = 0x0000001c;
        public static int AppCompatTheme_actionModeStyle = 0x0000001d;
        public static int AppCompatTheme_actionModeTheme = 0x0000001e;
        public static int AppCompatTheme_actionModeWebSearchDrawable = 0x0000001f;
        public static int AppCompatTheme_actionOverflowButtonStyle = 0x00000020;
        public static int AppCompatTheme_actionOverflowMenuStyle = 0x00000021;
        public static int AppCompatTheme_activityChooserViewStyle = 0x00000022;
        public static int AppCompatTheme_alertDialogButtonGroupStyle = 0x00000023;
        public static int AppCompatTheme_alertDialogCenterButtons = 0x00000024;
        public static int AppCompatTheme_alertDialogStyle = 0x00000025;
        public static int AppCompatTheme_alertDialogTheme = 0x00000026;
        public static int AppCompatTheme_android_windowAnimationStyle = 0x00000001;
        public static int AppCompatTheme_android_windowIsFloating = 0x00000000;
        public static int AppCompatTheme_autoCompleteTextViewStyle = 0x00000027;
        public static int AppCompatTheme_borderlessButtonStyle = 0x00000028;
        public static int AppCompatTheme_buttonBarButtonStyle = 0x00000029;
        public static int AppCompatTheme_buttonBarNegativeButtonStyle = 0x0000002a;
        public static int AppCompatTheme_buttonBarNeutralButtonStyle = 0x0000002b;
        public static int AppCompatTheme_buttonBarPositiveButtonStyle = 0x0000002c;
        public static int AppCompatTheme_buttonBarStyle = 0x0000002d;
        public static int AppCompatTheme_buttonStyle = 0x0000002e;
        public static int AppCompatTheme_buttonStyleSmall = 0x0000002f;
        public static int AppCompatTheme_checkboxStyle = 0x00000030;
        public static int AppCompatTheme_checkedTextViewStyle = 0x00000031;
        public static int AppCompatTheme_colorAccent = 0x00000032;
        public static int AppCompatTheme_colorBackgroundFloating = 0x00000033;
        public static int AppCompatTheme_colorButtonNormal = 0x00000034;
        public static int AppCompatTheme_colorControlActivated = 0x00000035;
        public static int AppCompatTheme_colorControlHighlight = 0x00000036;
        public static int AppCompatTheme_colorControlNormal = 0x00000037;
        public static int AppCompatTheme_colorError = 0x00000038;
        public static int AppCompatTheme_colorPrimary = 0x00000039;
        public static int AppCompatTheme_colorPrimaryDark = 0x0000003a;
        public static int AppCompatTheme_colorSwitchThumbNormal = 0x0000003b;
        public static int AppCompatTheme_controlBackground = 0x0000003c;
        public static int AppCompatTheme_dialogCornerRadius = 0x0000003d;
        public static int AppCompatTheme_dialogPreferredPadding = 0x0000003e;
        public static int AppCompatTheme_dialogTheme = 0x0000003f;
        public static int AppCompatTheme_dividerHorizontal = 0x00000040;
        public static int AppCompatTheme_dividerVertical = 0x00000041;
        public static int AppCompatTheme_dropDownListViewStyle = 0x00000042;
        public static int AppCompatTheme_dropdownListPreferredItemHeight = 0x00000043;
        public static int AppCompatTheme_editTextBackground = 0x00000044;
        public static int AppCompatTheme_editTextColor = 0x00000045;
        public static int AppCompatTheme_editTextStyle = 0x00000046;
        public static int AppCompatTheme_homeAsUpIndicator = 0x00000047;
        public static int AppCompatTheme_imageButtonStyle = 0x00000048;
        public static int AppCompatTheme_listChoiceBackgroundIndicator = 0x00000049;
        public static int AppCompatTheme_listChoiceIndicatorMultipleAnimated = 0x0000004a;
        public static int AppCompatTheme_listChoiceIndicatorSingleAnimated = 0x0000004b;
        public static int AppCompatTheme_listDividerAlertDialog = 0x0000004c;
        public static int AppCompatTheme_listMenuViewStyle = 0x0000004d;
        public static int AppCompatTheme_listPopupWindowStyle = 0x0000004e;
        public static int AppCompatTheme_listPreferredItemHeight = 0x0000004f;
        public static int AppCompatTheme_listPreferredItemHeightLarge = 0x00000050;
        public static int AppCompatTheme_listPreferredItemHeightSmall = 0x00000051;
        public static int AppCompatTheme_listPreferredItemPaddingEnd = 0x00000052;
        public static int AppCompatTheme_listPreferredItemPaddingLeft = 0x00000053;
        public static int AppCompatTheme_listPreferredItemPaddingRight = 0x00000054;
        public static int AppCompatTheme_listPreferredItemPaddingStart = 0x00000055;
        public static int AppCompatTheme_panelBackground = 0x00000056;
        public static int AppCompatTheme_panelMenuListTheme = 0x00000057;
        public static int AppCompatTheme_panelMenuListWidth = 0x00000058;
        public static int AppCompatTheme_popupMenuStyle = 0x00000059;
        public static int AppCompatTheme_popupWindowStyle = 0x0000005a;
        public static int AppCompatTheme_radioButtonStyle = 0x0000005b;
        public static int AppCompatTheme_ratingBarStyle = 0x0000005c;
        public static int AppCompatTheme_ratingBarStyleIndicator = 0x0000005d;
        public static int AppCompatTheme_ratingBarStyleSmall = 0x0000005e;
        public static int AppCompatTheme_searchViewStyle = 0x0000005f;
        public static int AppCompatTheme_seekBarStyle = 0x00000060;
        public static int AppCompatTheme_selectableItemBackground = 0x00000061;
        public static int AppCompatTheme_selectableItemBackgroundBorderless = 0x00000062;
        public static int AppCompatTheme_spinnerDropDownItemStyle = 0x00000063;
        public static int AppCompatTheme_spinnerStyle = 0x00000064;
        public static int AppCompatTheme_switchStyle = 0x00000065;
        public static int AppCompatTheme_textAppearanceLargePopupMenu = 0x00000066;
        public static int AppCompatTheme_textAppearanceListItem = 0x00000067;
        public static int AppCompatTheme_textAppearanceListItemSecondary = 0x00000068;
        public static int AppCompatTheme_textAppearanceListItemSmall = 0x00000069;
        public static int AppCompatTheme_textAppearancePopupMenuHeader = 0x0000006a;
        public static int AppCompatTheme_textAppearanceSearchResultSubtitle = 0x0000006b;
        public static int AppCompatTheme_textAppearanceSearchResultTitle = 0x0000006c;
        public static int AppCompatTheme_textAppearanceSmallPopupMenu = 0x0000006d;
        public static int AppCompatTheme_textColorAlertDialogListItem = 0x0000006e;
        public static int AppCompatTheme_textColorSearchUrl = 0x0000006f;
        public static int AppCompatTheme_toolbarNavigationButtonStyle = 0x00000070;
        public static int AppCompatTheme_toolbarStyle = 0x00000071;
        public static int AppCompatTheme_tooltipForegroundColor = 0x00000072;
        public static int AppCompatTheme_tooltipFrameBackground = 0x00000073;
        public static int AppCompatTheme_viewInflaterClass = 0x00000074;
        public static int AppCompatTheme_windowActionBar = 0x00000075;
        public static int AppCompatTheme_windowActionBarOverlay = 0x00000076;
        public static int AppCompatTheme_windowActionModeOverlay = 0x00000077;
        public static int AppCompatTheme_windowFixedHeightMajor = 0x00000078;
        public static int AppCompatTheme_windowFixedHeightMinor = 0x00000079;
        public static int AppCompatTheme_windowFixedWidthMajor = 0x0000007a;
        public static int AppCompatTheme_windowFixedWidthMinor = 0x0000007b;
        public static int AppCompatTheme_windowMinWidthMajor = 0x0000007c;
        public static int AppCompatTheme_windowMinWidthMinor = 0x0000007d;
        public static int AppCompatTheme_windowNoTitle = 0x0000007e;
        public static int Badge_autoAdjustToWithinGrandparentBounds = 0x00000000;
        public static int Badge_backgroundColor = 0x00000001;
        public static int Badge_badgeGravity = 0x00000002;
        public static int Badge_badgeHeight = 0x00000003;
        public static int Badge_badgeRadius = 0x00000004;
        public static int Badge_badgeShapeAppearance = 0x00000005;
        public static int Badge_badgeShapeAppearanceOverlay = 0x00000006;
        public static int Badge_badgeText = 0x00000007;
        public static int Badge_badgeTextAppearance = 0x00000008;
        public static int Badge_badgeTextColor = 0x00000009;
        public static int Badge_badgeVerticalPadding = 0x0000000a;
        public static int Badge_badgeWidePadding = 0x0000000b;
        public static int Badge_badgeWidth = 0x0000000c;
        public static int Badge_badgeWithTextHeight = 0x0000000d;
        public static int Badge_badgeWithTextRadius = 0x0000000e;
        public static int Badge_badgeWithTextShapeAppearance = 0x0000000f;
        public static int Badge_badgeWithTextShapeAppearanceOverlay = 0x00000010;
        public static int Badge_badgeWithTextWidth = 0x00000011;
        public static int Badge_horizontalOffset = 0x00000012;
        public static int Badge_horizontalOffsetWithText = 0x00000013;
        public static int Badge_largeFontVerticalOffsetAdjustment = 0x00000014;
        public static int Badge_maxCharacterCount = 0x00000015;
        public static int Badge_maxNumber = 0x00000016;
        public static int Badge_number = 0x00000017;
        public static int Badge_offsetAlignmentMode = 0x00000018;
        public static int Badge_verticalOffset = 0x00000019;
        public static int Badge_verticalOffsetWithText = 0x0000001a;
        public static int BaseProgressIndicator_android_indeterminate = 0x00000000;
        public static int BaseProgressIndicator_hideAnimationBehavior = 0x00000001;
        public static int BaseProgressIndicator_indicatorColor = 0x00000002;
        public static int BaseProgressIndicator_indicatorTrackGapSize = 0x00000003;
        public static int BaseProgressIndicator_minHideDelay = 0x00000004;
        public static int BaseProgressIndicator_showAnimationBehavior = 0x00000005;
        public static int BaseProgressIndicator_showDelay = 0x00000006;
        public static int BaseProgressIndicator_trackColor = 0x00000007;
        public static int BaseProgressIndicator_trackCornerRadius = 0x00000008;
        public static int BaseProgressIndicator_trackThickness = 0x00000009;
        public static int BottomAppBar_addElevationShadow = 0x00000000;
        public static int BottomAppBar_backgroundTint = 0x00000001;
        public static int BottomAppBar_elevation = 0x00000002;
        public static int BottomAppBar_fabAlignmentMode = 0x00000003;
        public static int BottomAppBar_fabAlignmentModeEndMargin = 0x00000004;
        public static int BottomAppBar_fabAnchorMode = 0x00000005;
        public static int BottomAppBar_fabAnimationMode = 0x00000006;
        public static int BottomAppBar_fabCradleMargin = 0x00000007;
        public static int BottomAppBar_fabCradleRoundedCornerRadius = 0x00000008;
        public static int BottomAppBar_fabCradleVerticalOffset = 0x00000009;
        public static int BottomAppBar_hideOnScroll = 0x0000000a;
        public static int BottomAppBar_menuAlignmentMode = 0x0000000b;
        public static int BottomAppBar_navigationIconTint = 0x0000000c;
        public static int BottomAppBar_paddingBottomSystemWindowInsets = 0x0000000d;
        public static int BottomAppBar_paddingLeftSystemWindowInsets = 0x0000000e;
        public static int BottomAppBar_paddingRightSystemWindowInsets = 0x0000000f;
        public static int BottomAppBar_removeEmbeddedFabElevation = 0x00000010;
        public static int BottomNavigationView_android_minHeight = 0x00000000;
        public static int BottomNavigationView_compatShadowEnabled = 0x00000001;
        public static int BottomNavigationView_itemHorizontalTranslationEnabled = 0x00000002;
        public static int BottomNavigationView_shapeAppearance = 0x00000003;
        public static int BottomNavigationView_shapeAppearanceOverlay = 0x00000004;
        public static int BottomSheetBehavior_Layout_android_elevation = 0x00000002;
        public static int BottomSheetBehavior_Layout_android_maxHeight = 0x00000001;
        public static int BottomSheetBehavior_Layout_android_maxWidth = 0x00000000;
        public static int BottomSheetBehavior_Layout_backgroundTint = 0x00000003;
        public static int BottomSheetBehavior_Layout_behavior_draggable = 0x00000004;
        public static int BottomSheetBehavior_Layout_behavior_expandedOffset = 0x00000005;
        public static int BottomSheetBehavior_Layout_behavior_fitToContents = 0x00000006;
        public static int BottomSheetBehavior_Layout_behavior_halfExpandedRatio = 0x00000007;
        public static int BottomSheetBehavior_Layout_behavior_hideable = 0x00000008;
        public static int BottomSheetBehavior_Layout_behavior_peekHeight = 0x00000009;
        public static int BottomSheetBehavior_Layout_behavior_saveFlags = 0x0000000a;
        public static int BottomSheetBehavior_Layout_behavior_significantVelocityThreshold = 0x0000000b;
        public static int BottomSheetBehavior_Layout_behavior_skipCollapsed = 0x0000000c;
        public static int BottomSheetBehavior_Layout_gestureInsetBottomIgnored = 0x0000000d;
        public static int BottomSheetBehavior_Layout_marginLeftSystemWindowInsets = 0x0000000e;
        public static int BottomSheetBehavior_Layout_marginRightSystemWindowInsets = 0x0000000f;
        public static int BottomSheetBehavior_Layout_marginTopSystemWindowInsets = 0x00000010;
        public static int BottomSheetBehavior_Layout_paddingBottomSystemWindowInsets = 0x00000011;
        public static int BottomSheetBehavior_Layout_paddingLeftSystemWindowInsets = 0x00000012;
        public static int BottomSheetBehavior_Layout_paddingRightSystemWindowInsets = 0x00000013;
        public static int BottomSheetBehavior_Layout_paddingTopSystemWindowInsets = 0x00000014;
        public static int BottomSheetBehavior_Layout_shapeAppearance = 0x00000015;
        public static int BottomSheetBehavior_Layout_shapeAppearanceOverlay = 0x00000016;
        public static int BottomSheetBehavior_Layout_shouldRemoveExpandedCorners = 0x00000017;
        public static int ButtonBarLayout_allowStacking = 0x00000000;
        public static int Capability_queryPatterns = 0x00000000;
        public static int Capability_shortcutMatchRequired = 0x00000001;
        public static int CardView_android_minHeight = 0x00000001;
        public static int CardView_android_minWidth = 0x00000000;
        public static int CardView_cardBackgroundColor = 0x00000002;
        public static int CardView_cardCornerRadius = 0x00000003;
        public static int CardView_cardElevation = 0x00000004;
        public static int CardView_cardMaxElevation = 0x00000005;
        public static int CardView_cardPreventCornerOverlap = 0x00000006;
        public static int CardView_cardUseCompatPadding = 0x00000007;
        public static int CardView_contentPadding = 0x00000008;
        public static int CardView_contentPaddingBottom = 0x00000009;
        public static int CardView_contentPaddingLeft = 0x0000000a;
        public static int CardView_contentPaddingRight = 0x0000000b;
        public static int CardView_contentPaddingTop = 0x0000000c;
        public static int Carousel_carousel_alignment = 0x00000000;
        public static int CheckedTextView_android_checkMark = 0x00000000;
        public static int CheckedTextView_checkMarkCompat = 0x00000001;
        public static int CheckedTextView_checkMarkTint = 0x00000002;
        public static int CheckedTextView_checkMarkTintMode = 0x00000003;
        public static int ChipGroup_checkedChip = 0x00000000;
        public static int ChipGroup_chipSpacing = 0x00000001;
        public static int ChipGroup_chipSpacingHorizontal = 0x00000002;
        public static int ChipGroup_chipSpacingVertical = 0x00000003;
        public static int ChipGroup_selectionRequired = 0x00000004;
        public static int ChipGroup_singleLine = 0x00000005;
        public static int ChipGroup_singleSelection = 0x00000006;
        public static int Chip_android_checkable = 0x00000006;
        public static int Chip_android_ellipsize = 0x00000003;
        public static int Chip_android_maxWidth = 0x00000004;
        public static int Chip_android_text = 0x00000005;
        public static int Chip_android_textAppearance = 0x00000000;
        public static int Chip_android_textColor = 0x00000002;
        public static int Chip_android_textSize = 0x00000001;
        public static int Chip_checkedIcon = 0x00000007;
        public static int Chip_checkedIconEnabled = 0x00000008;
        public static int Chip_checkedIconTint = 0x00000009;
        public static int Chip_checkedIconVisible = 0x0000000a;
        public static int Chip_chipBackgroundColor = 0x0000000b;
        public static int Chip_chipCornerRadius = 0x0000000c;
        public static int Chip_chipEndPadding = 0x0000000d;
        public static int Chip_chipIcon = 0x0000000e;
        public static int Chip_chipIconEnabled = 0x0000000f;
        public static int Chip_chipIconSize = 0x00000010;
        public static int Chip_chipIconTint = 0x00000011;
        public static int Chip_chipIconVisible = 0x00000012;
        public static int Chip_chipMinHeight = 0x00000013;
        public static int Chip_chipMinTouchTargetSize = 0x00000014;
        public static int Chip_chipStartPadding = 0x00000015;
        public static int Chip_chipStrokeColor = 0x00000016;
        public static int Chip_chipStrokeWidth = 0x00000017;
        public static int Chip_chipSurfaceColor = 0x00000018;
        public static int Chip_closeIcon = 0x00000019;
        public static int Chip_closeIconEnabled = 0x0000001a;
        public static int Chip_closeIconEndPadding = 0x0000001b;
        public static int Chip_closeIconSize = 0x0000001c;
        public static int Chip_closeIconStartPadding = 0x0000001d;
        public static int Chip_closeIconTint = 0x0000001e;
        public static int Chip_closeIconVisible = 0x0000001f;
        public static int Chip_ensureMinTouchTargetSize = 0x00000020;
        public static int Chip_hideMotionSpec = 0x00000021;
        public static int Chip_iconEndPadding = 0x00000022;
        public static int Chip_iconStartPadding = 0x00000023;
        public static int Chip_rippleColor = 0x00000024;
        public static int Chip_shapeAppearance = 0x00000025;
        public static int Chip_shapeAppearanceOverlay = 0x00000026;
        public static int Chip_showMotionSpec = 0x00000027;
        public static int Chip_textEndPadding = 0x00000028;
        public static int Chip_textStartPadding = 0x00000029;
        public static int CircularProgressIndicator_indicatorDirectionCircular = 0x00000000;
        public static int CircularProgressIndicator_indicatorInset = 0x00000001;
        public static int CircularProgressIndicator_indicatorSize = 0x00000002;
        public static int ClockFaceView_clockFaceBackgroundColor = 0x00000000;
        public static int ClockFaceView_clockNumberTextColor = 0x00000001;
        public static int ClockHandView_clockHandColor = 0x00000000;
        public static int ClockHandView_materialCircleRadius = 0x00000001;
        public static int ClockHandView_selectorSize = 0x00000002;
        public static int CollapsingToolbarLayout_Layout_layout_collapseMode = 0x00000000;
        public static int CollapsingToolbarLayout_Layout_layout_collapseParallaxMultiplier = 0x00000001;
        public static int CollapsingToolbarLayout_collapsedTitleGravity = 0x00000000;
        public static int CollapsingToolbarLayout_collapsedTitleTextAppearance = 0x00000001;
        public static int CollapsingToolbarLayout_collapsedTitleTextColor = 0x00000002;
        public static int CollapsingToolbarLayout_contentScrim = 0x00000003;
        public static int CollapsingToolbarLayout_expandedTitleGravity = 0x00000004;
        public static int CollapsingToolbarLayout_expandedTitleMargin = 0x00000005;
        public static int CollapsingToolbarLayout_expandedTitleMarginBottom = 0x00000006;
        public static int CollapsingToolbarLayout_expandedTitleMarginEnd = 0x00000007;
        public static int CollapsingToolbarLayout_expandedTitleMarginStart = 0x00000008;
        public static int CollapsingToolbarLayout_expandedTitleMarginTop = 0x00000009;
        public static int CollapsingToolbarLayout_expandedTitleTextAppearance = 0x0000000a;
        public static int CollapsingToolbarLayout_expandedTitleTextColor = 0x0000000b;
        public static int CollapsingToolbarLayout_extraMultilineHeightEnabled = 0x0000000c;
        public static int CollapsingToolbarLayout_forceApplySystemWindowInsetTop = 0x0000000d;
        public static int CollapsingToolbarLayout_maxLines = 0x0000000e;
        public static int CollapsingToolbarLayout_scrimAnimationDuration = 0x0000000f;
        public static int CollapsingToolbarLayout_scrimVisibleHeightTrigger = 0x00000010;
        public static int CollapsingToolbarLayout_statusBarScrim = 0x00000011;
        public static int CollapsingToolbarLayout_title = 0x00000012;
        public static int CollapsingToolbarLayout_titleCollapseMode = 0x00000013;
        public static int CollapsingToolbarLayout_titleEnabled = 0x00000014;
        public static int CollapsingToolbarLayout_titlePositionInterpolator = 0x00000015;
        public static int CollapsingToolbarLayout_titleTextEllipsize = 0x00000016;
        public static int CollapsingToolbarLayout_toolbarId = 0x00000017;
        public static int ColorStateListItem_alpha = 0x00000003;
        public static int ColorStateListItem_android_alpha = 0x00000001;
        public static int ColorStateListItem_android_color = 0x00000000;
        public static int ColorStateListItem_android_lStar = 0x00000002;
        public static int ColorStateListItem_lStar = 0x00000004;
        public static int CompoundButton_android_button = 0x00000000;
        public static int CompoundButton_buttonCompat = 0x00000001;
        public static int CompoundButton_buttonTint = 0x00000002;
        public static int CompoundButton_buttonTintMode = 0x00000003;
        public static int ConstraintLayout_Layout_android_elevation = 0x0000000d;
        public static int ConstraintLayout_Layout_android_maxHeight = 0x00000008;
        public static int ConstraintLayout_Layout_android_maxWidth = 0x00000007;
        public static int ConstraintLayout_Layout_android_minHeight = 0x0000000a;
        public static int ConstraintLayout_Layout_android_minWidth = 0x00000009;
        public static int ConstraintLayout_Layout_android_orientation = 0x00000000;
        public static int ConstraintLayout_Layout_android_padding = 0x00000001;
        public static int ConstraintLayout_Layout_android_paddingBottom = 0x00000005;
        public static int ConstraintLayout_Layout_android_paddingEnd = 0x0000000c;
        public static int ConstraintLayout_Layout_android_paddingLeft = 0x00000002;
        public static int ConstraintLayout_Layout_android_paddingRight = 0x00000004;
        public static int ConstraintLayout_Layout_android_paddingStart = 0x0000000b;
        public static int ConstraintLayout_Layout_android_paddingTop = 0x00000003;
        public static int ConstraintLayout_Layout_android_visibility = 0x00000006;
        public static int ConstraintLayout_Layout_barrierAllowsGoneWidgets = 0x0000000e;
        public static int ConstraintLayout_Layout_barrierDirection = 0x0000000f;
        public static int ConstraintLayout_Layout_barrierMargin = 0x00000010;
        public static int ConstraintLayout_Layout_chainUseRtl = 0x00000011;
        public static int ConstraintLayout_Layout_constraintSet = 0x00000012;
        public static int ConstraintLayout_Layout_constraint_referenced_ids = 0x00000013;
        public static int ConstraintLayout_Layout_flow_firstHorizontalBias = 0x00000014;
        public static int ConstraintLayout_Layout_flow_firstHorizontalStyle = 0x00000015;
        public static int ConstraintLayout_Layout_flow_firstVerticalBias = 0x00000016;
        public static int ConstraintLayout_Layout_flow_firstVerticalStyle = 0x00000017;
        public static int ConstraintLayout_Layout_flow_horizontalAlign = 0x00000018;
        public static int ConstraintLayout_Layout_flow_horizontalBias = 0x00000019;
        public static int ConstraintLayout_Layout_flow_horizontalGap = 0x0000001a;
        public static int ConstraintLayout_Layout_flow_horizontalStyle = 0x0000001b;
        public static int ConstraintLayout_Layout_flow_lastHorizontalBias = 0x0000001c;
        public static int ConstraintLayout_Layout_flow_lastHorizontalStyle = 0x0000001d;
        public static int ConstraintLayout_Layout_flow_lastVerticalBias = 0x0000001e;
        public static int ConstraintLayout_Layout_flow_lastVerticalStyle = 0x0000001f;
        public static int ConstraintLayout_Layout_flow_maxElementsWrap = 0x00000020;
        public static int ConstraintLayout_Layout_flow_verticalAlign = 0x00000021;
        public static int ConstraintLayout_Layout_flow_verticalBias = 0x00000022;
        public static int ConstraintLayout_Layout_flow_verticalGap = 0x00000023;
        public static int ConstraintLayout_Layout_flow_verticalStyle = 0x00000024;
        public static int ConstraintLayout_Layout_flow_wrapMode = 0x00000025;
        public static int ConstraintLayout_Layout_layoutDescription = 0x00000026;
        public static int ConstraintLayout_Layout_layout_constrainedHeight = 0x00000027;
        public static int ConstraintLayout_Layout_layout_constrainedWidth = 0x00000028;
        public static int ConstraintLayout_Layout_layout_constraintBaseline_creator = 0x00000029;
        public static int ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf = 0x0000002a;
        public static int ConstraintLayout_Layout_layout_constraintBottom_creator = 0x0000002b;
        public static int ConstraintLayout_Layout_layout_constraintBottom_toBottomOf = 0x0000002c;
        public static int ConstraintLayout_Layout_layout_constraintBottom_toTopOf = 0x0000002d;
        public static int ConstraintLayout_Layout_layout_constraintCircle = 0x0000002e;
        public static int ConstraintLayout_Layout_layout_constraintCircleAngle = 0x0000002f;
        public static int ConstraintLayout_Layout_layout_constraintCircleRadius = 0x00000030;
        public static int ConstraintLayout_Layout_layout_constraintDimensionRatio = 0x00000031;
        public static int ConstraintLayout_Layout_layout_constraintEnd_toEndOf = 0x00000032;
        public static int ConstraintLayout_Layout_layout_constraintEnd_toStartOf = 0x00000033;
        public static int ConstraintLayout_Layout_layout_constraintGuide_begin = 0x00000034;
        public static int ConstraintLayout_Layout_layout_constraintGuide_end = 0x00000035;
        public static int ConstraintLayout_Layout_layout_constraintGuide_percent = 0x00000036;
        public static int ConstraintLayout_Layout_layout_constraintHeight_default = 0x00000037;
        public static int ConstraintLayout_Layout_layout_constraintHeight_max = 0x00000038;
        public static int ConstraintLayout_Layout_layout_constraintHeight_min = 0x00000039;
        public static int ConstraintLayout_Layout_layout_constraintHeight_percent = 0x0000003a;
        public static int ConstraintLayout_Layout_layout_constraintHorizontal_bias = 0x0000003b;
        public static int ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle = 0x0000003c;
        public static int ConstraintLayout_Layout_layout_constraintHorizontal_weight = 0x0000003d;
        public static int ConstraintLayout_Layout_layout_constraintLeft_creator = 0x0000003e;
        public static int ConstraintLayout_Layout_layout_constraintLeft_toLeftOf = 0x0000003f;
        public static int ConstraintLayout_Layout_layout_constraintLeft_toRightOf = 0x00000040;
        public static int ConstraintLayout_Layout_layout_constraintRight_creator = 0x00000041;
        public static int ConstraintLayout_Layout_layout_constraintRight_toLeftOf = 0x00000042;
        public static int ConstraintLayout_Layout_layout_constraintRight_toRightOf = 0x00000043;
        public static int ConstraintLayout_Layout_layout_constraintStart_toEndOf = 0x00000044;
        public static int ConstraintLayout_Layout_layout_constraintStart_toStartOf = 0x00000045;
        public static int ConstraintLayout_Layout_layout_constraintTag = 0x00000046;
        public static int ConstraintLayout_Layout_layout_constraintTop_creator = 0x00000047;
        public static int ConstraintLayout_Layout_layout_constraintTop_toBottomOf = 0x00000048;
        public static int ConstraintLayout_Layout_layout_constraintTop_toTopOf = 0x00000049;
        public static int ConstraintLayout_Layout_layout_constraintVertical_bias = 0x0000004a;
        public static int ConstraintLayout_Layout_layout_constraintVertical_chainStyle = 0x0000004b;
        public static int ConstraintLayout_Layout_layout_constraintVertical_weight = 0x0000004c;
        public static int ConstraintLayout_Layout_layout_constraintWidth_default = 0x0000004d;
        public static int ConstraintLayout_Layout_layout_constraintWidth_max = 0x0000004e;
        public static int ConstraintLayout_Layout_layout_constraintWidth_min = 0x0000004f;
        public static int ConstraintLayout_Layout_layout_constraintWidth_percent = 0x00000050;
        public static int ConstraintLayout_Layout_layout_editor_absoluteX = 0x00000051;
        public static int ConstraintLayout_Layout_layout_editor_absoluteY = 0x00000052;
        public static int ConstraintLayout_Layout_layout_goneMarginBottom = 0x00000053;
        public static int ConstraintLayout_Layout_layout_goneMarginEnd = 0x00000054;
        public static int ConstraintLayout_Layout_layout_goneMarginLeft = 0x00000055;
        public static int ConstraintLayout_Layout_layout_goneMarginRight = 0x00000056;
        public static int ConstraintLayout_Layout_layout_goneMarginStart = 0x00000057;
        public static int ConstraintLayout_Layout_layout_goneMarginTop = 0x00000058;
        public static int ConstraintLayout_Layout_layout_optimizationLevel = 0x00000059;
        public static int ConstraintLayout_placeholder_content = 0x00000000;
        public static int ConstraintLayout_placeholder_placeholder_emptyVisibility = 0x00000001;
        public static int ConstraintSet_android_alpha = 0x0000000f;
        public static int ConstraintSet_android_elevation = 0x0000001c;
        public static int ConstraintSet_android_id = 0x00000001;
        public static int ConstraintSet_android_layout_height = 0x00000004;
        public static int ConstraintSet_android_layout_marginBottom = 0x00000008;
        public static int ConstraintSet_android_layout_marginEnd = 0x0000001a;
        public static int ConstraintSet_android_layout_marginLeft = 0x00000005;
        public static int ConstraintSet_android_layout_marginRight = 0x00000007;
        public static int ConstraintSet_android_layout_marginStart = 0x00000019;
        public static int ConstraintSet_android_layout_marginTop = 0x00000006;
        public static int ConstraintSet_android_layout_width = 0x00000003;
        public static int ConstraintSet_android_maxHeight = 0x0000000a;
        public static int ConstraintSet_android_maxWidth = 0x00000009;
        public static int ConstraintSet_android_minHeight = 0x0000000c;
        public static int ConstraintSet_android_minWidth = 0x0000000b;
        public static int ConstraintSet_android_orientation = 0x00000000;
        public static int ConstraintSet_android_pivotX = 0x0000000d;
        public static int ConstraintSet_android_pivotY = 0x0000000e;
        public static int ConstraintSet_android_rotation = 0x00000016;
        public static int ConstraintSet_android_rotationX = 0x00000017;
        public static int ConstraintSet_android_rotationY = 0x00000018;
        public static int ConstraintSet_android_scaleX = 0x00000014;
        public static int ConstraintSet_android_scaleY = 0x00000015;
        public static int ConstraintSet_android_transformPivotX = 0x00000010;
        public static int ConstraintSet_android_transformPivotY = 0x00000011;
        public static int ConstraintSet_android_translationX = 0x00000012;
        public static int ConstraintSet_android_translationY = 0x00000013;
        public static int ConstraintSet_android_translationZ = 0x0000001b;
        public static int ConstraintSet_android_visibility = 0x00000002;
        public static int ConstraintSet_animate_relativeTo = 0x0000001d;
        public static int ConstraintSet_barrierAllowsGoneWidgets = 0x0000001e;
        public static int ConstraintSet_barrierDirection = 0x0000001f;
        public static int ConstraintSet_barrierMargin = 0x00000020;
        public static int ConstraintSet_chainUseRtl = 0x00000021;
        public static int ConstraintSet_constraint_referenced_ids = 0x00000022;
        public static int ConstraintSet_deriveConstraintsFrom = 0x00000023;
        public static int ConstraintSet_drawPath = 0x00000024;
        public static int ConstraintSet_flow_firstHorizontalBias = 0x00000025;
        public static int ConstraintSet_flow_firstHorizontalStyle = 0x00000026;
        public static int ConstraintSet_flow_firstVerticalBias = 0x00000027;
        public static int ConstraintSet_flow_firstVerticalStyle = 0x00000028;
        public static int ConstraintSet_flow_horizontalAlign = 0x00000029;
        public static int ConstraintSet_flow_horizontalBias = 0x0000002a;
        public static int ConstraintSet_flow_horizontalGap = 0x0000002b;
        public static int ConstraintSet_flow_horizontalStyle = 0x0000002c;
        public static int ConstraintSet_flow_lastHorizontalBias = 0x0000002d;
        public static int ConstraintSet_flow_lastHorizontalStyle = 0x0000002e;
        public static int ConstraintSet_flow_lastVerticalBias = 0x0000002f;
        public static int ConstraintSet_flow_lastVerticalStyle = 0x00000030;
        public static int ConstraintSet_flow_maxElementsWrap = 0x00000031;
        public static int ConstraintSet_flow_verticalAlign = 0x00000032;
        public static int ConstraintSet_flow_verticalBias = 0x00000033;
        public static int ConstraintSet_flow_verticalGap = 0x00000034;
        public static int ConstraintSet_flow_verticalStyle = 0x00000035;
        public static int ConstraintSet_flow_wrapMode = 0x00000036;
        public static int ConstraintSet_layout_constrainedHeight = 0x00000037;
        public static int ConstraintSet_layout_constrainedWidth = 0x00000038;
        public static int ConstraintSet_layout_constraintBaseline_creator = 0x00000039;
        public static int ConstraintSet_layout_constraintBaseline_toBaselineOf = 0x0000003a;
        public static int ConstraintSet_layout_constraintBottom_creator = 0x0000003b;
        public static int ConstraintSet_layout_constraintBottom_toBottomOf = 0x0000003c;
        public static int ConstraintSet_layout_constraintBottom_toTopOf = 0x0000003d;
        public static int ConstraintSet_layout_constraintCircle = 0x0000003e;
        public static int ConstraintSet_layout_constraintCircleAngle = 0x0000003f;
        public static int ConstraintSet_layout_constraintCircleRadius = 0x00000040;
        public static int ConstraintSet_layout_constraintDimensionRatio = 0x00000041;
        public static int ConstraintSet_layout_constraintEnd_toEndOf = 0x00000042;
        public static int ConstraintSet_layout_constraintEnd_toStartOf = 0x00000043;
        public static int ConstraintSet_layout_constraintGuide_begin = 0x00000044;
        public static int ConstraintSet_layout_constraintGuide_end = 0x00000045;
        public static int ConstraintSet_layout_constraintGuide_percent = 0x00000046;
        public static int ConstraintSet_layout_constraintHeight_default = 0x00000047;
        public static int ConstraintSet_layout_constraintHeight_max = 0x00000048;
        public static int ConstraintSet_layout_constraintHeight_min = 0x00000049;
        public static int ConstraintSet_layout_constraintHeight_percent = 0x0000004a;
        public static int ConstraintSet_layout_constraintHorizontal_bias = 0x0000004b;
        public static int ConstraintSet_layout_constraintHorizontal_chainStyle = 0x0000004c;
        public static int ConstraintSet_layout_constraintHorizontal_weight = 0x0000004d;
        public static int ConstraintSet_layout_constraintLeft_creator = 0x0000004e;
        public static int ConstraintSet_layout_constraintLeft_toLeftOf = 0x0000004f;
        public static int ConstraintSet_layout_constraintLeft_toRightOf = 0x00000050;
        public static int ConstraintSet_layout_constraintRight_creator = 0x00000051;
        public static int ConstraintSet_layout_constraintRight_toLeftOf = 0x00000052;
        public static int ConstraintSet_layout_constraintRight_toRightOf = 0x00000053;
        public static int ConstraintSet_layout_constraintStart_toEndOf = 0x00000054;
        public static int ConstraintSet_layout_constraintStart_toStartOf = 0x00000055;
        public static int ConstraintSet_layout_constraintTag = 0x00000056;
        public static int ConstraintSet_layout_constraintTop_creator = 0x00000057;
        public static int ConstraintSet_layout_constraintTop_toBottomOf = 0x00000058;
        public static int ConstraintSet_layout_constraintTop_toTopOf = 0x00000059;
        public static int ConstraintSet_layout_constraintVertical_bias = 0x0000005a;
        public static int ConstraintSet_layout_constraintVertical_chainStyle = 0x0000005b;
        public static int ConstraintSet_layout_constraintVertical_weight = 0x0000005c;
        public static int ConstraintSet_layout_constraintWidth_default = 0x0000005d;
        public static int ConstraintSet_layout_constraintWidth_max = 0x0000005e;
        public static int ConstraintSet_layout_constraintWidth_min = 0x0000005f;
        public static int ConstraintSet_layout_constraintWidth_percent = 0x00000060;
        public static int ConstraintSet_layout_editor_absoluteX = 0x00000061;
        public static int ConstraintSet_layout_editor_absoluteY = 0x00000062;
        public static int ConstraintSet_layout_goneMarginBottom = 0x00000063;
        public static int ConstraintSet_layout_goneMarginEnd = 0x00000064;
        public static int ConstraintSet_layout_goneMarginLeft = 0x00000065;
        public static int ConstraintSet_layout_goneMarginRight = 0x00000066;
        public static int ConstraintSet_layout_goneMarginStart = 0x00000067;
        public static int ConstraintSet_layout_goneMarginTop = 0x00000068;
        public static int ConstraintSet_motionProgress = 0x00000069;
        public static int ConstraintSet_motionStagger = 0x0000006a;
        public static int ConstraintSet_pathMotionArc = 0x0000006b;
        public static int ConstraintSet_pivotAnchor = 0x0000006c;
        public static int ConstraintSet_transitionEasing = 0x0000006d;
        public static int ConstraintSet_transitionPathRotate = 0x0000006e;
        public static int Constraint_android_alpha = 0x0000000d;
        public static int Constraint_android_elevation = 0x0000001a;
        public static int Constraint_android_id = 0x00000001;
        public static int Constraint_android_layout_height = 0x00000004;
        public static int Constraint_android_layout_marginBottom = 0x00000008;
        public static int Constraint_android_layout_marginEnd = 0x00000018;
        public static int Constraint_android_layout_marginLeft = 0x00000005;
        public static int Constraint_android_layout_marginRight = 0x00000007;
        public static int Constraint_android_layout_marginStart = 0x00000017;
        public static int Constraint_android_layout_marginTop = 0x00000006;
        public static int Constraint_android_layout_width = 0x00000003;
        public static int Constraint_android_maxHeight = 0x0000000a;
        public static int Constraint_android_maxWidth = 0x00000009;
        public static int Constraint_android_minHeight = 0x0000000c;
        public static int Constraint_android_minWidth = 0x0000000b;
        public static int Constraint_android_orientation = 0x00000000;
        public static int Constraint_android_rotation = 0x00000014;
        public static int Constraint_android_rotationX = 0x00000015;
        public static int Constraint_android_rotationY = 0x00000016;
        public static int Constraint_android_scaleX = 0x00000012;
        public static int Constraint_android_scaleY = 0x00000013;
        public static int Constraint_android_transformPivotX = 0x0000000e;
        public static int Constraint_android_transformPivotY = 0x0000000f;
        public static int Constraint_android_translationX = 0x00000010;
        public static int Constraint_android_translationY = 0x00000011;
        public static int Constraint_android_translationZ = 0x00000019;
        public static int Constraint_android_visibility = 0x00000002;
        public static int Constraint_animate_relativeTo = 0x0000001b;
        public static int Constraint_barrierAllowsGoneWidgets = 0x0000001c;
        public static int Constraint_barrierDirection = 0x0000001d;
        public static int Constraint_barrierMargin = 0x0000001e;
        public static int Constraint_chainUseRtl = 0x0000001f;
        public static int Constraint_constraint_referenced_ids = 0x00000020;
        public static int Constraint_drawPath = 0x00000021;
        public static int Constraint_flow_firstHorizontalBias = 0x00000022;
        public static int Constraint_flow_firstHorizontalStyle = 0x00000023;
        public static int Constraint_flow_firstVerticalBias = 0x00000024;
        public static int Constraint_flow_firstVerticalStyle = 0x00000025;
        public static int Constraint_flow_horizontalAlign = 0x00000026;
        public static int Constraint_flow_horizontalBias = 0x00000027;
        public static int Constraint_flow_horizontalGap = 0x00000028;
        public static int Constraint_flow_horizontalStyle = 0x00000029;
        public static int Constraint_flow_lastHorizontalBias = 0x0000002a;
        public static int Constraint_flow_lastHorizontalStyle = 0x0000002b;
        public static int Constraint_flow_lastVerticalBias = 0x0000002c;
        public static int Constraint_flow_lastVerticalStyle = 0x0000002d;
        public static int Constraint_flow_maxElementsWrap = 0x0000002e;
        public static int Constraint_flow_verticalAlign = 0x0000002f;
        public static int Constraint_flow_verticalBias = 0x00000030;
        public static int Constraint_flow_verticalGap = 0x00000031;
        public static int Constraint_flow_verticalStyle = 0x00000032;
        public static int Constraint_flow_wrapMode = 0x00000033;
        public static int Constraint_layout_constrainedHeight = 0x00000034;
        public static int Constraint_layout_constrainedWidth = 0x00000035;
        public static int Constraint_layout_constraintBaseline_creator = 0x00000036;
        public static int Constraint_layout_constraintBaseline_toBaselineOf = 0x00000037;
        public static int Constraint_layout_constraintBottom_creator = 0x00000038;
        public static int Constraint_layout_constraintBottom_toBottomOf = 0x00000039;
        public static int Constraint_layout_constraintBottom_toTopOf = 0x0000003a;
        public static int Constraint_layout_constraintCircle = 0x0000003b;
        public static int Constraint_layout_constraintCircleAngle = 0x0000003c;
        public static int Constraint_layout_constraintCircleRadius = 0x0000003d;
        public static int Constraint_layout_constraintDimensionRatio = 0x0000003e;
        public static int Constraint_layout_constraintEnd_toEndOf = 0x0000003f;
        public static int Constraint_layout_constraintEnd_toStartOf = 0x00000040;
        public static int Constraint_layout_constraintGuide_begin = 0x00000041;
        public static int Constraint_layout_constraintGuide_end = 0x00000042;
        public static int Constraint_layout_constraintGuide_percent = 0x00000043;
        public static int Constraint_layout_constraintHeight_default = 0x00000044;
        public static int Constraint_layout_constraintHeight_max = 0x00000045;
        public static int Constraint_layout_constraintHeight_min = 0x00000046;
        public static int Constraint_layout_constraintHeight_percent = 0x00000047;
        public static int Constraint_layout_constraintHorizontal_bias = 0x00000048;
        public static int Constraint_layout_constraintHorizontal_chainStyle = 0x00000049;
        public static int Constraint_layout_constraintHorizontal_weight = 0x0000004a;
        public static int Constraint_layout_constraintLeft_creator = 0x0000004b;
        public static int Constraint_layout_constraintLeft_toLeftOf = 0x0000004c;
        public static int Constraint_layout_constraintLeft_toRightOf = 0x0000004d;
        public static int Constraint_layout_constraintRight_creator = 0x0000004e;
        public static int Constraint_layout_constraintRight_toLeftOf = 0x0000004f;
        public static int Constraint_layout_constraintRight_toRightOf = 0x00000050;
        public static int Constraint_layout_constraintStart_toEndOf = 0x00000051;
        public static int Constraint_layout_constraintStart_toStartOf = 0x00000052;
        public static int Constraint_layout_constraintTag = 0x00000053;
        public static int Constraint_layout_constraintTop_creator = 0x00000054;
        public static int Constraint_layout_constraintTop_toBottomOf = 0x00000055;
        public static int Constraint_layout_constraintTop_toTopOf = 0x00000056;
        public static int Constraint_layout_constraintVertical_bias = 0x00000057;
        public static int Constraint_layout_constraintVertical_chainStyle = 0x00000058;
        public static int Constraint_layout_constraintVertical_weight = 0x00000059;
        public static int Constraint_layout_constraintWidth_default = 0x0000005a;
        public static int Constraint_layout_constraintWidth_max = 0x0000005b;
        public static int Constraint_layout_constraintWidth_min = 0x0000005c;
        public static int Constraint_layout_constraintWidth_percent = 0x0000005d;
        public static int Constraint_layout_editor_absoluteX = 0x0000005e;
        public static int Constraint_layout_editor_absoluteY = 0x0000005f;
        public static int Constraint_layout_goneMarginBottom = 0x00000060;
        public static int Constraint_layout_goneMarginEnd = 0x00000061;
        public static int Constraint_layout_goneMarginLeft = 0x00000062;
        public static int Constraint_layout_goneMarginRight = 0x00000063;
        public static int Constraint_layout_goneMarginStart = 0x00000064;
        public static int Constraint_layout_goneMarginTop = 0x00000065;
        public static int Constraint_motionProgress = 0x00000066;
        public static int Constraint_motionStagger = 0x00000067;
        public static int Constraint_pathMotionArc = 0x00000068;
        public static int Constraint_pivotAnchor = 0x00000069;
        public static int Constraint_transitionEasing = 0x0000006a;
        public static int Constraint_transitionPathRotate = 0x0000006b;
        public static int Constraint_visibilityMode = 0x0000006c;
        public static int CoordinatorLayout_Layout_android_layout_gravity = 0x00000000;
        public static int CoordinatorLayout_Layout_layout_anchor = 0x00000001;
        public static int CoordinatorLayout_Layout_layout_anchorGravity = 0x00000002;
        public static int CoordinatorLayout_Layout_layout_behavior = 0x00000003;
        public static int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 0x00000004;
        public static int CoordinatorLayout_Layout_layout_insetEdge = 0x00000005;
        public static int CoordinatorLayout_Layout_layout_keyline = 0x00000006;
        public static int CoordinatorLayout_keylines = 0x00000000;
        public static int CoordinatorLayout_statusBarBackground = 0x00000001;
        public static int CustomAttribute_attributeName = 0x00000000;
        public static int CustomAttribute_customBoolean = 0x00000001;
        public static int CustomAttribute_customColorDrawableValue = 0x00000002;
        public static int CustomAttribute_customColorValue = 0x00000003;
        public static int CustomAttribute_customDimension = 0x00000004;
        public static int CustomAttribute_customFloatValue = 0x00000005;
        public static int CustomAttribute_customIntegerValue = 0x00000006;
        public static int CustomAttribute_customPixelDimension = 0x00000007;
        public static int CustomAttribute_customStringValue = 0x00000008;
        public static int DrawerArrowToggle_arrowHeadLength = 0x00000000;
        public static int DrawerArrowToggle_arrowShaftLength = 0x00000001;
        public static int DrawerArrowToggle_barLength = 0x00000002;
        public static int DrawerArrowToggle_color = 0x00000003;
        public static int DrawerArrowToggle_drawableSize = 0x00000004;
        public static int DrawerArrowToggle_gapBetweenBars = 0x00000005;
        public static int DrawerArrowToggle_spinBars = 0x00000006;
        public static int DrawerArrowToggle_thickness = 0x00000007;
        public static int DrawerLayout_elevation = 0x00000000;
        public static int ExtendedFloatingActionButton_Behavior_Layout_behavior_autoHide = 0x00000000;
        public static int ExtendedFloatingActionButton_Behavior_Layout_behavior_autoShrink = 0x00000001;
        public static int ExtendedFloatingActionButton_collapsedSize = 0x00000000;
        public static int ExtendedFloatingActionButton_elevation = 0x00000001;
        public static int ExtendedFloatingActionButton_extendMotionSpec = 0x00000002;
        public static int ExtendedFloatingActionButton_extendStrategy = 0x00000003;
        public static int ExtendedFloatingActionButton_hideMotionSpec = 0x00000004;
        public static int ExtendedFloatingActionButton_showMotionSpec = 0x00000005;
        public static int ExtendedFloatingActionButton_shrinkMotionSpec = 0x00000006;
        public static int FloatingActionButton_Behavior_Layout_behavior_autoHide = 0x00000000;
        public static int FloatingActionButton_android_enabled = 0x00000000;
        public static int FloatingActionButton_backgroundTint = 0x00000001;
        public static int FloatingActionButton_backgroundTintMode = 0x00000002;
        public static int FloatingActionButton_borderWidth = 0x00000003;
        public static int FloatingActionButton_elevation = 0x00000004;
        public static int FloatingActionButton_ensureMinTouchTargetSize = 0x00000005;
        public static int FloatingActionButton_fabCustomSize = 0x00000006;
        public static int FloatingActionButton_fabSize = 0x00000007;
        public static int FloatingActionButton_hideMotionSpec = 0x00000008;
        public static int FloatingActionButton_hoveredFocusedTranslationZ = 0x00000009;
        public static int FloatingActionButton_maxImageSize = 0x0000000a;
        public static int FloatingActionButton_pressedTranslationZ = 0x0000000b;
        public static int FloatingActionButton_rippleColor = 0x0000000c;
        public static int FloatingActionButton_shapeAppearance = 0x0000000d;
        public static int FloatingActionButton_shapeAppearanceOverlay = 0x0000000e;
        public static int FloatingActionButton_showMotionSpec = 0x0000000f;
        public static int FloatingActionButton_useCompatPadding = 0x00000010;
        public static int FlowLayout_itemSpacing = 0x00000000;
        public static int FlowLayout_lineSpacing = 0x00000001;
        public static int FontFamilyFont_android_font = 0x00000000;
        public static int FontFamilyFont_android_fontStyle = 0x00000002;
        public static int FontFamilyFont_android_fontVariationSettings = 0x00000004;
        public static int FontFamilyFont_android_fontWeight = 0x00000001;
        public static int FontFamilyFont_android_ttcIndex = 0x00000003;
        public static int FontFamilyFont_font = 0x00000005;
        public static int FontFamilyFont_fontStyle = 0x00000006;
        public static int FontFamilyFont_fontVariationSettings = 0x00000007;
        public static int FontFamilyFont_fontWeight = 0x00000008;
        public static int FontFamilyFont_ttcIndex = 0x00000009;
        public static int FontFamily_fontProviderAuthority = 0x00000000;
        public static int FontFamily_fontProviderCerts = 0x00000001;
        public static int FontFamily_fontProviderFetchStrategy = 0x00000002;
        public static int FontFamily_fontProviderFetchTimeout = 0x00000003;
        public static int FontFamily_fontProviderPackage = 0x00000004;
        public static int FontFamily_fontProviderQuery = 0x00000005;
        public static int FontFamily_fontProviderSystemFontFamily = 0x00000006;
        public static int ForegroundLinearLayout_android_foreground = 0x00000000;
        public static int ForegroundLinearLayout_android_foregroundGravity = 0x00000001;
        public static int ForegroundLinearLayout_foregroundInsidePadding = 0x00000002;
        public static int FragmentContainerView_android_name = 0x00000000;
        public static int FragmentContainerView_android_tag = 0x00000001;
        public static int Fragment_android_id = 0x00000001;
        public static int Fragment_android_name = 0x00000000;
        public static int Fragment_android_tag = 0x00000002;
        public static int GradientColorItem_android_color = 0x00000000;
        public static int GradientColorItem_android_offset = 0x00000001;
        public static int GradientColor_android_centerColor = 0x00000007;
        public static int GradientColor_android_centerX = 0x00000003;
        public static int GradientColor_android_centerY = 0x00000004;
        public static int GradientColor_android_endColor = 0x00000001;
        public static int GradientColor_android_endX = 0x0000000a;
        public static int GradientColor_android_endY = 0x0000000b;
        public static int GradientColor_android_gradientRadius = 0x00000005;
        public static int GradientColor_android_startColor = 0x00000000;
        public static int GradientColor_android_startX = 0x00000008;
        public static int GradientColor_android_startY = 0x00000009;
        public static int GradientColor_android_tileMode = 0x00000006;
        public static int GradientColor_android_type = 0x00000002;
        public static int ImageFilterView_altSrc = 0x00000000;
        public static int ImageFilterView_brightness = 0x00000001;
        public static int ImageFilterView_contrast = 0x00000002;
        public static int ImageFilterView_crossfade = 0x00000003;
        public static int ImageFilterView_overlay = 0x00000004;
        public static int ImageFilterView_round = 0x00000005;
        public static int ImageFilterView_roundPercent = 0x00000006;
        public static int ImageFilterView_saturation = 0x00000007;
        public static int ImageFilterView_warmth = 0x00000008;
        public static int Insets_marginLeftSystemWindowInsets = 0x00000000;
        public static int Insets_marginRightSystemWindowInsets = 0x00000001;
        public static int Insets_marginTopSystemWindowInsets = 0x00000002;
        public static int Insets_paddingBottomSystemWindowInsets = 0x00000003;
        public static int Insets_paddingLeftSystemWindowInsets = 0x00000004;
        public static int Insets_paddingRightSystemWindowInsets = 0x00000005;
        public static int Insets_paddingStartSystemWindowInsets = 0x00000006;
        public static int Insets_paddingTopSystemWindowInsets = 0x00000007;
        public static int KeyAttribute_android_alpha = 0x00000000;
        public static int KeyAttribute_android_elevation = 0x0000000b;
        public static int KeyAttribute_android_rotation = 0x00000007;
        public static int KeyAttribute_android_rotationX = 0x00000008;
        public static int KeyAttribute_android_rotationY = 0x00000009;
        public static int KeyAttribute_android_scaleX = 0x00000005;
        public static int KeyAttribute_android_scaleY = 0x00000006;
        public static int KeyAttribute_android_transformPivotX = 0x00000001;
        public static int KeyAttribute_android_transformPivotY = 0x00000002;
        public static int KeyAttribute_android_translationX = 0x00000003;
        public static int KeyAttribute_android_translationY = 0x00000004;
        public static int KeyAttribute_android_translationZ = 0x0000000a;
        public static int KeyAttribute_curveFit = 0x0000000c;
        public static int KeyAttribute_framePosition = 0x0000000d;
        public static int KeyAttribute_motionProgress = 0x0000000e;
        public static int KeyAttribute_motionTarget = 0x0000000f;
        public static int KeyAttribute_transitionEasing = 0x00000010;
        public static int KeyAttribute_transitionPathRotate = 0x00000011;
        public static int KeyCycle_android_alpha = 0x00000000;
        public static int KeyCycle_android_elevation = 0x00000009;
        public static int KeyCycle_android_rotation = 0x00000005;
        public static int KeyCycle_android_rotationX = 0x00000006;
        public static int KeyCycle_android_rotationY = 0x00000007;
        public static int KeyCycle_android_scaleX = 0x00000003;
        public static int KeyCycle_android_scaleY = 0x00000004;
        public static int KeyCycle_android_translationX = 0x00000001;
        public static int KeyCycle_android_translationY = 0x00000002;
        public static int KeyCycle_android_translationZ = 0x00000008;
        public static int KeyCycle_curveFit = 0x0000000a;
        public static int KeyCycle_framePosition = 0x0000000b;
        public static int KeyCycle_motionProgress = 0x0000000c;
        public static int KeyCycle_motionTarget = 0x0000000d;
        public static int KeyCycle_transitionEasing = 0x0000000e;
        public static int KeyCycle_transitionPathRotate = 0x0000000f;
        public static int KeyCycle_waveOffset = 0x00000010;
        public static int KeyCycle_wavePeriod = 0x00000011;
        public static int KeyCycle_waveShape = 0x00000012;
        public static int KeyCycle_waveVariesBy = 0x00000013;
        public static int KeyPosition_curveFit = 0x00000000;
        public static int KeyPosition_drawPath = 0x00000001;
        public static int KeyPosition_framePosition = 0x00000002;
        public static int KeyPosition_keyPositionType = 0x00000003;
        public static int KeyPosition_motionTarget = 0x00000004;
        public static int KeyPosition_pathMotionArc = 0x00000005;
        public static int KeyPosition_percentHeight = 0x00000006;
        public static int KeyPosition_percentWidth = 0x00000007;
        public static int KeyPosition_percentX = 0x00000008;
        public static int KeyPosition_percentY = 0x00000009;
        public static int KeyPosition_sizePercent = 0x0000000a;
        public static int KeyPosition_transitionEasing = 0x0000000b;
        public static int KeyTimeCycle_android_alpha = 0x00000000;
        public static int KeyTimeCycle_android_elevation = 0x00000009;
        public static int KeyTimeCycle_android_rotation = 0x00000005;
        public static int KeyTimeCycle_android_rotationX = 0x00000006;
        public static int KeyTimeCycle_android_rotationY = 0x00000007;
        public static int KeyTimeCycle_android_scaleX = 0x00000003;
        public static int KeyTimeCycle_android_scaleY = 0x00000004;
        public static int KeyTimeCycle_android_translationX = 0x00000001;
        public static int KeyTimeCycle_android_translationY = 0x00000002;
        public static int KeyTimeCycle_android_translationZ = 0x00000008;
        public static int KeyTimeCycle_curveFit = 0x0000000a;
        public static int KeyTimeCycle_framePosition = 0x0000000b;
        public static int KeyTimeCycle_motionProgress = 0x0000000c;
        public static int KeyTimeCycle_motionTarget = 0x0000000d;
        public static int KeyTimeCycle_transitionEasing = 0x0000000e;
        public static int KeyTimeCycle_transitionPathRotate = 0x0000000f;
        public static int KeyTimeCycle_waveDecay = 0x00000010;
        public static int KeyTimeCycle_waveOffset = 0x00000011;
        public static int KeyTimeCycle_wavePeriod = 0x00000012;
        public static int KeyTimeCycle_waveShape = 0x00000013;
        public static int KeyTrigger_framePosition = 0x00000000;
        public static int KeyTrigger_motionTarget = 0x00000001;
        public static int KeyTrigger_motion_postLayoutCollision = 0x00000002;
        public static int KeyTrigger_motion_triggerOnCollision = 0x00000003;
        public static int KeyTrigger_onCross = 0x00000004;
        public static int KeyTrigger_onNegativeCross = 0x00000005;
        public static int KeyTrigger_onPositiveCross = 0x00000006;
        public static int KeyTrigger_triggerId = 0x00000007;
        public static int KeyTrigger_triggerReceiver = 0x00000008;
        public static int KeyTrigger_triggerSlack = 0x00000009;
        public static int Layout_android_layout_height = 0x00000002;
        public static int Layout_android_layout_marginBottom = 0x00000006;
        public static int Layout_android_layout_marginEnd = 0x00000008;
        public static int Layout_android_layout_marginLeft = 0x00000003;
        public static int Layout_android_layout_marginRight = 0x00000005;
        public static int Layout_android_layout_marginStart = 0x00000007;
        public static int Layout_android_layout_marginTop = 0x00000004;
        public static int Layout_android_layout_width = 0x00000001;
        public static int Layout_android_orientation = 0x00000000;
        public static int Layout_barrierAllowsGoneWidgets = 0x00000009;
        public static int Layout_barrierDirection = 0x0000000a;
        public static int Layout_barrierMargin = 0x0000000b;
        public static int Layout_chainUseRtl = 0x0000000c;
        public static int Layout_constraint_referenced_ids = 0x0000000d;
        public static int Layout_layout_constrainedHeight = 0x0000000e;
        public static int Layout_layout_constrainedWidth = 0x0000000f;
        public static int Layout_layout_constraintBaseline_creator = 0x00000010;
        public static int Layout_layout_constraintBaseline_toBaselineOf = 0x00000011;
        public static int Layout_layout_constraintBottom_creator = 0x00000012;
        public static int Layout_layout_constraintBottom_toBottomOf = 0x00000013;
        public static int Layout_layout_constraintBottom_toTopOf = 0x00000014;
        public static int Layout_layout_constraintCircle = 0x00000015;
        public static int Layout_layout_constraintCircleAngle = 0x00000016;
        public static int Layout_layout_constraintCircleRadius = 0x00000017;
        public static int Layout_layout_constraintDimensionRatio = 0x00000018;
        public static int Layout_layout_constraintEnd_toEndOf = 0x00000019;
        public static int Layout_layout_constraintEnd_toStartOf = 0x0000001a;
        public static int Layout_layout_constraintGuide_begin = 0x0000001b;
        public static int Layout_layout_constraintGuide_end = 0x0000001c;
        public static int Layout_layout_constraintGuide_percent = 0x0000001d;
        public static int Layout_layout_constraintHeight_default = 0x0000001e;
        public static int Layout_layout_constraintHeight_max = 0x0000001f;
        public static int Layout_layout_constraintHeight_min = 0x00000020;
        public static int Layout_layout_constraintHeight_percent = 0x00000021;
        public static int Layout_layout_constraintHorizontal_bias = 0x00000022;
        public static int Layout_layout_constraintHorizontal_chainStyle = 0x00000023;
        public static int Layout_layout_constraintHorizontal_weight = 0x00000024;
        public static int Layout_layout_constraintLeft_creator = 0x00000025;
        public static int Layout_layout_constraintLeft_toLeftOf = 0x00000026;
        public static int Layout_layout_constraintLeft_toRightOf = 0x00000027;
        public static int Layout_layout_constraintRight_creator = 0x00000028;
        public static int Layout_layout_constraintRight_toLeftOf = 0x00000029;
        public static int Layout_layout_constraintRight_toRightOf = 0x0000002a;
        public static int Layout_layout_constraintStart_toEndOf = 0x0000002b;
        public static int Layout_layout_constraintStart_toStartOf = 0x0000002c;
        public static int Layout_layout_constraintTop_creator = 0x0000002d;
        public static int Layout_layout_constraintTop_toBottomOf = 0x0000002e;
        public static int Layout_layout_constraintTop_toTopOf = 0x0000002f;
        public static int Layout_layout_constraintVertical_bias = 0x00000030;
        public static int Layout_layout_constraintVertical_chainStyle = 0x00000031;
        public static int Layout_layout_constraintVertical_weight = 0x00000032;
        public static int Layout_layout_constraintWidth_default = 0x00000033;
        public static int Layout_layout_constraintWidth_max = 0x00000034;
        public static int Layout_layout_constraintWidth_min = 0x00000035;
        public static int Layout_layout_constraintWidth_percent = 0x00000036;
        public static int Layout_layout_editor_absoluteX = 0x00000037;
        public static int Layout_layout_editor_absoluteY = 0x00000038;
        public static int Layout_layout_goneMarginBottom = 0x00000039;
        public static int Layout_layout_goneMarginEnd = 0x0000003a;
        public static int Layout_layout_goneMarginLeft = 0x0000003b;
        public static int Layout_layout_goneMarginRight = 0x0000003c;
        public static int Layout_layout_goneMarginStart = 0x0000003d;
        public static int Layout_layout_goneMarginTop = 0x0000003e;
        public static int Layout_maxHeight = 0x0000003f;
        public static int Layout_maxWidth = 0x00000040;
        public static int Layout_minHeight = 0x00000041;
        public static int Layout_minWidth = 0x00000042;
        public static int LinearLayoutCompat_Layout_android_layout_gravity = 0x00000000;
        public static int LinearLayoutCompat_Layout_android_layout_height = 0x00000002;
        public static int LinearLayoutCompat_Layout_android_layout_weight = 0x00000003;
        public static int LinearLayoutCompat_Layout_android_layout_width = 0x00000001;
        public static int LinearLayoutCompat_android_baselineAligned = 0x00000002;
        public static int LinearLayoutCompat_android_baselineAlignedChildIndex = 0x00000003;
        public static int LinearLayoutCompat_android_gravity = 0x00000000;
        public static int LinearLayoutCompat_android_orientation = 0x00000001;
        public static int LinearLayoutCompat_android_weightSum = 0x00000004;
        public static int LinearLayoutCompat_divider = 0x00000005;
        public static int LinearLayoutCompat_dividerPadding = 0x00000006;
        public static int LinearLayoutCompat_measureWithLargestChild = 0x00000007;
        public static int LinearLayoutCompat_showDividers = 0x00000008;
        public static int LinearProgressIndicator_indeterminateAnimationType = 0x00000000;
        public static int LinearProgressIndicator_indicatorDirectionLinear = 0x00000001;
        public static int LinearProgressIndicator_trackStopIndicatorSize = 0x00000002;
        public static int ListPopupWindow_android_dropDownHorizontalOffset = 0x00000000;
        public static int ListPopupWindow_android_dropDownVerticalOffset = 0x00000001;
        public static int MaterialAlertDialogTheme_materialAlertDialogBodyTextStyle = 0x00000000;
        public static int MaterialAlertDialogTheme_materialAlertDialogButtonSpacerVisibility = 0x00000001;
        public static int MaterialAlertDialogTheme_materialAlertDialogTheme = 0x00000002;
        public static int MaterialAlertDialogTheme_materialAlertDialogTitleIconStyle = 0x00000003;
        public static int MaterialAlertDialogTheme_materialAlertDialogTitlePanelStyle = 0x00000004;
        public static int MaterialAlertDialogTheme_materialAlertDialogTitleTextStyle = 0x00000005;
        public static int MaterialAlertDialog_backgroundInsetBottom = 0x00000000;
        public static int MaterialAlertDialog_backgroundInsetEnd = 0x00000001;
        public static int MaterialAlertDialog_backgroundInsetStart = 0x00000002;
        public static int MaterialAlertDialog_backgroundInsetTop = 0x00000003;
        public static int MaterialAlertDialog_backgroundTint = 0x00000004;
        public static int MaterialAutoCompleteTextView_android_inputType = 0x00000000;
        public static int MaterialAutoCompleteTextView_android_popupElevation = 0x00000001;
        public static int MaterialAutoCompleteTextView_dropDownBackgroundTint = 0x00000002;
        public static int MaterialAutoCompleteTextView_simpleItemLayout = 0x00000003;
        public static int MaterialAutoCompleteTextView_simpleItemSelectedColor = 0x00000004;
        public static int MaterialAutoCompleteTextView_simpleItemSelectedRippleColor = 0x00000005;
        public static int MaterialAutoCompleteTextView_simpleItems = 0x00000006;
        public static int MaterialButtonToggleGroup_android_enabled = 0x00000000;
        public static int MaterialButtonToggleGroup_checkedButton = 0x00000001;
        public static int MaterialButtonToggleGroup_selectionRequired = 0x00000002;
        public static int MaterialButtonToggleGroup_singleSelection = 0x00000003;
        public static int MaterialButton_android_background = 0x00000000;
        public static int MaterialButton_android_checkable = 0x00000005;
        public static int MaterialButton_android_insetBottom = 0x00000004;
        public static int MaterialButton_android_insetLeft = 0x00000001;
        public static int MaterialButton_android_insetRight = 0x00000002;
        public static int MaterialButton_android_insetTop = 0x00000003;
        public static int MaterialButton_backgroundTint = 0x00000006;
        public static int MaterialButton_backgroundTintMode = 0x00000007;
        public static int MaterialButton_cornerRadius = 0x00000008;
        public static int MaterialButton_elevation = 0x00000009;
        public static int MaterialButton_icon = 0x0000000a;
        public static int MaterialButton_iconGravity = 0x0000000b;
        public static int MaterialButton_iconPadding = 0x0000000c;
        public static int MaterialButton_iconSize = 0x0000000d;
        public static int MaterialButton_iconTint = 0x0000000e;
        public static int MaterialButton_iconTintMode = 0x0000000f;
        public static int MaterialButton_rippleColor = 0x00000010;
        public static int MaterialButton_shapeAppearance = 0x00000011;
        public static int MaterialButton_shapeAppearanceOverlay = 0x00000012;
        public static int MaterialButton_strokeColor = 0x00000013;
        public static int MaterialButton_strokeWidth = 0x00000014;
        public static int MaterialButton_toggleCheckedStateOnClick = 0x00000015;
        public static int MaterialCalendarItem_android_insetBottom = 0x00000003;
        public static int MaterialCalendarItem_android_insetLeft = 0x00000000;
        public static int MaterialCalendarItem_android_insetRight = 0x00000001;
        public static int MaterialCalendarItem_android_insetTop = 0x00000002;
        public static int MaterialCalendarItem_itemFillColor = 0x00000004;
        public static int MaterialCalendarItem_itemShapeAppearance = 0x00000005;
        public static int MaterialCalendarItem_itemShapeAppearanceOverlay = 0x00000006;
        public static int MaterialCalendarItem_itemStrokeColor = 0x00000007;
        public static int MaterialCalendarItem_itemStrokeWidth = 0x00000008;
        public static int MaterialCalendarItem_itemTextColor = 0x00000009;
        public static int MaterialCalendar_android_windowFullscreen = 0x00000000;
        public static int MaterialCalendar_backgroundTint = 0x00000001;
        public static int MaterialCalendar_dayInvalidStyle = 0x00000002;
        public static int MaterialCalendar_daySelectedStyle = 0x00000003;
        public static int MaterialCalendar_dayStyle = 0x00000004;
        public static int MaterialCalendar_dayTodayStyle = 0x00000005;
        public static int MaterialCalendar_nestedScrollable = 0x00000006;
        public static int MaterialCalendar_rangeFillColor = 0x00000007;
        public static int MaterialCalendar_yearSelectedStyle = 0x00000008;
        public static int MaterialCalendar_yearStyle = 0x00000009;
        public static int MaterialCalendar_yearTodayStyle = 0x0000000a;
        public static int MaterialCardView_android_checkable = 0x00000000;
        public static int MaterialCardView_cardForegroundColor = 0x00000001;
        public static int MaterialCardView_checkedIcon = 0x00000002;
        public static int MaterialCardView_checkedIconGravity = 0x00000003;
        public static int MaterialCardView_checkedIconMargin = 0x00000004;
        public static int MaterialCardView_checkedIconSize = 0x00000005;
        public static int MaterialCardView_checkedIconTint = 0x00000006;
        public static int MaterialCardView_rippleColor = 0x00000007;
        public static int MaterialCardView_shapeAppearance = 0x00000008;
        public static int MaterialCardView_shapeAppearanceOverlay = 0x00000009;
        public static int MaterialCardView_state_dragged = 0x0000000a;
        public static int MaterialCardView_strokeColor = 0x0000000b;
        public static int MaterialCardView_strokeWidth = 0x0000000c;
        public static int MaterialCheckBoxStates_state_error = 0x00000000;
        public static int MaterialCheckBoxStates_state_indeterminate = 0x00000001;
        public static int MaterialCheckBox_android_button = 0x00000000;
        public static int MaterialCheckBox_buttonCompat = 0x00000001;
        public static int MaterialCheckBox_buttonIcon = 0x00000002;
        public static int MaterialCheckBox_buttonIconTint = 0x00000003;
        public static int MaterialCheckBox_buttonIconTintMode = 0x00000004;
        public static int MaterialCheckBox_buttonTint = 0x00000005;
        public static int MaterialCheckBox_centerIfNoTextEnabled = 0x00000006;
        public static int MaterialCheckBox_checkedState = 0x00000007;
        public static int MaterialCheckBox_errorAccessibilityLabel = 0x00000008;
        public static int MaterialCheckBox_errorShown = 0x00000009;
        public static int MaterialCheckBox_useMaterialThemeColors = 0x0000000a;
        public static int MaterialDivider_dividerColor = 0x00000000;
        public static int MaterialDivider_dividerInsetEnd = 0x00000001;
        public static int MaterialDivider_dividerInsetStart = 0x00000002;
        public static int MaterialDivider_dividerThickness = 0x00000003;
        public static int MaterialDivider_lastItemDecorated = 0x00000004;
        public static int MaterialRadioButton_buttonTint = 0x00000000;
        public static int MaterialRadioButton_useMaterialThemeColors = 0x00000001;
        public static int MaterialShape_shapeAppearance = 0x00000000;
        public static int MaterialShape_shapeAppearanceOverlay = 0x00000001;
        public static int MaterialSwitch_thumbIcon = 0x00000000;
        public static int MaterialSwitch_thumbIconSize = 0x00000001;
        public static int MaterialSwitch_thumbIconTint = 0x00000002;
        public static int MaterialSwitch_thumbIconTintMode = 0x00000003;
        public static int MaterialSwitch_trackDecoration = 0x00000004;
        public static int MaterialSwitch_trackDecorationTint = 0x00000005;
        public static int MaterialSwitch_trackDecorationTintMode = 0x00000006;
        public static int MaterialTextAppearance_android_letterSpacing = 0x00000000;
        public static int MaterialTextAppearance_android_lineHeight = 0x00000001;
        public static int MaterialTextAppearance_lineHeight = 0x00000002;
        public static int MaterialTextView_android_lineHeight = 0x00000001;
        public static int MaterialTextView_android_textAppearance = 0x00000000;
        public static int MaterialTextView_lineHeight = 0x00000002;
        public static int MaterialTimePicker_backgroundTint = 0x00000000;
        public static int MaterialTimePicker_clockIcon = 0x00000001;
        public static int MaterialTimePicker_keyboardIcon = 0x00000002;
        public static int MaterialToolbar_logoAdjustViewBounds = 0x00000000;
        public static int MaterialToolbar_logoScaleType = 0x00000001;
        public static int MaterialToolbar_navigationIconTint = 0x00000002;
        public static int MaterialToolbar_subtitleCentered = 0x00000003;
        public static int MaterialToolbar_titleCentered = 0x00000004;
        public static int MenuGroup_android_checkableBehavior = 0x00000005;
        public static int MenuGroup_android_enabled = 0x00000000;
        public static int MenuGroup_android_id = 0x00000001;
        public static int MenuGroup_android_menuCategory = 0x00000003;
        public static int MenuGroup_android_orderInCategory = 0x00000004;
        public static int MenuGroup_android_visible = 0x00000002;
        public static int MenuItem_actionLayout = 0x0000000d;
        public static int MenuItem_actionProviderClass = 0x0000000e;
        public static int MenuItem_actionViewClass = 0x0000000f;
        public static int MenuItem_alphabeticModifiers = 0x00000010;
        public static int MenuItem_android_alphabeticShortcut = 0x00000009;
        public static int MenuItem_android_checkable = 0x0000000b;
        public static int MenuItem_android_checked = 0x00000003;
        public static int MenuItem_android_enabled = 0x00000001;
        public static int MenuItem_android_icon = 0x00000000;
        public static int MenuItem_android_id = 0x00000002;
        public static int MenuItem_android_menuCategory = 0x00000005;
        public static int MenuItem_android_numericShortcut = 0x0000000a;
        public static int MenuItem_android_onClick = 0x0000000c;
        public static int MenuItem_android_orderInCategory = 0x00000006;
        public static int MenuItem_android_title = 0x00000007;
        public static int MenuItem_android_titleCondensed = 0x00000008;
        public static int MenuItem_android_visible = 0x00000004;
        public static int MenuItem_contentDescription = 0x00000011;
        public static int MenuItem_iconTint = 0x00000012;
        public static int MenuItem_iconTintMode = 0x00000013;
        public static int MenuItem_numericModifiers = 0x00000014;
        public static int MenuItem_showAsAction = 0x00000015;
        public static int MenuItem_tooltipText = 0x00000016;
        public static int MenuView_android_headerBackground = 0x00000004;
        public static int MenuView_android_horizontalDivider = 0x00000002;
        public static int MenuView_android_itemBackground = 0x00000005;
        public static int MenuView_android_itemIconDisabledAlpha = 0x00000006;
        public static int MenuView_android_itemTextAppearance = 0x00000001;
        public static int MenuView_android_verticalDivider = 0x00000003;
        public static int MenuView_android_windowAnimationStyle = 0x00000000;
        public static int MenuView_preserveIconSpacing = 0x00000007;
        public static int MenuView_subMenuArrow = 0x00000008;
        public static int MockView_mock_diagonalsColor = 0x00000000;
        public static int MockView_mock_label = 0x00000001;
        public static int MockView_mock_labelBackgroundColor = 0x00000002;
        public static int MockView_mock_labelColor = 0x00000003;
        public static int MockView_mock_showDiagonals = 0x00000004;
        public static int MockView_mock_showLabel = 0x00000005;
        public static int MotionHelper_onHide = 0x00000000;
        public static int MotionHelper_onShow = 0x00000001;
        public static int MotionLayout_applyMotionScene = 0x00000000;
        public static int MotionLayout_currentState = 0x00000001;
        public static int MotionLayout_layoutDescription = 0x00000002;
        public static int MotionLayout_motionDebug = 0x00000003;
        public static int MotionLayout_motionProgress = 0x00000004;
        public static int MotionLayout_showPaths = 0x00000005;
        public static int MotionScene_defaultDuration = 0x00000000;
        public static int MotionScene_layoutDuringTransition = 0x00000001;
        public static int MotionTelltales_telltales_tailColor = 0x00000000;
        public static int MotionTelltales_telltales_tailScale = 0x00000001;
        public static int MotionTelltales_telltales_velocityMode = 0x00000002;
        public static int Motion_animate_relativeTo = 0x00000000;
        public static int Motion_drawPath = 0x00000001;
        public static int Motion_motionPathRotate = 0x00000002;
        public static int Motion_motionStagger = 0x00000003;
        public static int Motion_pathMotionArc = 0x00000004;
        public static int Motion_transitionEasing = 0x00000005;
        public static int NavigationBarActiveIndicator_android_color = 0x00000002;
        public static int NavigationBarActiveIndicator_android_height = 0x00000000;
        public static int NavigationBarActiveIndicator_android_width = 0x00000001;
        public static int NavigationBarActiveIndicator_marginHorizontal = 0x00000003;
        public static int NavigationBarActiveIndicator_shapeAppearance = 0x00000004;
        public static int NavigationBarView_activeIndicatorLabelPadding = 0x00000000;
        public static int NavigationBarView_backgroundTint = 0x00000001;
        public static int NavigationBarView_elevation = 0x00000002;
        public static int NavigationBarView_itemActiveIndicatorStyle = 0x00000003;
        public static int NavigationBarView_itemBackground = 0x00000004;
        public static int NavigationBarView_itemIconSize = 0x00000005;
        public static int NavigationBarView_itemIconTint = 0x00000006;
        public static int NavigationBarView_itemPaddingBottom = 0x00000007;
        public static int NavigationBarView_itemPaddingTop = 0x00000008;
        public static int NavigationBarView_itemRippleColor = 0x00000009;
        public static int NavigationBarView_itemTextAppearanceActive = 0x0000000a;
        public static int NavigationBarView_itemTextAppearanceActiveBoldEnabled = 0x0000000b;
        public static int NavigationBarView_itemTextAppearanceInactive = 0x0000000c;
        public static int NavigationBarView_itemTextColor = 0x0000000d;
        public static int NavigationBarView_labelVisibilityMode = 0x0000000e;
        public static int NavigationBarView_menu = 0x0000000f;
        public static int NavigationRailView_headerLayout = 0x00000000;
        public static int NavigationRailView_itemMinHeight = 0x00000001;
        public static int NavigationRailView_menuGravity = 0x00000002;
        public static int NavigationRailView_paddingBottomSystemWindowInsets = 0x00000003;
        public static int NavigationRailView_paddingStartSystemWindowInsets = 0x00000004;
        public static int NavigationRailView_paddingTopSystemWindowInsets = 0x00000005;
        public static int NavigationRailView_shapeAppearance = 0x00000006;
        public static int NavigationRailView_shapeAppearanceOverlay = 0x00000007;
        public static int NavigationView_android_background = 0x00000001;
        public static int NavigationView_android_fitsSystemWindows = 0x00000002;
        public static int NavigationView_android_layout_gravity = 0x00000000;
        public static int NavigationView_android_maxWidth = 0x00000003;
        public static int NavigationView_bottomInsetScrimEnabled = 0x00000004;
        public static int NavigationView_dividerInsetEnd = 0x00000005;
        public static int NavigationView_dividerInsetStart = 0x00000006;
        public static int NavigationView_drawerLayoutCornerSize = 0x00000007;
        public static int NavigationView_elevation = 0x00000008;
        public static int NavigationView_headerLayout = 0x00000009;
        public static int NavigationView_itemBackground = 0x0000000a;
        public static int NavigationView_itemHorizontalPadding = 0x0000000b;
        public static int NavigationView_itemIconPadding = 0x0000000c;
        public static int NavigationView_itemIconSize = 0x0000000d;
        public static int NavigationView_itemIconTint = 0x0000000e;
        public static int NavigationView_itemMaxLines = 0x0000000f;
        public static int NavigationView_itemRippleColor = 0x00000010;
        public static int NavigationView_itemShapeAppearance = 0x00000011;
        public static int NavigationView_itemShapeAppearanceOverlay = 0x00000012;
        public static int NavigationView_itemShapeFillColor = 0x00000013;
        public static int NavigationView_itemShapeInsetBottom = 0x00000014;
        public static int NavigationView_itemShapeInsetEnd = 0x00000015;
        public static int NavigationView_itemShapeInsetStart = 0x00000016;
        public static int NavigationView_itemShapeInsetTop = 0x00000017;
        public static int NavigationView_itemTextAppearance = 0x00000018;
        public static int NavigationView_itemTextAppearanceActiveBoldEnabled = 0x00000019;
        public static int NavigationView_itemTextColor = 0x0000001a;
        public static int NavigationView_itemVerticalPadding = 0x0000001b;
        public static int NavigationView_menu = 0x0000001c;
        public static int NavigationView_shapeAppearance = 0x0000001d;
        public static int NavigationView_shapeAppearanceOverlay = 0x0000001e;
        public static int NavigationView_subheaderColor = 0x0000001f;
        public static int NavigationView_subheaderInsetEnd = 0x00000020;
        public static int NavigationView_subheaderInsetStart = 0x00000021;
        public static int NavigationView_subheaderTextAppearance = 0x00000022;
        public static int NavigationView_topInsetScrimEnabled = 0x00000023;
        public static int OnClick_clickAction = 0x00000000;
        public static int OnClick_targetId = 0x00000001;
        public static int OnSwipe_dragDirection = 0x00000000;
        public static int OnSwipe_dragScale = 0x00000001;
        public static int OnSwipe_dragThreshold = 0x00000002;
        public static int OnSwipe_limitBoundsTo = 0x00000003;
        public static int OnSwipe_maxAcceleration = 0x00000004;
        public static int OnSwipe_maxVelocity = 0x00000005;
        public static int OnSwipe_moveWhenScrollAtTop = 0x00000006;
        public static int OnSwipe_nestedScrollFlags = 0x00000007;
        public static int OnSwipe_onTouchUp = 0x00000008;
        public static int OnSwipe_touchAnchorId = 0x00000009;
        public static int OnSwipe_touchAnchorSide = 0x0000000a;
        public static int OnSwipe_touchRegionId = 0x0000000b;
        public static int PopupWindowBackgroundState_state_above_anchor = 0x00000000;
        public static int PopupWindow_android_popupAnimationStyle = 0x00000001;
        public static int PopupWindow_android_popupBackground = 0x00000000;
        public static int PopupWindow_overlapAnchor = 0x00000002;
        public static int PropertySet_android_alpha = 0x00000001;
        public static int PropertySet_android_visibility = 0x00000000;
        public static int PropertySet_layout_constraintTag = 0x00000002;
        public static int PropertySet_motionProgress = 0x00000003;
        public static int PropertySet_visibilityMode = 0x00000004;
        public static int RadialViewGroup_materialCircleRadius = 0x00000000;
        public static int RangeSlider_minSeparation = 0x00000000;
        public static int RangeSlider_values = 0x00000001;
        public static int RecycleListView_paddingBottomNoButtons = 0x00000000;
        public static int RecycleListView_paddingTopNoTitle = 0x00000001;
        public static int RecyclerView_android_clipToPadding = 0x00000001;
        public static int RecyclerView_android_descendantFocusability = 0x00000002;
        public static int RecyclerView_android_orientation = 0x00000000;
        public static int RecyclerView_fastScrollEnabled = 0x00000003;
        public static int RecyclerView_fastScrollHorizontalThumbDrawable = 0x00000004;
        public static int RecyclerView_fastScrollHorizontalTrackDrawable = 0x00000005;
        public static int RecyclerView_fastScrollVerticalThumbDrawable = 0x00000006;
        public static int RecyclerView_fastScrollVerticalTrackDrawable = 0x00000007;
        public static int RecyclerView_layoutManager = 0x00000008;
        public static int RecyclerView_reverseLayout = 0x00000009;
        public static int RecyclerView_spanCount = 0x0000000a;
        public static int RecyclerView_stackFromEnd = 0x0000000b;
        public static int ScrimInsetsFrameLayout_insetForeground = 0x00000000;
        public static int ScrollingViewBehavior_Layout_behavior_overlapTop = 0x00000000;
        public static int SearchBar_android_hint = 0x00000002;
        public static int SearchBar_android_text = 0x00000001;
        public static int SearchBar_android_textAppearance = 0x00000000;
        public static int SearchBar_backgroundTint = 0x00000003;
        public static int SearchBar_defaultMarginsEnabled = 0x00000004;
        public static int SearchBar_defaultScrollFlagsEnabled = 0x00000005;
        public static int SearchBar_elevation = 0x00000006;
        public static int SearchBar_forceDefaultNavigationOnClickListener = 0x00000007;
        public static int SearchBar_hideNavigationIcon = 0x00000008;
        public static int SearchBar_navigationIconTint = 0x00000009;
        public static int SearchBar_strokeColor = 0x0000000a;
        public static int SearchBar_strokeWidth = 0x0000000b;
        public static int SearchBar_tintNavigationIcon = 0x0000000c;
        public static int SearchView_android_focusable = 0x00000001;
        public static int SearchView_android_hint = 0x00000004;
        public static int SearchView_android_imeOptions = 0x00000006;
        public static int SearchView_android_inputType = 0x00000005;
        public static int SearchView_android_maxWidth = 0x00000002;
        public static int SearchView_android_text = 0x00000003;
        public static int SearchView_android_textAppearance = 0x00000000;
        public static int SearchView_animateMenuItems = 0x00000007;
        public static int SearchView_animateNavigationIcon = 0x00000008;
        public static int SearchView_autoShowKeyboard = 0x00000009;
        public static int SearchView_backHandlingEnabled = 0x0000000a;
        public static int SearchView_backgroundTint = 0x0000000b;
        public static int SearchView_closeIcon = 0x0000000c;
        public static int SearchView_commitIcon = 0x0000000d;
        public static int SearchView_defaultQueryHint = 0x0000000e;
        public static int SearchView_goIcon = 0x0000000f;
        public static int SearchView_headerLayout = 0x00000010;
        public static int SearchView_hideNavigationIcon = 0x00000011;
        public static int SearchView_iconifiedByDefault = 0x00000012;
        public static int SearchView_layout = 0x00000013;
        public static int SearchView_queryBackground = 0x00000014;
        public static int SearchView_queryHint = 0x00000015;
        public static int SearchView_searchHintIcon = 0x00000016;
        public static int SearchView_searchIcon = 0x00000017;
        public static int SearchView_searchPrefixText = 0x00000018;
        public static int SearchView_submitBackground = 0x00000019;
        public static int SearchView_suggestionRowLayout = 0x0000001a;
        public static int SearchView_useDrawerArrowDrawable = 0x0000001b;
        public static int SearchView_voiceIcon = 0x0000001c;
        public static int ShapeAppearance_cornerFamily = 0x00000000;
        public static int ShapeAppearance_cornerFamilyBottomLeft = 0x00000001;
        public static int ShapeAppearance_cornerFamilyBottomRight = 0x00000002;
        public static int ShapeAppearance_cornerFamilyTopLeft = 0x00000003;
        public static int ShapeAppearance_cornerFamilyTopRight = 0x00000004;
        public static int ShapeAppearance_cornerSize = 0x00000005;
        public static int ShapeAppearance_cornerSizeBottomLeft = 0x00000006;
        public static int ShapeAppearance_cornerSizeBottomRight = 0x00000007;
        public static int ShapeAppearance_cornerSizeTopLeft = 0x00000008;
        public static int ShapeAppearance_cornerSizeTopRight = 0x00000009;
        public static int ShapeableImageView_contentPadding = 0x00000000;
        public static int ShapeableImageView_contentPaddingBottom = 0x00000001;
        public static int ShapeableImageView_contentPaddingEnd = 0x00000002;
        public static int ShapeableImageView_contentPaddingLeft = 0x00000003;
        public static int ShapeableImageView_contentPaddingRight = 0x00000004;
        public static int ShapeableImageView_contentPaddingStart = 0x00000005;
        public static int ShapeableImageView_contentPaddingTop = 0x00000006;
        public static int ShapeableImageView_shapeAppearance = 0x00000007;
        public static int ShapeableImageView_shapeAppearanceOverlay = 0x00000008;
        public static int ShapeableImageView_strokeColor = 0x00000009;
        public static int ShapeableImageView_strokeWidth = 0x0000000a;
        public static int SideSheetBehavior_Layout_android_elevation = 0x00000002;
        public static int SideSheetBehavior_Layout_android_maxHeight = 0x00000001;
        public static int SideSheetBehavior_Layout_android_maxWidth = 0x00000000;
        public static int SideSheetBehavior_Layout_backgroundTint = 0x00000003;
        public static int SideSheetBehavior_Layout_behavior_draggable = 0x00000004;
        public static int SideSheetBehavior_Layout_coplanarSiblingViewId = 0x00000005;
        public static int SideSheetBehavior_Layout_shapeAppearance = 0x00000006;
        public static int SideSheetBehavior_Layout_shapeAppearanceOverlay = 0x00000007;
        public static int Slider_android_enabled = 0x00000000;
        public static int Slider_android_stepSize = 0x00000002;
        public static int Slider_android_value = 0x00000001;
        public static int Slider_android_valueFrom = 0x00000003;
        public static int Slider_android_valueTo = 0x00000004;
        public static int Slider_haloColor = 0x00000005;
        public static int Slider_haloRadius = 0x00000006;
        public static int Slider_labelBehavior = 0x00000007;
        public static int Slider_labelStyle = 0x00000008;
        public static int Slider_minTouchTargetSize = 0x00000009;
        public static int Slider_thumbColor = 0x0000000a;
        public static int Slider_thumbElevation = 0x0000000b;
        public static int Slider_thumbHeight = 0x0000000c;
        public static int Slider_thumbRadius = 0x0000000d;
        public static int Slider_thumbStrokeColor = 0x0000000e;
        public static int Slider_thumbStrokeWidth = 0x0000000f;
        public static int Slider_thumbTrackGapSize = 0x00000010;
        public static int Slider_thumbWidth = 0x00000011;
        public static int Slider_tickColor = 0x00000012;
        public static int Slider_tickColorActive = 0x00000013;
        public static int Slider_tickColorInactive = 0x00000014;
        public static int Slider_tickRadiusActive = 0x00000015;
        public static int Slider_tickRadiusInactive = 0x00000016;
        public static int Slider_tickVisible = 0x00000017;
        public static int Slider_trackColor = 0x00000018;
        public static int Slider_trackColorActive = 0x00000019;
        public static int Slider_trackColorInactive = 0x0000001a;
        public static int Slider_trackHeight = 0x0000001b;
        public static int Slider_trackInsideCornerSize = 0x0000001c;
        public static int Slider_trackStopIndicatorSize = 0x0000001d;
        public static int SnackbarLayout_actionTextColorAlpha = 0x00000001;
        public static int SnackbarLayout_android_maxWidth = 0x00000000;
        public static int SnackbarLayout_animationMode = 0x00000002;
        public static int SnackbarLayout_backgroundOverlayColorAlpha = 0x00000003;
        public static int SnackbarLayout_backgroundTint = 0x00000004;
        public static int SnackbarLayout_backgroundTintMode = 0x00000005;
        public static int SnackbarLayout_elevation = 0x00000006;
        public static int SnackbarLayout_maxActionInlineWidth = 0x00000007;
        public static int SnackbarLayout_shapeAppearance = 0x00000008;
        public static int SnackbarLayout_shapeAppearanceOverlay = 0x00000009;
        public static int Snackbar_snackbarButtonStyle = 0x00000000;
        public static int Snackbar_snackbarStyle = 0x00000001;
        public static int Snackbar_snackbarTextViewStyle = 0x00000002;
        public static int Spinner_android_dropDownWidth = 0x00000003;
        public static int Spinner_android_entries = 0x00000000;
        public static int Spinner_android_popupBackground = 0x00000001;
        public static int Spinner_android_prompt = 0x00000002;
        public static int Spinner_popupTheme = 0x00000004;
        public static int StateListDrawableItem_android_drawable = 0x00000000;
        public static int StateListDrawable_android_constantSize = 0x00000003;
        public static int StateListDrawable_android_dither = 0x00000000;
        public static int StateListDrawable_android_enterFadeDuration = 0x00000004;
        public static int StateListDrawable_android_exitFadeDuration = 0x00000005;
        public static int StateListDrawable_android_variablePadding = 0x00000002;
        public static int StateListDrawable_android_visible = 0x00000001;
        public static int StateSet_defaultState = 0x00000000;
        public static int State_android_id = 0x00000000;
        public static int State_constraints = 0x00000001;
        public static int SwitchCompat_android_textOff = 0x00000001;
        public static int SwitchCompat_android_textOn = 0x00000000;
        public static int SwitchCompat_android_thumb = 0x00000002;
        public static int SwitchCompat_showText = 0x00000003;
        public static int SwitchCompat_splitTrack = 0x00000004;
        public static int SwitchCompat_switchMinWidth = 0x00000005;
        public static int SwitchCompat_switchPadding = 0x00000006;
        public static int SwitchCompat_switchTextAppearance = 0x00000007;
        public static int SwitchCompat_thumbTextPadding = 0x00000008;
        public static int SwitchCompat_thumbTint = 0x00000009;
        public static int SwitchCompat_thumbTintMode = 0x0000000a;
        public static int SwitchCompat_track = 0x0000000b;
        public static int SwitchCompat_trackTint = 0x0000000c;
        public static int SwitchCompat_trackTintMode = 0x0000000d;
        public static int SwitchMaterial_useMaterialThemeColors = 0x00000000;
        public static int TabItem_android_icon = 0x00000000;
        public static int TabItem_android_layout = 0x00000001;
        public static int TabItem_android_text = 0x00000002;
        public static int TabLayout_tabBackground = 0x00000000;
        public static int TabLayout_tabContentStart = 0x00000001;
        public static int TabLayout_tabGravity = 0x00000002;
        public static int TabLayout_tabIconTint = 0x00000003;
        public static int TabLayout_tabIconTintMode = 0x00000004;
        public static int TabLayout_tabIndicator = 0x00000005;
        public static int TabLayout_tabIndicatorAnimationDuration = 0x00000006;
        public static int TabLayout_tabIndicatorAnimationMode = 0x00000007;
        public static int TabLayout_tabIndicatorColor = 0x00000008;
        public static int TabLayout_tabIndicatorFullWidth = 0x00000009;
        public static int TabLayout_tabIndicatorGravity = 0x0000000a;
        public static int TabLayout_tabIndicatorHeight = 0x0000000b;
        public static int TabLayout_tabInlineLabel = 0x0000000c;
        public static int TabLayout_tabMaxWidth = 0x0000000d;
        public static int TabLayout_tabMinWidth = 0x0000000e;
        public static int TabLayout_tabMode = 0x0000000f;
        public static int TabLayout_tabPadding = 0x00000010;
        public static int TabLayout_tabPaddingBottom = 0x00000011;
        public static int TabLayout_tabPaddingEnd = 0x00000012;
        public static int TabLayout_tabPaddingStart = 0x00000013;
        public static int TabLayout_tabPaddingTop = 0x00000014;
        public static int TabLayout_tabRippleColor = 0x00000015;
        public static int TabLayout_tabSelectedTextAppearance = 0x00000016;
        public static int TabLayout_tabSelectedTextColor = 0x00000017;
        public static int TabLayout_tabTextAppearance = 0x00000018;
        public static int TabLayout_tabTextColor = 0x00000019;
        public static int TabLayout_tabUnboundedRipple = 0x0000001a;
        public static int TextAppearance_android_fontFamily = 0x0000000a;
        public static int TextAppearance_android_shadowColor = 0x00000006;
        public static int TextAppearance_android_shadowDx = 0x00000007;
        public static int TextAppearance_android_shadowDy = 0x00000008;
        public static int TextAppearance_android_shadowRadius = 0x00000009;
        public static int TextAppearance_android_textColor = 0x00000003;
        public static int TextAppearance_android_textColorHint = 0x00000004;
        public static int TextAppearance_android_textColorLink = 0x00000005;
        public static int TextAppearance_android_textFontWeight = 0x0000000b;
        public static int TextAppearance_android_textSize = 0x00000000;
        public static int TextAppearance_android_textStyle = 0x00000002;
        public static int TextAppearance_android_typeface = 0x00000001;
        public static int TextAppearance_fontFamily = 0x0000000c;
        public static int TextAppearance_fontVariationSettings = 0x0000000d;
        public static int TextAppearance_textAllCaps = 0x0000000e;
        public static int TextAppearance_textLocale = 0x0000000f;
        public static int TextInputEditText_textInputLayoutFocusedRectEnabled = 0x00000000;
        public static int TextInputLayout_android_enabled = 0x00000000;
        public static int TextInputLayout_android_hint = 0x00000004;
        public static int TextInputLayout_android_maxEms = 0x00000005;
        public static int TextInputLayout_android_maxWidth = 0x00000002;
        public static int TextInputLayout_android_minEms = 0x00000006;
        public static int TextInputLayout_android_minWidth = 0x00000003;
        public static int TextInputLayout_android_textColorHint = 0x00000001;
        public static int TextInputLayout_boxBackgroundColor = 0x00000007;
        public static int TextInputLayout_boxBackgroundMode = 0x00000008;
        public static int TextInputLayout_boxCollapsedPaddingTop = 0x00000009;
        public static int TextInputLayout_boxCornerRadiusBottomEnd = 0x0000000a;
        public static int TextInputLayout_boxCornerRadiusBottomStart = 0x0000000b;
        public static int TextInputLayout_boxCornerRadiusTopEnd = 0x0000000c;
        public static int TextInputLayout_boxCornerRadiusTopStart = 0x0000000d;
        public static int TextInputLayout_boxStrokeColor = 0x0000000e;
        public static int TextInputLayout_boxStrokeErrorColor = 0x0000000f;
        public static int TextInputLayout_boxStrokeWidth = 0x00000010;
        public static int TextInputLayout_boxStrokeWidthFocused = 0x00000011;
        public static int TextInputLayout_counterEnabled = 0x00000012;
        public static int TextInputLayout_counterMaxLength = 0x00000013;
        public static int TextInputLayout_counterOverflowTextAppearance = 0x00000014;
        public static int TextInputLayout_counterOverflowTextColor = 0x00000015;
        public static int TextInputLayout_counterTextAppearance = 0x00000016;
        public static int TextInputLayout_counterTextColor = 0x00000017;
        public static int TextInputLayout_cursorColor = 0x00000018;
        public static int TextInputLayout_cursorErrorColor = 0x00000019;
        public static int TextInputLayout_endIconCheckable = 0x0000001a;
        public static int TextInputLayout_endIconContentDescription = 0x0000001b;
        public static int TextInputLayout_endIconDrawable = 0x0000001c;
        public static int TextInputLayout_endIconMinSize = 0x0000001d;
        public static int TextInputLayout_endIconMode = 0x0000001e;
        public static int TextInputLayout_endIconScaleType = 0x0000001f;
        public static int TextInputLayout_endIconTint = 0x00000020;
        public static int TextInputLayout_endIconTintMode = 0x00000021;
        public static int TextInputLayout_errorAccessibilityLiveRegion = 0x00000022;
        public static int TextInputLayout_errorContentDescription = 0x00000023;
        public static int TextInputLayout_errorEnabled = 0x00000024;
        public static int TextInputLayout_errorIconDrawable = 0x00000025;
        public static int TextInputLayout_errorIconTint = 0x00000026;
        public static int TextInputLayout_errorIconTintMode = 0x00000027;
        public static int TextInputLayout_errorTextAppearance = 0x00000028;
        public static int TextInputLayout_errorTextColor = 0x00000029;
        public static int TextInputLayout_expandedHintEnabled = 0x0000002a;
        public static int TextInputLayout_helperText = 0x0000002b;
        public static int TextInputLayout_helperTextEnabled = 0x0000002c;
        public static int TextInputLayout_helperTextTextAppearance = 0x0000002d;
        public static int TextInputLayout_helperTextTextColor = 0x0000002e;
        public static int TextInputLayout_hintAnimationEnabled = 0x0000002f;
        public static int TextInputLayout_hintEnabled = 0x00000030;
        public static int TextInputLayout_hintTextAppearance = 0x00000031;
        public static int TextInputLayout_hintTextColor = 0x00000032;
        public static int TextInputLayout_passwordToggleContentDescription = 0x00000033;
        public static int TextInputLayout_passwordToggleDrawable = 0x00000034;
        public static int TextInputLayout_passwordToggleEnabled = 0x00000035;
        public static int TextInputLayout_passwordToggleTint = 0x00000036;
        public static int TextInputLayout_passwordToggleTintMode = 0x00000037;
        public static int TextInputLayout_placeholderText = 0x00000038;
        public static int TextInputLayout_placeholderTextAppearance = 0x00000039;
        public static int TextInputLayout_placeholderTextColor = 0x0000003a;
        public static int TextInputLayout_prefixText = 0x0000003b;
        public static int TextInputLayout_prefixTextAppearance = 0x0000003c;
        public static int TextInputLayout_prefixTextColor = 0x0000003d;
        public static int TextInputLayout_shapeAppearance = 0x0000003e;
        public static int TextInputLayout_shapeAppearanceOverlay = 0x0000003f;
        public static int TextInputLayout_startIconCheckable = 0x00000040;
        public static int TextInputLayout_startIconContentDescription = 0x00000041;
        public static int TextInputLayout_startIconDrawable = 0x00000042;
        public static int TextInputLayout_startIconMinSize = 0x00000043;
        public static int TextInputLayout_startIconScaleType = 0x00000044;
        public static int TextInputLayout_startIconTint = 0x00000045;
        public static int TextInputLayout_startIconTintMode = 0x00000046;
        public static int TextInputLayout_suffixText = 0x00000047;
        public static int TextInputLayout_suffixTextAppearance = 0x00000048;
        public static int TextInputLayout_suffixTextColor = 0x00000049;
        public static int ThemeEnforcement_android_textAppearance = 0x00000000;
        public static int ThemeEnforcement_enforceMaterialTheme = 0x00000001;
        public static int ThemeEnforcement_enforceTextAppearance = 0x00000002;
        public static int Toolbar_android_gravity = 0x00000000;
        public static int Toolbar_android_minHeight = 0x00000001;
        public static int Toolbar_buttonGravity = 0x00000002;
        public static int Toolbar_collapseContentDescription = 0x00000003;
        public static int Toolbar_collapseIcon = 0x00000004;
        public static int Toolbar_contentInsetEnd = 0x00000005;
        public static int Toolbar_contentInsetEndWithActions = 0x00000006;
        public static int Toolbar_contentInsetLeft = 0x00000007;
        public static int Toolbar_contentInsetRight = 0x00000008;
        public static int Toolbar_contentInsetStart = 0x00000009;
        public static int Toolbar_contentInsetStartWithNavigation = 0x0000000a;
        public static int Toolbar_logo = 0x0000000b;
        public static int Toolbar_logoDescription = 0x0000000c;
        public static int Toolbar_maxButtonHeight = 0x0000000d;
        public static int Toolbar_menu = 0x0000000e;
        public static int Toolbar_navigationContentDescription = 0x0000000f;
        public static int Toolbar_navigationIcon = 0x00000010;
        public static int Toolbar_popupTheme = 0x00000011;
        public static int Toolbar_subtitle = 0x00000012;
        public static int Toolbar_subtitleTextAppearance = 0x00000013;
        public static int Toolbar_subtitleTextColor = 0x00000014;
        public static int Toolbar_title = 0x00000015;
        public static int Toolbar_titleMargin = 0x00000016;
        public static int Toolbar_titleMarginBottom = 0x00000017;
        public static int Toolbar_titleMarginEnd = 0x00000018;
        public static int Toolbar_titleMarginStart = 0x00000019;
        public static int Toolbar_titleMarginTop = 0x0000001a;
        public static int Toolbar_titleMargins = 0x0000001b;
        public static int Toolbar_titleTextAppearance = 0x0000001c;
        public static int Toolbar_titleTextColor = 0x0000001d;
        public static int Tooltip_android_layout_margin = 0x00000003;
        public static int Tooltip_android_minHeight = 0x00000005;
        public static int Tooltip_android_minWidth = 0x00000004;
        public static int Tooltip_android_padding = 0x00000002;
        public static int Tooltip_android_text = 0x00000006;
        public static int Tooltip_android_textAppearance = 0x00000000;
        public static int Tooltip_android_textColor = 0x00000001;
        public static int Tooltip_backgroundTint = 0x00000007;
        public static int Tooltip_showMarker = 0x00000008;
        public static int Transform_android_elevation = 0x0000000a;
        public static int Transform_android_rotation = 0x00000006;
        public static int Transform_android_rotationX = 0x00000007;
        public static int Transform_android_rotationY = 0x00000008;
        public static int Transform_android_scaleX = 0x00000004;
        public static int Transform_android_scaleY = 0x00000005;
        public static int Transform_android_transformPivotX = 0x00000000;
        public static int Transform_android_transformPivotY = 0x00000001;
        public static int Transform_android_translationX = 0x00000002;
        public static int Transform_android_translationY = 0x00000003;
        public static int Transform_android_translationZ = 0x00000009;
        public static int Transition_android_id = 0x00000000;
        public static int Transition_autoTransition = 0x00000001;
        public static int Transition_constraintSetEnd = 0x00000002;
        public static int Transition_constraintSetStart = 0x00000003;
        public static int Transition_duration = 0x00000004;
        public static int Transition_layoutDuringTransition = 0x00000005;
        public static int Transition_motionInterpolator = 0x00000006;
        public static int Transition_pathMotionArc = 0x00000007;
        public static int Transition_staggered = 0x00000008;
        public static int Transition_transitionDisable = 0x00000009;
        public static int Transition_transitionFlags = 0x0000000a;
        public static int Variant_constraints = 0x00000000;
        public static int Variant_region_heightLessThan = 0x00000001;
        public static int Variant_region_heightMoreThan = 0x00000002;
        public static int Variant_region_widthLessThan = 0x00000003;
        public static int Variant_region_widthMoreThan = 0x00000004;
        public static int ViewBackgroundHelper_android_background = 0x00000000;
        public static int ViewBackgroundHelper_backgroundTint = 0x00000001;
        public static int ViewBackgroundHelper_backgroundTintMode = 0x00000002;
        public static int ViewPager2_android_orientation = 0x00000000;
        public static int ViewStubCompat_android_id = 0x00000000;
        public static int ViewStubCompat_android_inflatedId = 0x00000002;
        public static int ViewStubCompat_android_layout = 0x00000001;
        public static int View_android_focusable = 0x00000001;
        public static int View_android_theme = 0x00000000;
        public static int View_paddingEnd = 0x00000002;
        public static int View_paddingStart = 0x00000003;
        public static int View_theme = 0x00000004;
        public static int[] ActionBar = {R.attr.background, R.attr.backgroundSplit, R.attr.backgroundStacked, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.customNavigationLayout, R.attr.displayOptions, R.attr.divider, R.attr.elevation, R.attr.height, R.attr.hideOnContentScroll, R.attr.homeAsUpIndicator, R.attr.homeLayout, R.attr.icon, R.attr.indeterminateProgressStyle, R.attr.itemPadding, R.attr.logo, R.attr.navigationMode, R.attr.popupTheme, R.attr.progressBarPadding, R.attr.progressBarStyle, R.attr.subtitle, R.attr.subtitleTextStyle, R.attr.title, R.attr.titleTextStyle};
        public static int[] ActionBarLayout = {android.R.attr.layout_gravity};
        public static int[] ActionMenuItemView = {android.R.attr.minWidth};
        public static int[] ActionMenuView = new int[0];
        public static int[] ActionMode = {R.attr.background, R.attr.backgroundSplit, R.attr.closeItemLayout, R.attr.height, R.attr.subtitleTextStyle, R.attr.titleTextStyle};
        public static int[] ActivityChooserView = {R.attr.expandActivityOverflowButtonDrawable, R.attr.initialActivityCount};
        public static int[] AlertDialog = {android.R.attr.layout, R.attr.buttonIconDimen, R.attr.buttonPanelSideLayout, R.attr.listItemLayout, R.attr.listLayout, R.attr.multiChoiceItemLayout, R.attr.showTitle, R.attr.singleChoiceItemLayout};
        public static int[] AnimatedStateListDrawableCompat = {android.R.attr.dither, android.R.attr.visible, android.R.attr.variablePadding, android.R.attr.constantSize, android.R.attr.enterFadeDuration, android.R.attr.exitFadeDuration};
        public static int[] AnimatedStateListDrawableItem = {android.R.attr.id, android.R.attr.drawable};
        public static int[] AnimatedStateListDrawableTransition = {android.R.attr.drawable, android.R.attr.toId, android.R.attr.fromId, android.R.attr.reversible};
        public static int[] AppBarLayout = {android.R.attr.background, android.R.attr.touchscreenBlocksFocus, android.R.attr.keyboardNavigationCluster, R.attr.elevation, R.attr.expanded, R.attr.liftOnScroll, R.attr.liftOnScrollColor, R.attr.liftOnScrollTargetViewId, R.attr.statusBarForeground};
        public static int[] AppBarLayoutStates = {R.attr.state_collapsed, R.attr.state_collapsible, R.attr.state_liftable, R.attr.state_lifted};
        public static int[] AppBarLayout_Layout = {R.attr.layout_scrollEffect, R.attr.layout_scrollFlags, R.attr.layout_scrollInterpolator};
        public static int[] AppCompatEmojiHelper = new int[0];
        public static int[] AppCompatImageView = {android.R.attr.src, R.attr.srcCompat, R.attr.tint, R.attr.tintMode};
        public static int[] AppCompatSeekBar = {android.R.attr.thumb, R.attr.tickMark, R.attr.tickMarkTint, R.attr.tickMarkTintMode};
        public static int[] AppCompatTextHelper = {android.R.attr.textAppearance, android.R.attr.drawableTop, android.R.attr.drawableBottom, android.R.attr.drawableLeft, android.R.attr.drawableRight, android.R.attr.drawableStart, android.R.attr.drawableEnd};
        public static int[] AppCompatTextView = {android.R.attr.textAppearance, R.attr.autoSizeMaxTextSize, R.attr.autoSizeMinTextSize, R.attr.autoSizePresetSizes, R.attr.autoSizeStepGranularity, R.attr.autoSizeTextType, R.attr.drawableBottomCompat, R.attr.drawableEndCompat, R.attr.drawableLeftCompat, R.attr.drawableRightCompat, R.attr.drawableStartCompat, R.attr.drawableTint, R.attr.drawableTintMode, R.attr.drawableTopCompat, R.attr.emojiCompatEnabled, R.attr.firstBaselineToTopHeight, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.lastBaselineToBottomHeight, R.attr.lineHeight, R.attr.textAllCaps, R.attr.textLocale};
        public static int[] AppCompatTheme = {android.R.attr.windowIsFloating, android.R.attr.windowAnimationStyle, R.attr.actionBarDivider, R.attr.actionBarItemBackground, R.attr.actionBarPopupTheme, R.attr.actionBarSize, R.attr.actionBarSplitStyle, R.attr.actionBarStyle, R.attr.actionBarTabBarStyle, R.attr.actionBarTabStyle, R.attr.actionBarTabTextStyle, R.attr.actionBarTheme, R.attr.actionBarWidgetTheme, R.attr.actionButtonStyle, R.attr.actionDropDownStyle, R.attr.actionMenuTextAppearance, R.attr.actionMenuTextColor, R.attr.actionModeBackground, R.attr.actionModeCloseButtonStyle, R.attr.actionModeCloseContentDescription, R.attr.actionModeCloseDrawable, R.attr.actionModeCopyDrawable, R.attr.actionModeCutDrawable, R.attr.actionModeFindDrawable, R.attr.actionModePasteDrawable, R.attr.actionModePopupWindowStyle, R.attr.actionModeSelectAllDrawable, R.attr.actionModeShareDrawable, R.attr.actionModeSplitBackground, R.attr.actionModeStyle, R.attr.actionModeTheme, R.attr.actionModeWebSearchDrawable, R.attr.actionOverflowButtonStyle, R.attr.actionOverflowMenuStyle, R.attr.activityChooserViewStyle, R.attr.alertDialogButtonGroupStyle, R.attr.alertDialogCenterButtons, R.attr.alertDialogStyle, R.attr.alertDialogTheme, R.attr.autoCompleteTextViewStyle, R.attr.borderlessButtonStyle, R.attr.buttonBarButtonStyle, R.attr.buttonBarNegativeButtonStyle, R.attr.buttonBarNeutralButtonStyle, R.attr.buttonBarPositiveButtonStyle, R.attr.buttonBarStyle, R.attr.buttonStyle, R.attr.buttonStyleSmall, R.attr.checkboxStyle, R.attr.checkedTextViewStyle, R.attr.colorAccent, R.attr.colorBackgroundFloating, R.attr.colorButtonNormal, R.attr.colorControlActivated, R.attr.colorControlHighlight, R.attr.colorControlNormal, R.attr.colorError, R.attr.colorPrimary, R.attr.colorPrimaryDark, R.attr.colorSwitchThumbNormal, R.attr.controlBackground, R.attr.dialogCornerRadius, R.attr.dialogPreferredPadding, R.attr.dialogTheme, R.attr.dividerHorizontal, R.attr.dividerVertical, R.attr.dropDownListViewStyle, R.attr.dropdownListPreferredItemHeight, R.attr.editTextBackground, R.attr.editTextColor, R.attr.editTextStyle, R.attr.homeAsUpIndicator, R.attr.imageButtonStyle, R.attr.listChoiceBackgroundIndicator, R.attr.listChoiceIndicatorMultipleAnimated, R.attr.listChoiceIndicatorSingleAnimated, R.attr.listDividerAlertDialog, R.attr.listMenuViewStyle, R.attr.listPopupWindowStyle, R.attr.listPreferredItemHeight, R.attr.listPreferredItemHeightLarge, R.attr.listPreferredItemHeightSmall, R.attr.listPreferredItemPaddingEnd, R.attr.listPreferredItemPaddingLeft, R.attr.listPreferredItemPaddingRight, R.attr.listPreferredItemPaddingStart, R.attr.panelBackground, R.attr.panelMenuListTheme, R.attr.panelMenuListWidth, R.attr.popupMenuStyle, R.attr.popupWindowStyle, R.attr.radioButtonStyle, R.attr.ratingBarStyle, R.attr.ratingBarStyleIndicator, R.attr.ratingBarStyleSmall, R.attr.searchViewStyle, R.attr.seekBarStyle, R.attr.selectableItemBackground, R.attr.selectableItemBackgroundBorderless, R.attr.spinnerDropDownItemStyle, R.attr.spinnerStyle, R.attr.switchStyle, R.attr.textAppearanceLargePopupMenu, R.attr.textAppearanceListItem, R.attr.textAppearanceListItemSecondary, R.attr.textAppearanceListItemSmall, R.attr.textAppearancePopupMenuHeader, R.attr.textAppearanceSearchResultSubtitle, R.attr.textAppearanceSearchResultTitle, R.attr.textAppearanceSmallPopupMenu, R.attr.textColorAlertDialogListItem, R.attr.textColorSearchUrl, R.attr.toolbarNavigationButtonStyle, R.attr.toolbarStyle, R.attr.tooltipForegroundColor, R.attr.tooltipFrameBackground, R.attr.viewInflaterClass, R.attr.windowActionBar, R.attr.windowActionBarOverlay, R.attr.windowActionModeOverlay, R.attr.windowFixedHeightMajor, R.attr.windowFixedHeightMinor, R.attr.windowFixedWidthMajor, R.attr.windowFixedWidthMinor, R.attr.windowMinWidthMajor, R.attr.windowMinWidthMinor, R.attr.windowNoTitle};
        public static int[] Badge = {R.attr.autoAdjustToWithinGrandparentBounds, R.attr.backgroundColor, R.attr.badgeGravity, R.attr.badgeHeight, R.attr.badgeRadius, R.attr.badgeShapeAppearance, R.attr.badgeShapeAppearanceOverlay, R.attr.badgeText, R.attr.badgeTextAppearance, R.attr.badgeTextColor, R.attr.badgeVerticalPadding, R.attr.badgeWidePadding, R.attr.badgeWidth, R.attr.badgeWithTextHeight, R.attr.badgeWithTextRadius, R.attr.badgeWithTextShapeAppearance, R.attr.badgeWithTextShapeAppearanceOverlay, R.attr.badgeWithTextWidth, R.attr.horizontalOffset, R.attr.horizontalOffsetWithText, R.attr.largeFontVerticalOffsetAdjustment, R.attr.maxCharacterCount, R.attr.maxNumber, R.attr.number, R.attr.offsetAlignmentMode, R.attr.verticalOffset, R.attr.verticalOffsetWithText};
        public static int[] BaseProgressIndicator = {android.R.attr.indeterminate, R.attr.hideAnimationBehavior, R.attr.indicatorColor, R.attr.indicatorTrackGapSize, R.attr.minHideDelay, R.attr.showAnimationBehavior, R.attr.showDelay, R.attr.trackColor, R.attr.trackCornerRadius, R.attr.trackThickness};
        public static int[] BottomAppBar = {R.attr.addElevationShadow, R.attr.backgroundTint, R.attr.elevation, R.attr.fabAlignmentMode, R.attr.fabAlignmentModeEndMargin, R.attr.fabAnchorMode, R.attr.fabAnimationMode, R.attr.fabCradleMargin, R.attr.fabCradleRoundedCornerRadius, R.attr.fabCradleVerticalOffset, R.attr.hideOnScroll, R.attr.menuAlignmentMode, R.attr.navigationIconTint, R.attr.paddingBottomSystemWindowInsets, R.attr.paddingLeftSystemWindowInsets, R.attr.paddingRightSystemWindowInsets, R.attr.removeEmbeddedFabElevation};
        public static int[] BottomNavigationView = {android.R.attr.minHeight, R.attr.compatShadowEnabled, R.attr.itemHorizontalTranslationEnabled, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay};
        public static int[] BottomSheetBehavior_Layout = {android.R.attr.maxWidth, android.R.attr.maxHeight, android.R.attr.elevation, R.attr.backgroundTint, R.attr.behavior_draggable, R.attr.behavior_expandedOffset, R.attr.behavior_fitToContents, R.attr.behavior_halfExpandedRatio, R.attr.behavior_hideable, R.attr.behavior_peekHeight, R.attr.behavior_saveFlags, R.attr.behavior_significantVelocityThreshold, R.attr.behavior_skipCollapsed, R.attr.gestureInsetBottomIgnored, R.attr.marginLeftSystemWindowInsets, R.attr.marginRightSystemWindowInsets, R.attr.marginTopSystemWindowInsets, R.attr.paddingBottomSystemWindowInsets, R.attr.paddingLeftSystemWindowInsets, R.attr.paddingRightSystemWindowInsets, R.attr.paddingTopSystemWindowInsets, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.shouldRemoveExpandedCorners};
        public static int[] ButtonBarLayout = {R.attr.allowStacking};
        public static int[] Capability = {R.attr.queryPatterns, R.attr.shortcutMatchRequired};
        public static int[] CardView = {android.R.attr.minWidth, android.R.attr.minHeight, R.attr.cardBackgroundColor, R.attr.cardCornerRadius, R.attr.cardElevation, R.attr.cardMaxElevation, R.attr.cardPreventCornerOverlap, R.attr.cardUseCompatPadding, R.attr.contentPadding, R.attr.contentPaddingBottom, R.attr.contentPaddingLeft, R.attr.contentPaddingRight, R.attr.contentPaddingTop};
        public static int[] Carousel = {R.attr.carousel_alignment};
        public static int[] CheckedTextView = {android.R.attr.checkMark, R.attr.checkMarkCompat, R.attr.checkMarkTint, R.attr.checkMarkTintMode};
        public static int[] Chip = {android.R.attr.textAppearance, android.R.attr.textSize, android.R.attr.textColor, android.R.attr.ellipsize, android.R.attr.maxWidth, android.R.attr.text, android.R.attr.checkable, R.attr.checkedIcon, R.attr.checkedIconEnabled, R.attr.checkedIconTint, R.attr.checkedIconVisible, R.attr.chipBackgroundColor, R.attr.chipCornerRadius, R.attr.chipEndPadding, R.attr.chipIcon, R.attr.chipIconEnabled, R.attr.chipIconSize, R.attr.chipIconTint, R.attr.chipIconVisible, R.attr.chipMinHeight, R.attr.chipMinTouchTargetSize, R.attr.chipStartPadding, R.attr.chipStrokeColor, R.attr.chipStrokeWidth, R.attr.chipSurfaceColor, R.attr.closeIcon, R.attr.closeIconEnabled, R.attr.closeIconEndPadding, R.attr.closeIconSize, R.attr.closeIconStartPadding, R.attr.closeIconTint, R.attr.closeIconVisible, R.attr.ensureMinTouchTargetSize, R.attr.hideMotionSpec, R.attr.iconEndPadding, R.attr.iconStartPadding, R.attr.rippleColor, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.showMotionSpec, R.attr.textEndPadding, R.attr.textStartPadding};
        public static int[] ChipGroup = {R.attr.checkedChip, R.attr.chipSpacing, R.attr.chipSpacingHorizontal, R.attr.chipSpacingVertical, R.attr.selectionRequired, R.attr.singleLine, R.attr.singleSelection};
        public static int[] CircularProgressIndicator = {R.attr.indicatorDirectionCircular, R.attr.indicatorInset, R.attr.indicatorSize};
        public static int[] ClockFaceView = {R.attr.clockFaceBackgroundColor, R.attr.clockNumberTextColor};
        public static int[] ClockHandView = {R.attr.clockHandColor, R.attr.materialCircleRadius, R.attr.selectorSize};
        public static int[] CollapsingToolbarLayout = {R.attr.collapsedTitleGravity, R.attr.collapsedTitleTextAppearance, R.attr.collapsedTitleTextColor, R.attr.contentScrim, R.attr.expandedTitleGravity, R.attr.expandedTitleMargin, R.attr.expandedTitleMarginBottom, R.attr.expandedTitleMarginEnd, R.attr.expandedTitleMarginStart, R.attr.expandedTitleMarginTop, R.attr.expandedTitleTextAppearance, R.attr.expandedTitleTextColor, R.attr.extraMultilineHeightEnabled, R.attr.forceApplySystemWindowInsetTop, R.attr.maxLines, R.attr.scrimAnimationDuration, R.attr.scrimVisibleHeightTrigger, R.attr.statusBarScrim, R.attr.title, R.attr.titleCollapseMode, R.attr.titleEnabled, R.attr.titlePositionInterpolator, R.attr.titleTextEllipsize, R.attr.toolbarId};
        public static int[] CollapsingToolbarLayout_Layout = {R.attr.layout_collapseMode, R.attr.layout_collapseParallaxMultiplier};
        public static int[] ColorStateListItem = {android.R.attr.color, android.R.attr.alpha, android.R.attr.lStar, R.attr.alpha, R.attr.lStar};
        public static int[] CompoundButton = {android.R.attr.button, R.attr.buttonCompat, R.attr.buttonTint, R.attr.buttonTintMode};
        public static int[] Constraint = {android.R.attr.orientation, android.R.attr.id, android.R.attr.visibility, android.R.attr.layout_width, android.R.attr.layout_height, android.R.attr.layout_marginLeft, android.R.attr.layout_marginTop, android.R.attr.layout_marginRight, android.R.attr.layout_marginBottom, android.R.attr.maxWidth, android.R.attr.maxHeight, android.R.attr.minWidth, android.R.attr.minHeight, android.R.attr.alpha, android.R.attr.transformPivotX, android.R.attr.transformPivotY, android.R.attr.translationX, android.R.attr.translationY, android.R.attr.scaleX, android.R.attr.scaleY, android.R.attr.rotation, android.R.attr.rotationX, android.R.attr.rotationY, android.R.attr.layout_marginStart, android.R.attr.layout_marginEnd, android.R.attr.translationZ, android.R.attr.elevation, R.attr.animate_relativeTo, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraint_referenced_ids, R.attr.drawPath, R.attr.flow_firstHorizontalBias, R.attr.flow_firstHorizontalStyle, R.attr.flow_firstVerticalBias, R.attr.flow_firstVerticalStyle, R.attr.flow_horizontalAlign, R.attr.flow_horizontalBias, R.attr.flow_horizontalGap, R.attr.flow_horizontalStyle, R.attr.flow_lastHorizontalBias, R.attr.flow_lastHorizontalStyle, R.attr.flow_lastVerticalBias, R.attr.flow_lastVerticalStyle, R.attr.flow_maxElementsWrap, R.attr.flow_verticalAlign, R.attr.flow_verticalBias, R.attr.flow_verticalGap, R.attr.flow_verticalStyle, R.attr.flow_wrapMode, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTag, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.motionProgress, R.attr.motionStagger, R.attr.pathMotionArc, R.attr.pivotAnchor, R.attr.transitionEasing, R.attr.transitionPathRotate, R.attr.visibilityMode};
        public static int[] ConstraintLayout_Layout = {android.R.attr.orientation, android.R.attr.padding, android.R.attr.paddingLeft, android.R.attr.paddingTop, android.R.attr.paddingRight, android.R.attr.paddingBottom, android.R.attr.visibility, android.R.attr.maxWidth, android.R.attr.maxHeight, android.R.attr.minWidth, android.R.attr.minHeight, android.R.attr.paddingStart, android.R.attr.paddingEnd, android.R.attr.elevation, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraintSet, R.attr.constraint_referenced_ids, R.attr.flow_firstHorizontalBias, R.attr.flow_firstHorizontalStyle, R.attr.flow_firstVerticalBias, R.attr.flow_firstVerticalStyle, R.attr.flow_horizontalAlign, R.attr.flow_horizontalBias, R.attr.flow_horizontalGap, R.attr.flow_horizontalStyle, R.attr.flow_lastHorizontalBias, R.attr.flow_lastHorizontalStyle, R.attr.flow_lastVerticalBias, R.attr.flow_lastVerticalStyle, R.attr.flow_maxElementsWrap, R.attr.flow_verticalAlign, R.attr.flow_verticalBias, R.attr.flow_verticalGap, R.attr.flow_verticalStyle, R.attr.flow_wrapMode, R.attr.layoutDescription, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTag, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.layout_optimizationLevel};
        public static int[] ConstraintLayout_placeholder = {R.attr.content, R.attr.placeholder_emptyVisibility};
        public static int[] ConstraintSet = {android.R.attr.orientation, android.R.attr.id, android.R.attr.visibility, android.R.attr.layout_width, android.R.attr.layout_height, android.R.attr.layout_marginLeft, android.R.attr.layout_marginTop, android.R.attr.layout_marginRight, android.R.attr.layout_marginBottom, android.R.attr.maxWidth, android.R.attr.maxHeight, android.R.attr.minWidth, android.R.attr.minHeight, android.R.attr.pivotX, android.R.attr.pivotY, android.R.attr.alpha, android.R.attr.transformPivotX, android.R.attr.transformPivotY, android.R.attr.translationX, android.R.attr.translationY, android.R.attr.scaleX, android.R.attr.scaleY, android.R.attr.rotation, android.R.attr.rotationX, android.R.attr.rotationY, android.R.attr.layout_marginStart, android.R.attr.layout_marginEnd, android.R.attr.translationZ, android.R.attr.elevation, R.attr.animate_relativeTo, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraint_referenced_ids, R.attr.deriveConstraintsFrom, R.attr.drawPath, R.attr.flow_firstHorizontalBias, R.attr.flow_firstHorizontalStyle, R.attr.flow_firstVerticalBias, R.attr.flow_firstVerticalStyle, R.attr.flow_horizontalAlign, R.attr.flow_horizontalBias, R.attr.flow_horizontalGap, R.attr.flow_horizontalStyle, R.attr.flow_lastHorizontalBias, R.attr.flow_lastHorizontalStyle, R.attr.flow_lastVerticalBias, R.attr.flow_lastVerticalStyle, R.attr.flow_maxElementsWrap, R.attr.flow_verticalAlign, R.attr.flow_verticalBias, R.attr.flow_verticalGap, R.attr.flow_verticalStyle, R.attr.flow_wrapMode, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTag, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.motionProgress, R.attr.motionStagger, R.attr.pathMotionArc, R.attr.pivotAnchor, R.attr.transitionEasing, R.attr.transitionPathRotate};
        public static int[] CoordinatorLayout = {R.attr.keylines, R.attr.statusBarBackground};
        public static int[] CoordinatorLayout_Layout = {android.R.attr.layout_gravity, R.attr.layout_anchor, R.attr.layout_anchorGravity, R.attr.layout_behavior, R.attr.layout_dodgeInsetEdges, R.attr.layout_insetEdge, R.attr.layout_keyline};
        public static int[] CustomAttribute = {R.attr.attributeName, R.attr.customBoolean, R.attr.customColorDrawableValue, R.attr.customColorValue, R.attr.customDimension, R.attr.customFloatValue, R.attr.customIntegerValue, R.attr.customPixelDimension, R.attr.customStringValue};
        public static int[] DrawerArrowToggle = {R.attr.arrowHeadLength, R.attr.arrowShaftLength, R.attr.barLength, R.attr.color, R.attr.drawableSize, R.attr.gapBetweenBars, R.attr.spinBars, R.attr.thickness};
        public static int[] DrawerLayout = {R.attr.elevation};
        public static int[] ExtendedFloatingActionButton = {R.attr.collapsedSize, R.attr.elevation, R.attr.extendMotionSpec, R.attr.extendStrategy, R.attr.hideMotionSpec, R.attr.showMotionSpec, R.attr.shrinkMotionSpec};
        public static int[] ExtendedFloatingActionButton_Behavior_Layout = {R.attr.behavior_autoHide, R.attr.behavior_autoShrink};
        public static int[] FloatingActionButton = {android.R.attr.enabled, R.attr.backgroundTint, R.attr.backgroundTintMode, R.attr.borderWidth, R.attr.elevation, R.attr.ensureMinTouchTargetSize, R.attr.fabCustomSize, R.attr.fabSize, R.attr.hideMotionSpec, R.attr.hoveredFocusedTranslationZ, R.attr.maxImageSize, R.attr.pressedTranslationZ, R.attr.rippleColor, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.showMotionSpec, R.attr.useCompatPadding};
        public static int[] FloatingActionButton_Behavior_Layout = {R.attr.behavior_autoHide};
        public static int[] FlowLayout = {R.attr.itemSpacing, R.attr.lineSpacing};
        public static int[] FontFamily = {R.attr.fontProviderAuthority, R.attr.fontProviderCerts, R.attr.fontProviderFetchStrategy, R.attr.fontProviderFetchTimeout, R.attr.fontProviderPackage, R.attr.fontProviderQuery, R.attr.fontProviderSystemFontFamily};
        public static int[] FontFamilyFont = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, R.attr.font, R.attr.fontStyle, R.attr.fontVariationSettings, R.attr.fontWeight, R.attr.ttcIndex};
        public static int[] ForegroundLinearLayout = {android.R.attr.foreground, android.R.attr.foregroundGravity, R.attr.foregroundInsidePadding};
        public static int[] Fragment = {android.R.attr.name, android.R.attr.id, android.R.attr.tag};
        public static int[] FragmentContainerView = {android.R.attr.name, android.R.attr.tag};
        public static int[] GradientColor = {android.R.attr.startColor, android.R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};
        public static int[] GradientColorItem = {android.R.attr.color, android.R.attr.offset};
        public static int[] ImageFilterView = {R.attr.altSrc, R.attr.brightness, R.attr.contrast, R.attr.crossfade, R.attr.overlay, R.attr.round, R.attr.roundPercent, R.attr.saturation, R.attr.warmth};
        public static int[] Insets = {R.attr.marginLeftSystemWindowInsets, R.attr.marginRightSystemWindowInsets, R.attr.marginTopSystemWindowInsets, R.attr.paddingBottomSystemWindowInsets, R.attr.paddingLeftSystemWindowInsets, R.attr.paddingRightSystemWindowInsets, R.attr.paddingStartSystemWindowInsets, R.attr.paddingTopSystemWindowInsets};
        public static int[] KeyAttribute = {android.R.attr.alpha, android.R.attr.transformPivotX, android.R.attr.transformPivotY, android.R.attr.translationX, android.R.attr.translationY, android.R.attr.scaleX, android.R.attr.scaleY, android.R.attr.rotation, android.R.attr.rotationX, android.R.attr.rotationY, android.R.attr.translationZ, android.R.attr.elevation, R.attr.curveFit, R.attr.framePosition, R.attr.motionProgress, R.attr.motionTarget, R.attr.transitionEasing, R.attr.transitionPathRotate};
        public static int[] KeyCycle = {android.R.attr.alpha, android.R.attr.translationX, android.R.attr.translationY, android.R.attr.scaleX, android.R.attr.scaleY, android.R.attr.rotation, android.R.attr.rotationX, android.R.attr.rotationY, android.R.attr.translationZ, android.R.attr.elevation, R.attr.curveFit, R.attr.framePosition, R.attr.motionProgress, R.attr.motionTarget, R.attr.transitionEasing, R.attr.transitionPathRotate, R.attr.waveOffset, R.attr.wavePeriod, R.attr.waveShape, R.attr.waveVariesBy};
        public static int[] KeyPosition = {R.attr.curveFit, R.attr.drawPath, R.attr.framePosition, R.attr.keyPositionType, R.attr.motionTarget, R.attr.pathMotionArc, R.attr.percentHeight, R.attr.percentWidth, R.attr.percentX, R.attr.percentY, R.attr.sizePercent, R.attr.transitionEasing};
        public static int[] KeyTimeCycle = {android.R.attr.alpha, android.R.attr.translationX, android.R.attr.translationY, android.R.attr.scaleX, android.R.attr.scaleY, android.R.attr.rotation, android.R.attr.rotationX, android.R.attr.rotationY, android.R.attr.translationZ, android.R.attr.elevation, R.attr.curveFit, R.attr.framePosition, R.attr.motionProgress, R.attr.motionTarget, R.attr.transitionEasing, R.attr.transitionPathRotate, R.attr.waveDecay, R.attr.waveOffset, R.attr.wavePeriod, R.attr.waveShape};
        public static int[] KeyTrigger = {R.attr.framePosition, R.attr.motionTarget, R.attr.motion_postLayoutCollision, R.attr.motion_triggerOnCollision, R.attr.onCross, R.attr.onNegativeCross, R.attr.onPositiveCross, R.attr.triggerId, R.attr.triggerReceiver, R.attr.triggerSlack};
        public static int[] Layout = {android.R.attr.orientation, android.R.attr.layout_width, android.R.attr.layout_height, android.R.attr.layout_marginLeft, android.R.attr.layout_marginTop, android.R.attr.layout_marginRight, android.R.attr.layout_marginBottom, android.R.attr.layout_marginStart, android.R.attr.layout_marginEnd, R.attr.barrierAllowsGoneWidgets, R.attr.barrierDirection, R.attr.barrierMargin, R.attr.chainUseRtl, R.attr.constraint_referenced_ids, R.attr.layout_constrainedHeight, R.attr.layout_constrainedWidth, R.attr.layout_constraintBaseline_creator, R.attr.layout_constraintBaseline_toBaselineOf, R.attr.layout_constraintBottom_creator, R.attr.layout_constraintBottom_toBottomOf, R.attr.layout_constraintBottom_toTopOf, R.attr.layout_constraintCircle, R.attr.layout_constraintCircleAngle, R.attr.layout_constraintCircleRadius, R.attr.layout_constraintDimensionRatio, R.attr.layout_constraintEnd_toEndOf, R.attr.layout_constraintEnd_toStartOf, R.attr.layout_constraintGuide_begin, R.attr.layout_constraintGuide_end, R.attr.layout_constraintGuide_percent, R.attr.layout_constraintHeight_default, R.attr.layout_constraintHeight_max, R.attr.layout_constraintHeight_min, R.attr.layout_constraintHeight_percent, R.attr.layout_constraintHorizontal_bias, R.attr.layout_constraintHorizontal_chainStyle, R.attr.layout_constraintHorizontal_weight, R.attr.layout_constraintLeft_creator, R.attr.layout_constraintLeft_toLeftOf, R.attr.layout_constraintLeft_toRightOf, R.attr.layout_constraintRight_creator, R.attr.layout_constraintRight_toLeftOf, R.attr.layout_constraintRight_toRightOf, R.attr.layout_constraintStart_toEndOf, R.attr.layout_constraintStart_toStartOf, R.attr.layout_constraintTop_creator, R.attr.layout_constraintTop_toBottomOf, R.attr.layout_constraintTop_toTopOf, R.attr.layout_constraintVertical_bias, R.attr.layout_constraintVertical_chainStyle, R.attr.layout_constraintVertical_weight, R.attr.layout_constraintWidth_default, R.attr.layout_constraintWidth_max, R.attr.layout_constraintWidth_min, R.attr.layout_constraintWidth_percent, R.attr.layout_editor_absoluteX, R.attr.layout_editor_absoluteY, R.attr.layout_goneMarginBottom, R.attr.layout_goneMarginEnd, R.attr.layout_goneMarginLeft, R.attr.layout_goneMarginRight, R.attr.layout_goneMarginStart, R.attr.layout_goneMarginTop, R.attr.maxHeight, R.attr.maxWidth, R.attr.minHeight, R.attr.minWidth};
        public static int[] LinearLayoutCompat = {android.R.attr.gravity, android.R.attr.orientation, android.R.attr.baselineAligned, android.R.attr.baselineAlignedChildIndex, android.R.attr.weightSum, R.attr.divider, R.attr.dividerPadding, R.attr.measureWithLargestChild, R.attr.showDividers};
        public static int[] LinearLayoutCompat_Layout = {android.R.attr.layout_gravity, android.R.attr.layout_width, android.R.attr.layout_height, android.R.attr.layout_weight};
        public static int[] LinearProgressIndicator = {R.attr.indeterminateAnimationType, R.attr.indicatorDirectionLinear, R.attr.trackStopIndicatorSize};
        public static int[] ListPopupWindow = {android.R.attr.dropDownHorizontalOffset, android.R.attr.dropDownVerticalOffset};
        public static int[] MaterialAlertDialog = {R.attr.backgroundInsetBottom, R.attr.backgroundInsetEnd, R.attr.backgroundInsetStart, R.attr.backgroundInsetTop, R.attr.backgroundTint};
        public static int[] MaterialAlertDialogTheme = {R.attr.materialAlertDialogBodyTextStyle, R.attr.materialAlertDialogButtonSpacerVisibility, R.attr.materialAlertDialogTheme, R.attr.materialAlertDialogTitleIconStyle, R.attr.materialAlertDialogTitlePanelStyle, R.attr.materialAlertDialogTitleTextStyle};
        public static int[] MaterialAutoCompleteTextView = {android.R.attr.inputType, android.R.attr.popupElevation, R.attr.dropDownBackgroundTint, R.attr.simpleItemLayout, R.attr.simpleItemSelectedColor, R.attr.simpleItemSelectedRippleColor, R.attr.simpleItems};
        public static int[] MaterialButton = {android.R.attr.background, android.R.attr.insetLeft, android.R.attr.insetRight, android.R.attr.insetTop, android.R.attr.insetBottom, android.R.attr.checkable, R.attr.backgroundTint, R.attr.backgroundTintMode, R.attr.cornerRadius, R.attr.elevation, R.attr.icon, R.attr.iconGravity, R.attr.iconPadding, R.attr.iconSize, R.attr.iconTint, R.attr.iconTintMode, R.attr.rippleColor, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.strokeColor, R.attr.strokeWidth, R.attr.toggleCheckedStateOnClick};
        public static int[] MaterialButtonToggleGroup = {android.R.attr.enabled, R.attr.checkedButton, R.attr.selectionRequired, R.attr.singleSelection};
        public static int[] MaterialCalendar = {android.R.attr.windowFullscreen, R.attr.backgroundTint, R.attr.dayInvalidStyle, R.attr.daySelectedStyle, R.attr.dayStyle, R.attr.dayTodayStyle, R.attr.nestedScrollable, R.attr.rangeFillColor, R.attr.yearSelectedStyle, R.attr.yearStyle, R.attr.yearTodayStyle};
        public static int[] MaterialCalendarItem = {android.R.attr.insetLeft, android.R.attr.insetRight, android.R.attr.insetTop, android.R.attr.insetBottom, R.attr.itemFillColor, R.attr.itemShapeAppearance, R.attr.itemShapeAppearanceOverlay, R.attr.itemStrokeColor, R.attr.itemStrokeWidth, R.attr.itemTextColor};
        public static int[] MaterialCardView = {android.R.attr.checkable, R.attr.cardForegroundColor, R.attr.checkedIcon, R.attr.checkedIconGravity, R.attr.checkedIconMargin, R.attr.checkedIconSize, R.attr.checkedIconTint, R.attr.rippleColor, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.state_dragged, R.attr.strokeColor, R.attr.strokeWidth};
        public static int[] MaterialCheckBox = {android.R.attr.button, R.attr.buttonCompat, R.attr.buttonIcon, R.attr.buttonIconTint, R.attr.buttonIconTintMode, R.attr.buttonTint, R.attr.centerIfNoTextEnabled, R.attr.checkedState, R.attr.errorAccessibilityLabel, R.attr.errorShown, R.attr.useMaterialThemeColors};
        public static int[] MaterialCheckBoxStates = {R.attr.state_error, R.attr.state_indeterminate};
        public static int[] MaterialDivider = {R.attr.dividerColor, R.attr.dividerInsetEnd, R.attr.dividerInsetStart, R.attr.dividerThickness, R.attr.lastItemDecorated};
        public static int[] MaterialRadioButton = {R.attr.buttonTint, R.attr.useMaterialThemeColors};
        public static int[] MaterialShape = {R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay};
        public static int[] MaterialSwitch = {R.attr.thumbIcon, R.attr.thumbIconSize, R.attr.thumbIconTint, R.attr.thumbIconTintMode, R.attr.trackDecoration, R.attr.trackDecorationTint, R.attr.trackDecorationTintMode};
        public static int[] MaterialTextAppearance = {android.R.attr.letterSpacing, android.R.attr.lineHeight, R.attr.lineHeight};
        public static int[] MaterialTextView = {android.R.attr.textAppearance, android.R.attr.lineHeight, R.attr.lineHeight};
        public static int[] MaterialTimePicker = {R.attr.backgroundTint, R.attr.clockIcon, R.attr.keyboardIcon};
        public static int[] MaterialToolbar = {R.attr.logoAdjustViewBounds, R.attr.logoScaleType, R.attr.navigationIconTint, R.attr.subtitleCentered, R.attr.titleCentered};
        public static int[] MenuGroup = {android.R.attr.enabled, android.R.attr.id, android.R.attr.visible, android.R.attr.menuCategory, android.R.attr.orderInCategory, android.R.attr.checkableBehavior};
        public static int[] MenuItem = {android.R.attr.icon, android.R.attr.enabled, android.R.attr.id, android.R.attr.checked, android.R.attr.visible, android.R.attr.menuCategory, android.R.attr.orderInCategory, android.R.attr.title, android.R.attr.titleCondensed, android.R.attr.alphabeticShortcut, android.R.attr.numericShortcut, android.R.attr.checkable, android.R.attr.onClick, R.attr.actionLayout, R.attr.actionProviderClass, R.attr.actionViewClass, R.attr.alphabeticModifiers, R.attr.contentDescription, R.attr.iconTint, R.attr.iconTintMode, R.attr.numericModifiers, R.attr.showAsAction, R.attr.tooltipText};
        public static int[] MenuView = {android.R.attr.windowAnimationStyle, android.R.attr.itemTextAppearance, android.R.attr.horizontalDivider, android.R.attr.verticalDivider, android.R.attr.headerBackground, android.R.attr.itemBackground, android.R.attr.itemIconDisabledAlpha, R.attr.preserveIconSpacing, R.attr.subMenuArrow};
        public static int[] MockView = {R.attr.mock_diagonalsColor, R.attr.mock_label, R.attr.mock_labelBackgroundColor, R.attr.mock_labelColor, R.attr.mock_showDiagonals, R.attr.mock_showLabel};
        public static int[] Motion = {R.attr.animate_relativeTo, R.attr.drawPath, R.attr.motionPathRotate, R.attr.motionStagger, R.attr.pathMotionArc, R.attr.transitionEasing};
        public static int[] MotionHelper = {R.attr.onHide, R.attr.onShow};
        public static int[] MotionLayout = {R.attr.applyMotionScene, R.attr.currentState, R.attr.layoutDescription, R.attr.motionDebug, R.attr.motionProgress, R.attr.showPaths};
        public static int[] MotionScene = {R.attr.defaultDuration, R.attr.layoutDuringTransition};
        public static int[] MotionTelltales = {R.attr.telltales_tailColor, R.attr.telltales_tailScale, R.attr.telltales_velocityMode};
        public static int[] NavigationBarActiveIndicator = {android.R.attr.height, android.R.attr.width, android.R.attr.color, R.attr.marginHorizontal, R.attr.shapeAppearance};
        public static int[] NavigationBarView = {R.attr.activeIndicatorLabelPadding, R.attr.backgroundTint, R.attr.elevation, R.attr.itemActiveIndicatorStyle, R.attr.itemBackground, R.attr.itemIconSize, R.attr.itemIconTint, R.attr.itemPaddingBottom, R.attr.itemPaddingTop, R.attr.itemRippleColor, R.attr.itemTextAppearanceActive, R.attr.itemTextAppearanceActiveBoldEnabled, R.attr.itemTextAppearanceInactive, R.attr.itemTextColor, R.attr.labelVisibilityMode, R.attr.menu};
        public static int[] NavigationRailView = {R.attr.headerLayout, R.attr.itemMinHeight, R.attr.menuGravity, R.attr.paddingBottomSystemWindowInsets, R.attr.paddingStartSystemWindowInsets, R.attr.paddingTopSystemWindowInsets, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay};
        public static int[] NavigationView = {android.R.attr.layout_gravity, android.R.attr.background, android.R.attr.fitsSystemWindows, android.R.attr.maxWidth, R.attr.bottomInsetScrimEnabled, R.attr.dividerInsetEnd, R.attr.dividerInsetStart, R.attr.drawerLayoutCornerSize, R.attr.elevation, R.attr.headerLayout, R.attr.itemBackground, R.attr.itemHorizontalPadding, R.attr.itemIconPadding, R.attr.itemIconSize, R.attr.itemIconTint, R.attr.itemMaxLines, R.attr.itemRippleColor, R.attr.itemShapeAppearance, R.attr.itemShapeAppearanceOverlay, R.attr.itemShapeFillColor, R.attr.itemShapeInsetBottom, R.attr.itemShapeInsetEnd, R.attr.itemShapeInsetStart, R.attr.itemShapeInsetTop, R.attr.itemTextAppearance, R.attr.itemTextAppearanceActiveBoldEnabled, R.attr.itemTextColor, R.attr.itemVerticalPadding, R.attr.menu, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.subheaderColor, R.attr.subheaderInsetEnd, R.attr.subheaderInsetStart, R.attr.subheaderTextAppearance, R.attr.topInsetScrimEnabled};
        public static int[] OnClick = {R.attr.clickAction, R.attr.targetId};
        public static int[] OnSwipe = {R.attr.dragDirection, R.attr.dragScale, R.attr.dragThreshold, R.attr.limitBoundsTo, R.attr.maxAcceleration, R.attr.maxVelocity, R.attr.moveWhenScrollAtTop, R.attr.nestedScrollFlags, R.attr.onTouchUp, R.attr.touchAnchorId, R.attr.touchAnchorSide, R.attr.touchRegionId};
        public static int[] PopupWindow = {android.R.attr.popupBackground, android.R.attr.popupAnimationStyle, R.attr.overlapAnchor};
        public static int[] PopupWindowBackgroundState = {R.attr.state_above_anchor};
        public static int[] PropertySet = {android.R.attr.visibility, android.R.attr.alpha, R.attr.layout_constraintTag, R.attr.motionProgress, R.attr.visibilityMode};
        public static int[] RadialViewGroup = {R.attr.materialCircleRadius};
        public static int[] RangeSlider = {R.attr.minSeparation, R.attr.values};
        public static int[] RecycleListView = {R.attr.paddingBottomNoButtons, R.attr.paddingTopNoTitle};
        public static int[] RecyclerView = {android.R.attr.orientation, android.R.attr.clipToPadding, android.R.attr.descendantFocusability, R.attr.fastScrollEnabled, R.attr.fastScrollHorizontalThumbDrawable, R.attr.fastScrollHorizontalTrackDrawable, R.attr.fastScrollVerticalThumbDrawable, R.attr.fastScrollVerticalTrackDrawable, R.attr.layoutManager, R.attr.reverseLayout, R.attr.spanCount, R.attr.stackFromEnd};
        public static int[] ScrimInsetsFrameLayout = {R.attr.insetForeground};
        public static int[] ScrollingViewBehavior_Layout = {R.attr.behavior_overlapTop};
        public static int[] SearchBar = {android.R.attr.textAppearance, android.R.attr.text, android.R.attr.hint, R.attr.backgroundTint, R.attr.defaultMarginsEnabled, R.attr.defaultScrollFlagsEnabled, R.attr.elevation, R.attr.forceDefaultNavigationOnClickListener, R.attr.hideNavigationIcon, R.attr.navigationIconTint, R.attr.strokeColor, R.attr.strokeWidth, R.attr.tintNavigationIcon};
        public static int[] SearchView = {android.R.attr.textAppearance, android.R.attr.focusable, android.R.attr.maxWidth, android.R.attr.text, android.R.attr.hint, android.R.attr.inputType, android.R.attr.imeOptions, R.attr.animateMenuItems, R.attr.animateNavigationIcon, R.attr.autoShowKeyboard, R.attr.backHandlingEnabled, R.attr.backgroundTint, R.attr.closeIcon, R.attr.commitIcon, R.attr.defaultQueryHint, R.attr.goIcon, R.attr.headerLayout, R.attr.hideNavigationIcon, R.attr.iconifiedByDefault, R.attr.layout, R.attr.queryBackground, R.attr.queryHint, R.attr.searchHintIcon, R.attr.searchIcon, R.attr.searchPrefixText, R.attr.submitBackground, R.attr.suggestionRowLayout, R.attr.useDrawerArrowDrawable, R.attr.voiceIcon};
        public static int[] ShapeAppearance = {R.attr.cornerFamily, R.attr.cornerFamilyBottomLeft, R.attr.cornerFamilyBottomRight, R.attr.cornerFamilyTopLeft, R.attr.cornerFamilyTopRight, R.attr.cornerSize, R.attr.cornerSizeBottomLeft, R.attr.cornerSizeBottomRight, R.attr.cornerSizeTopLeft, R.attr.cornerSizeTopRight};
        public static int[] ShapeableImageView = {R.attr.contentPadding, R.attr.contentPaddingBottom, R.attr.contentPaddingEnd, R.attr.contentPaddingLeft, R.attr.contentPaddingRight, R.attr.contentPaddingStart, R.attr.contentPaddingTop, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.strokeColor, R.attr.strokeWidth};
        public static int[] SideSheetBehavior_Layout = {android.R.attr.maxWidth, android.R.attr.maxHeight, android.R.attr.elevation, R.attr.backgroundTint, R.attr.behavior_draggable, R.attr.coplanarSiblingViewId, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay};
        public static int[] Slider = {android.R.attr.enabled, android.R.attr.value, android.R.attr.stepSize, android.R.attr.valueFrom, android.R.attr.valueTo, R.attr.haloColor, R.attr.haloRadius, R.attr.labelBehavior, R.attr.labelStyle, R.attr.minTouchTargetSize, R.attr.thumbColor, R.attr.thumbElevation, R.attr.thumbHeight, R.attr.thumbRadius, R.attr.thumbStrokeColor, R.attr.thumbStrokeWidth, R.attr.thumbTrackGapSize, R.attr.thumbWidth, R.attr.tickColor, R.attr.tickColorActive, R.attr.tickColorInactive, R.attr.tickRadiusActive, R.attr.tickRadiusInactive, R.attr.tickVisible, R.attr.trackColor, R.attr.trackColorActive, R.attr.trackColorInactive, R.attr.trackHeight, R.attr.trackInsideCornerSize, R.attr.trackStopIndicatorSize};
        public static int[] Snackbar = {R.attr.snackbarButtonStyle, R.attr.snackbarStyle, R.attr.snackbarTextViewStyle};
        public static int[] SnackbarLayout = {android.R.attr.maxWidth, R.attr.actionTextColorAlpha, R.attr.animationMode, R.attr.backgroundOverlayColorAlpha, R.attr.backgroundTint, R.attr.backgroundTintMode, R.attr.elevation, R.attr.maxActionInlineWidth, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay};
        public static int[] Spinner = {android.R.attr.entries, android.R.attr.popupBackground, android.R.attr.prompt, android.R.attr.dropDownWidth, R.attr.popupTheme};
        public static int[] State = {android.R.attr.id, R.attr.constraints};
        public static int[] StateListDrawable = {android.R.attr.dither, android.R.attr.visible, android.R.attr.variablePadding, android.R.attr.constantSize, android.R.attr.enterFadeDuration, android.R.attr.exitFadeDuration};
        public static int[] StateListDrawableItem = {android.R.attr.drawable};
        public static int[] StateSet = {R.attr.defaultState};
        public static int[] SwitchCompat = {android.R.attr.textOn, android.R.attr.textOff, android.R.attr.thumb, R.attr.showText, R.attr.splitTrack, R.attr.switchMinWidth, R.attr.switchPadding, R.attr.switchTextAppearance, R.attr.thumbTextPadding, R.attr.thumbTint, R.attr.thumbTintMode, R.attr.track, R.attr.trackTint, R.attr.trackTintMode};
        public static int[] SwitchMaterial = {R.attr.useMaterialThemeColors};
        public static int[] TabItem = {android.R.attr.icon, android.R.attr.layout, android.R.attr.text};
        public static int[] TabLayout = {R.attr.tabBackground, R.attr.tabContentStart, R.attr.tabGravity, R.attr.tabIconTint, R.attr.tabIconTintMode, R.attr.tabIndicator, R.attr.tabIndicatorAnimationDuration, R.attr.tabIndicatorAnimationMode, R.attr.tabIndicatorColor, R.attr.tabIndicatorFullWidth, R.attr.tabIndicatorGravity, R.attr.tabIndicatorHeight, R.attr.tabInlineLabel, R.attr.tabMaxWidth, R.attr.tabMinWidth, R.attr.tabMode, R.attr.tabPadding, R.attr.tabPaddingBottom, R.attr.tabPaddingEnd, R.attr.tabPaddingStart, R.attr.tabPaddingTop, R.attr.tabRippleColor, R.attr.tabSelectedTextAppearance, R.attr.tabSelectedTextColor, R.attr.tabTextAppearance, R.attr.tabTextColor, R.attr.tabUnboundedRipple};
        public static int[] TextAppearance = {android.R.attr.textSize, android.R.attr.typeface, android.R.attr.textStyle, android.R.attr.textColor, android.R.attr.textColorHint, android.R.attr.textColorLink, android.R.attr.shadowColor, android.R.attr.shadowDx, android.R.attr.shadowDy, android.R.attr.shadowRadius, android.R.attr.fontFamily, android.R.attr.textFontWeight, R.attr.fontFamily, R.attr.fontVariationSettings, R.attr.textAllCaps, R.attr.textLocale};
        public static int[] TextInputEditText = {R.attr.textInputLayoutFocusedRectEnabled};
        public static int[] TextInputLayout = {android.R.attr.enabled, android.R.attr.textColorHint, android.R.attr.maxWidth, android.R.attr.minWidth, android.R.attr.hint, android.R.attr.maxEms, android.R.attr.minEms, R.attr.boxBackgroundColor, R.attr.boxBackgroundMode, R.attr.boxCollapsedPaddingTop, R.attr.boxCornerRadiusBottomEnd, R.attr.boxCornerRadiusBottomStart, R.attr.boxCornerRadiusTopEnd, R.attr.boxCornerRadiusTopStart, R.attr.boxStrokeColor, R.attr.boxStrokeErrorColor, R.attr.boxStrokeWidth, R.attr.boxStrokeWidthFocused, R.attr.counterEnabled, R.attr.counterMaxLength, R.attr.counterOverflowTextAppearance, R.attr.counterOverflowTextColor, R.attr.counterTextAppearance, R.attr.counterTextColor, R.attr.cursorColor, R.attr.cursorErrorColor, R.attr.endIconCheckable, R.attr.endIconContentDescription, R.attr.endIconDrawable, R.attr.endIconMinSize, R.attr.endIconMode, R.attr.endIconScaleType, R.attr.endIconTint, R.attr.endIconTintMode, R.attr.errorAccessibilityLiveRegion, R.attr.errorContentDescription, R.attr.errorEnabled, R.attr.errorIconDrawable, R.attr.errorIconTint, R.attr.errorIconTintMode, R.attr.errorTextAppearance, R.attr.errorTextColor, R.attr.expandedHintEnabled, R.attr.helperText, R.attr.helperTextEnabled, R.attr.helperTextTextAppearance, R.attr.helperTextTextColor, R.attr.hintAnimationEnabled, R.attr.hintEnabled, R.attr.hintTextAppearance, R.attr.hintTextColor, R.attr.passwordToggleContentDescription, R.attr.passwordToggleDrawable, R.attr.passwordToggleEnabled, R.attr.passwordToggleTint, R.attr.passwordToggleTintMode, R.attr.placeholderText, R.attr.placeholderTextAppearance, R.attr.placeholderTextColor, R.attr.prefixText, R.attr.prefixTextAppearance, R.attr.prefixTextColor, R.attr.shapeAppearance, R.attr.shapeAppearanceOverlay, R.attr.startIconCheckable, R.attr.startIconContentDescription, R.attr.startIconDrawable, R.attr.startIconMinSize, R.attr.startIconScaleType, R.attr.startIconTint, R.attr.startIconTintMode, R.attr.suffixText, R.attr.suffixTextAppearance, R.attr.suffixTextColor};
        public static int[] ThemeEnforcement = {android.R.attr.textAppearance, R.attr.enforceMaterialTheme, R.attr.enforceTextAppearance};
        public static int[] Toolbar = {android.R.attr.gravity, android.R.attr.minHeight, R.attr.buttonGravity, R.attr.collapseContentDescription, R.attr.collapseIcon, R.attr.contentInsetEnd, R.attr.contentInsetEndWithActions, R.attr.contentInsetLeft, R.attr.contentInsetRight, R.attr.contentInsetStart, R.attr.contentInsetStartWithNavigation, R.attr.logo, R.attr.logoDescription, R.attr.maxButtonHeight, R.attr.menu, R.attr.navigationContentDescription, R.attr.navigationIcon, R.attr.popupTheme, R.attr.subtitle, R.attr.subtitleTextAppearance, R.attr.subtitleTextColor, R.attr.title, R.attr.titleMargin, R.attr.titleMarginBottom, R.attr.titleMarginEnd, R.attr.titleMarginStart, R.attr.titleMarginTop, R.attr.titleMargins, R.attr.titleTextAppearance, R.attr.titleTextColor};
        public static int[] Tooltip = {android.R.attr.textAppearance, android.R.attr.textColor, android.R.attr.padding, android.R.attr.layout_margin, android.R.attr.minWidth, android.R.attr.minHeight, android.R.attr.text, R.attr.backgroundTint, R.attr.showMarker};
        public static int[] Transform = {android.R.attr.transformPivotX, android.R.attr.transformPivotY, android.R.attr.translationX, android.R.attr.translationY, android.R.attr.scaleX, android.R.attr.scaleY, android.R.attr.rotation, android.R.attr.rotationX, android.R.attr.rotationY, android.R.attr.translationZ, android.R.attr.elevation};
        public static int[] Transition = {android.R.attr.id, R.attr.autoTransition, R.attr.constraintSetEnd, R.attr.constraintSetStart, R.attr.duration, R.attr.layoutDuringTransition, R.attr.motionInterpolator, R.attr.pathMotionArc, R.attr.staggered, R.attr.transitionDisable, R.attr.transitionFlags};
        public static int[] Variant = {R.attr.constraints, R.attr.region_heightLessThan, R.attr.region_heightMoreThan, R.attr.region_widthLessThan, R.attr.region_widthMoreThan};
        public static int[] View = {android.R.attr.theme, android.R.attr.focusable, R.attr.paddingEnd, R.attr.paddingStart, R.attr.theme};
        public static int[] ViewBackgroundHelper = {android.R.attr.background, R.attr.backgroundTint, R.attr.backgroundTintMode};
        public static int[] ViewPager2 = {android.R.attr.orientation};
        public static int[] ViewStubCompat = {android.R.attr.id, android.R.attr.layout, android.R.attr.inflatedId};

        private styleable() {
        }
    }

    /* JADX INFO: Added by JADX */
    public static final class xml {

        /* JADX INFO: Added by JADX */
        public static final int r_qwodwc = 0x7f110000;

        /* JADX INFO: Added by JADX */
        public static final int r_0tcg5m = 0x7f110001;

        /* JADX INFO: Added by JADX */
        public static final int r_19389t = 0x7f110002;

        /* JADX INFO: Added by JADX */
        public static final int r_gwu6k0 = 0x7f110003;
    }

    private R() {
    }
}
